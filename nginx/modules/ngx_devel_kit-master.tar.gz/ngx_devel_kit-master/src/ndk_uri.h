


u_char *  ndk_map_uri_to_path_add_suffix  (ngx_http_request_t *r, ngx_str_t *path, ngx_str_t *suffix, ngx_int_t dot);


