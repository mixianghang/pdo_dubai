#include <ngx_config.h>
#include <ngx_core.h>
#include <ngx_http.h>

#define MMC_CONSISTENT_BUCKETS 1024
#define MMC_CONSISTENT_POINTS 160

#define HASH_DATA_MAX_LENGTH 28

// 服务器虚拟节点定义
typedef struct {
    uint32_t point; //每个节点有一个hash值
    struct sockaddr* sockaddr; //保存服务器的sock信息
    socklen_t socklen; //sock len
    ngx_str_t name; //名字
} ngx_http_baidu_upstream_consistent_hash_node;

// 一致性hash环
typedef struct {
    ngx_uint_t npoints; //一共有的虚拟节点个数
    ngx_http_baidu_upstream_consistent_hash_node* nodes; //虚拟节点数组
} ngx_http_baidu_upstream_consistent_hash_continuum;

// 最后使用的hash桶，拥有1024个服务器虚拟节点
typedef struct {
    //指向hash环的指针
    ngx_http_baidu_upstream_consistent_hash_continuum* continuum;
    //hash桶，指向虚拟节点的指针
    ngx_http_baidu_upstream_consistent_hash_node* buckets[MMC_CONSISTENT_BUCKETS];
    ngx_array_t* vars_lengths;
    ngx_array_t* vars_values;
} ngx_http_baidu_upstream_consistent_hash_buckets;

// 连接用的peer数据
typedef struct {
    ngx_http_baidu_upstream_consistent_hash_buckets *peers;
    u_char tries;
    uint32_t point;
    ngx_event_get_peer_pt get_rr_peer;
} ngx_http_baidu_upstream_consistent_hash_peer_data_t;

static char* ngx_http_baidu_upstream_consistent_hash(
    ngx_conf_t*, ngx_command_t*, void*);
static ngx_int_t ngx_http_baidu_upstream_init_consistent_hash(
    ngx_conf_t*, ngx_http_upstream_srv_conf_t*);
static ngx_int_t ngx_http_baidu_upstream_init_consistent_hash_peer(
    ngx_http_request_t*, ngx_http_upstream_srv_conf_t*);
static ngx_int_t ngx_http_baidu_upstream_get_consistent_hash_peer(
    ngx_peer_connection_t*, void*);
static void ngx_http_baidu_upstream_free_consistent_hash_peer(
    ngx_peer_connection_t*, void*, ngx_uint_t);
static int ngx_http_baidu_upstream_consistent_hash_compare_continuum_nodes(
    const void*, const void*);
static ngx_http_baidu_upstream_consistent_hash_node*
ngx_http_baidu_upstream_consistent_hash_find(
    ngx_http_baidu_upstream_consistent_hash_continuum*, uint32_t);

static ngx_command_t ngx_http_baidu_upstream_consistent_hash_commands[] = {
    {
        ngx_string("consistent_hash"),
        NGX_HTTP_UPS_CONF|NGX_CONF_TAKE1,
        ngx_http_baidu_upstream_consistent_hash,
        0,
        0,
        NULL
    },
    ngx_null_command
};

static ngx_http_module_t ngx_http_baidu_upstream_consistent_hash_module_ctx = {
    NULL,                                  /* preconfiguration */
    NULL,                                  /* postconfiguration */
    NULL,                                  /* create main configuration */
    NULL,                                  /* init main configuration */
    NULL,                                  /* create server configuration */
    NULL,                                  /* merge server configuration */
    NULL,                                  /* create location configuration */
    NULL                                   /* merge location configuration */
};

ngx_module_t  ngx_http_baidu_upstream_consistent_hash_module = {
    NGX_MODULE_V1,
    &ngx_http_baidu_upstream_consistent_hash_module_ctx, /* module context */
    ngx_http_baidu_upstream_consistent_hash_commands,    /* module directives */
    NGX_HTTP_MODULE,                               /* module type */
    NULL,                                          /* init master */
    NULL,                                          /* init module */
    NULL,                                          /* init process */
    NULL,                                          /* init thread */
    NULL,                                          /* exit thread */
    NULL,                                          /* exit process */
    NULL,                                          /* exit master */
    NGX_MODULE_V1_PADDING
};

static char*
ngx_http_baidu_upstream_consistent_hash(
    ngx_conf_t* cf, ngx_command_t* cmd, void* conf) {

    ngx_http_upstream_srv_conf_t* uscf;
    ngx_http_script_compile_t sc;
    ngx_str_t *value;
    ngx_http_baidu_upstream_consistent_hash_buckets* buckets;

    // 初始化buckets
    buckets = ngx_pcalloc(cf->pool,
            sizeof(ngx_http_baidu_upstream_consistent_hash_buckets));
    if (buckets == NULL) {
        return NGX_CONF_ERROR;
    }
    buckets->vars_values = NULL;
    buckets->vars_lengths = NULL;

    // 绑定变量相关
    value = cf->args->elts;
    ngx_memzero(&sc, sizeof(ngx_http_script_compile_t));
    sc.cf = cf;
    sc.source = &value[1];
    sc.lengths = &buckets->vars_lengths;
    sc.values = &buckets->vars_values;
    sc.complete_lengths = 1;
    sc.complete_values = 1;

    if (ngx_http_script_compile(&sc) != NGX_OK) {
        return NGX_CONF_ERROR;
    }

    uscf = ngx_http_conf_get_module_srv_conf(cf, ngx_http_upstream_module);
    uscf->peer.init_upstream = ngx_http_baidu_upstream_init_consistent_hash;
    uscf->peer.data = buckets;
    uscf->flags = NGX_HTTP_UPSTREAM_CREATE | NGX_HTTP_UPSTREAM_WEIGHT;

    return NGX_CONF_OK;
}

ngx_int_t
ngx_http_baidu_upstream_init_consistent_hash(
    ngx_conf_t* cf, ngx_http_upstream_srv_conf_t* us) {
    uint32_t step;
    u_char key[HASH_DATA_MAX_LENGTH];
    ngx_uint_t i, j, n, k, m, points=0;
    ngx_http_upstream_server_t* server;
    ngx_http_baidu_upstream_consistent_hash_continuum* continuum;
    ngx_http_baidu_upstream_consistent_hash_buckets* buckets;

    if (!us->servers) {
        return NGX_ERROR;
    }

    // 获取hash桶
    buckets = us->peer.data;

    // 获取服务器头指针
    server = us->servers->elts;
    for (i = 0; i < us->servers->nelts; i++) {
        points += server[i].weight * server[i].naddrs * MMC_CONSISTENT_POINTS;
    }

    continuum = ngx_pcalloc(cf->pool,
            sizeof(ngx_http_baidu_upstream_consistent_hash_continuum));
    if (continuum == NULL) {
        return NGX_ERROR;
    }
    continuum->npoints = points;

    continuum->nodes = ngx_pcalloc(cf->pool,
            sizeof(ngx_http_baidu_upstream_consistent_hash_node) * points);
    if (continuum->nodes == NULL) {
        return NGX_ERROR;
    }

    // 创建所有虚拟服务节点
    for (i = 0, n = 0; i < us->servers->nelts; i++) {
        for (j = 0; j < server[i].naddrs; j++) {
            for (m = 0; m < HASH_DATA_MAX_LENGTH; m++) key[m] = '\0';
            for (k = 0; k < MMC_CONSISTENT_POINTS * server[i].weight; k++) {
                ngx_snprintf(key, HASH_DATA_MAX_LENGTH,
                        "%V-%ui", &server[i].addrs[j].name, k);
                continuum->nodes[n].sockaddr = server[i].addrs[j].sockaddr;
                continuum->nodes[n].socklen = server[i].addrs[j].socklen;
                continuum->nodes[n].name = server[i].addrs[j].name;
                continuum->nodes[n].name.data[server[i].addrs[j].name.len] = 0;
                continuum->nodes[n].point =
                    ngx_crc32_long(key, ngx_strlen(key));
                n++;
            }
        }
    }

    // 排序
    qsort(continuum->nodes, continuum->npoints,
        sizeof(ngx_http_baidu_upstream_consistent_hash_node),
        ngx_http_baidu_upstream_consistent_hash_compare_continuum_nodes);

    // 计算hash桶
    step = (uint32_t) (0xffffffff / MMC_CONSISTENT_BUCKETS);
    for (i = 0; i < MMC_CONSISTENT_BUCKETS; i++) {
        buckets->buckets[i] =
            ngx_http_baidu_upstream_consistent_hash_find(continuum, step * i);
    }

    buckets->continuum = continuum;
    us->peer.init = ngx_http_baidu_upstream_init_consistent_hash_peer;

    return NGX_OK;
}

static ngx_int_t
ngx_http_baidu_upstream_init_consistent_hash_peer(ngx_http_request_t *r,
    ngx_http_upstream_srv_conf_t *us) {
    ngx_http_baidu_upstream_consistent_hash_peer_data_t *uchpd;
    ngx_str_t key;

    uchpd = ngx_pcalloc(r->pool,
            sizeof(ngx_http_baidu_upstream_consistent_hash_peer_data_t));
    if (uchpd == NULL) {
        return NGX_ERROR;
    }

    uchpd->peers = us->peer.data;
    r->upstream->peer.data = us->peer.data;

    if (ngx_http_script_run(r, &key, uchpd->peers->vars_lengths->elts,
        0, uchpd->peers->vars_values->elts) == NULL) {
        return NGX_ERROR;
    }

    uchpd->point = ngx_crc32_long(key.data, key.len);
    r->upstream->peer.free = ngx_http_baidu_upstream_free_consistent_hash_peer;
    r->upstream->peer.get = ngx_http_baidu_upstream_get_consistent_hash_peer;
    r->upstream->peer.data = uchpd;

    return NGX_OK;
}

static ngx_int_t
ngx_http_baidu_upstream_get_consistent_hash_peer(
    ngx_peer_connection_t* pc, void* data) {
    ngx_http_baidu_upstream_consistent_hash_peer_data_t* uchpd = data;
    ngx_int_t index = uchpd->point % MMC_CONSISTENT_BUCKETS;

    pc->cached = 0;
    pc->connection = NULL;
    pc->sockaddr = uchpd->peers->buckets[index]->sockaddr;
    pc->socklen = uchpd->peers->buckets[index]->socklen;
    pc->name = &uchpd->peers->buckets[index]->name;

    return NGX_OK;
}

static void
ngx_http_baidu_upstream_free_consistent_hash_peer(
    ngx_peer_connection_t* pc, void* data, ngx_uint_t state) {
    pc->tries = 0;
}

static ngx_http_baidu_upstream_consistent_hash_node*
ngx_http_baidu_upstream_consistent_hash_find(
    ngx_http_baidu_upstream_consistent_hash_continuum* continuum,
    uint32_t point) {

    ngx_uint_t mid = 0, lo = 0, hi = continuum->npoints- 1;
    while (1) {
        if (point <= continuum->nodes[lo].point
            || point > continuum->nodes[hi].point) {
            return &continuum->nodes[lo];
        }

        mid = lo + (hi - lo) / 2;
        if (point <= continuum->nodes[mid].point
            && point > (mid ? continuum->nodes[mid-1].point : 0)) {
            return &continuum->nodes[mid];
        }

        if (continuum->nodes[mid].point < point) {
            lo = mid + 1;
        } else {
            hi = mid - 1;
        }
    }
}

static int
ngx_http_baidu_upstream_consistent_hash_compare_continuum_nodes(
    const void* a, const void* b) {
    ngx_http_baidu_upstream_consistent_hash_node* node1;
    ngx_http_baidu_upstream_consistent_hash_node* node2;

    node1 = (ngx_http_baidu_upstream_consistent_hash_node *)a;
    node2 = (ngx_http_baidu_upstream_consistent_hash_node *)b;

    if (node1->point < node2->point) {
        return -1;
    } else if (node1->point > node2->point) {
        return 1;
    }

    return 0;
}
