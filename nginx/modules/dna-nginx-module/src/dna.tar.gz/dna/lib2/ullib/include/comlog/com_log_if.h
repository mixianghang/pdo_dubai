/***************************************************************************
 * 
 * Copyright (c) 2008 Baidu.com, Inc. All Rights Reserved
 * $Id: com_log_if.h,v 1.2 2009/03/25 12:34:11 yingxiang Exp $ 
 * 
 **************************************************************************/
 
 
 
/**
 * @file com_log_if.h
 * @author xiaowei(com@baidu.com)
 * @date 2008/03/26 16:28:23
 * @version $Revision: 1.2 $ 
 * @brief 
 *  
 **/


#ifndef  __COM_LOG_IF_H_
#define  __COM_LOG_IF_H_

#include "comlog.h"
#include "event.h"
#include "category.h"
#include "layout.h"
#include "appender/appender.h"

















#endif  //__COM_LOG_IF_H_

/* vim: set ts=4 sw=4 sts=4 tw=100 */
