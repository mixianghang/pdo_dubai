/***************************************************************************
 * 
 * Copyright (c) 2007 Baidu.com, Inc. All Rights Reserved
 * $Id: ul_htmltag.h,v 1.2 2008/08/13 02:28:55 baonh Exp $ 
 * 
 **************************************************************************/



/**
 * @file ul_htmltag.h
 * @author com-dev (com-dev@baidu.com)
 * @date 2007/12/14 11:08:35
 * @version $Revision: 1.2 $ 
 * @brief ������ҳ�е�tag
 */



#ifndef __UL_HTMLTAG_H_
#define __UL_HTMLTAG_H_


#include "dep/dep_htmltag.h"


#endif
/* vim: set ts=4 sw=4 sts=4 tw=100 noet: */
