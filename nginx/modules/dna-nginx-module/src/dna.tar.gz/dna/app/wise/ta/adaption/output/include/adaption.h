/*:
 * =====================================================================================
 *
 *       Filename:  adaption.h
 *
 *    Description:  ��װ�ṩ��ps��������ӿ���
 *
 *        Version:  1.0
 *        Created:  08/10/2009 11:09:56 AM
 *       Revision:  none
 *       Compiler:  g++
 *
 *         Author:  zhangyanjing, 
 *        Company:  
 *
 * =====================================================================================
 */


#ifndef  _ADAPTION_H_
#define  _ADAPTION_H_

#include "dictmgr.h"
#include "adaptor_def.h"

#if !(defined(__x86_64__) || defined(__ia64__) || defined(__amd64__))
#include <string>
#endif

/*
 * =====================================================================================
 *        Class:  Adaption_intf
 *  Description:  
 * =====================================================================================
 */


class Adaption_intf
{
    public:
    
        enum _return_vaule 
        {
            SUCCESS = 0,
            LOAD_FILE_FAIL = -1,
            INPUT_PARAM_ERROR = -2,
            LOAD_DICT_FREQ = -3,
        };				/* ----------  end of enum _return_vaule  ---------- */

        typedef enum _return_vaule return_vaule;
    public:
        /* ====================  LIFECYCLE     ======================================= */
        Adaption_intf (){m_is_init = false;}                             /* constructor      */
        ~Adaption_intf (){}                            /* destructor       */

        /* ====================  ACCESSORS     ======================================= */
        /*
        * Function:  init
        *
        * @brief: ��ʼ��wise�ṩ���������䷽������Ҫ�ڵ�������������ǰ���ó�ʼ������
        *
        * @param [in] : (char *)pfilepath wise�ṩ�����ã����ݵ��ļ����·��
        *
        * @retval : SUCCESS  Ϊ�ɹ�������Ϊʧ��
        */

        int32_t init(char *pfilepath);
        /*
        * Function:  is_mobile_device
        *
        * @brief: ��������ͷ��ip�����wise�����ж��Ƿ�Ϊ�ֻ��ն�
        *
        * @param [in] : (header_info_t *)pstreq_header http����ͷ��ɵĽṹ��  
        * @param [in] : (uint32_t) cip ����ͻ���ip
        *
        * @retval : true  �ж�Ϊ���ֻ��նˣ�falseΪ���ֻ��ն�
        */
        bool is_mobile_device(header_info_t *pstreq_header, uint32_t cip);
        bool is_mobile_device(header_info_t *pstreq_header, char * cip);
		bool is_pad_device(header_info_t *pstreq_header);
    private:
        
        struct header_elem_sort 
        {
           std::string user_agent;
           std::string accept;
           std::string accept_charset;
           std::string accept_encoding;
           std::string accept_language;
           std::string drm_version;
           std::string encoding_version;
           std::string x_nokia_musicshop;
		   char *padaptname[MAX_ITEM_NUM];
        };				/* ----------  end of struct header_elem_sort  ---------- */

        typedef struct header_elem_sort Header_elem_sort;
        /*
        * Function:  build_header_struct
        *
        * @brief: �������ͷ������build��Ϊ����ģ�鴦������
        *
        * @param [in] : (header_info_t *)pstreq_header http����ͷ��ɵĽṹ��  
        * @param [in] : (uint32_t) cip ����ͻ���ip
        *
        * @retval : true  �ж�Ϊ���ֻ��նˣ�falseΪ���ֻ��ն�
        */
        inline int32_t build_header_struct(header_info_t *psthead, header_elem_sort *psort_head);

        inline int32_t user_agent_processer(header_elem_sort *psort_head, bool *need_goon, bool *ret_val );
		inline int32_t pad_user_agent_processor(header_elem_sort *psort_head, bool *need_goon, bool *ret_val);
        inline int32_t wap_ip_filter(uint32_t cip, bool *need_goon, bool *ret_val);
        inline int32_t ucweb_filter(header_elem_sort *psort_head, bool *need_goon, bool *ret_val);
        inline int32_t accept_filter(header_elem_sort *psort_head, bool *need_goon, bool *ret_val);
        inline int32_t black_filter(header_elem_sort *psort_head, bool *need_goon, bool *ret_val);
        inline int32_t sign_filter(header_elem_sort *psort_head, bool *need_goon, bool *ret_val);
		inline int32_t sign_filter2(header_elem_sort *psort_head, bool *need_goon, bool *ret_val);
        inline int32_t wap_ip_filter(char * cip, bool *need_goon, bool *ret_val);

    protected:
        Adaption_intf ( const Adaption_intf &other );   /* copy constructor */
        Adaption_intf& operator = ( const Adaption_intf &other ); /* assignment operator */

    private:
        Dictmgr m_dict; 
        bool    m_is_init;

}; /* -----  end of class Adaption_intf  ----- */


#endif   /* ----- #ifndef _adaption_h__INC  ----- */
