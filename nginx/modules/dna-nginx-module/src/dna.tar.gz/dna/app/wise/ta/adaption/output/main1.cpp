/*
 * $Id: main1.cpp,v 1.4 2009/08/17 06:27:28 zhangyj3 Exp $
 * Description: odict library file
 * Copyright (C) 2004 Baidu.com, Inc. All rights reserved
 */

/*
 * $Id: main1.cpp,v 1.4 2009/08/17 06:27:28 zhangyj3 Exp $
 */

#include <stdio.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include "adaption.h"
#include "adaptor_def.h"

//#include "odict.h"


#define MAX_BUFFER_LEN 1024000
#define IS_ENTERN_CHAR(ch) ((ch)=='\r')
#define IS_LINE_CHAR(ch) ((ch)=='\n')
#define IS_SPACE(ch) ((ch)==' ' || (ch)=='\t' || (ch)=='\r' || (ch)=='\n')
int add_item(header_info_t * headers,char * headerstr,int & cipidx)
{
	if(headers->info_count>=MAX_ITEM_NUM)
		return -1;
	char * pcur = headerstr;
	char * pkey = NULL;
	char * pvalue = NULL;
	while(*pcur && IS_SPACE(*pcur))
		pcur++;
	if(*pcur == 0)
		return -1;
	pkey = pcur;
	while(*pcur && !(IS_SPACE(*pcur) || *pcur == ':'))
		pcur++;
	if(*pcur == 0)
		return -1;
	*pcur = 0;
	pcur++;
	while(*pcur && (IS_SPACE(*pcur) || *pcur== ':'))
		pcur++;
	if(*pcur == 0)
		return -1;
	pvalue = pcur;
	if(strcmp(pkey,"gateway-cip")==0)
		cipidx = headers->info_count;
	headers->request_item_arr[headers->info_count].item_name = pkey;
	headers->request_item_arr[headers->info_count].item_value= pvalue;
	headers->info_count++;
	return headers->info_count;
}
char *TrimString(char *str)
       {
            char    *s, *e;
            if(str == NULL)
              return NULL;
            s = str;

            while (isspace(*s))
            s++;
            e = s + strlen(s);
            if (e > s) {
                 while (isspace(*(--e)))
                                     ;
                    *(++e) = 0;
             }
                                           
            if (s != str)
            memmove(str, s, e - s + 1);

             return str;
        }

int main(int argc, char *argv[])
{
	
    unsigned char       	c = 0;
	
	//char linebuffer[MAX_BUFFER_LEN];
	char resbuffer[MAX_BUFFER_LEN*2];
	header_info_t headers;
	memset(&headers,0,sizeof(header_info_t));
	Adaption_intf adaptor;
	if(0 != adaptor.init("./conf"))
	{
		printf("load adapt data fail! must put data in path:/home/onesearch/domain_adaptor/adapt_data/");
		exit(-1);
	}
	int reslen = 0;
	int cip_idx = 0;
	if(argc == 1)
	{
		reslen = 0;
		while(0 < fgets(resbuffer+reslen,sizeof(resbuffer)-reslen,stdin))
		{
            TrimString(resbuffer+reslen);
		    int len = strlen(resbuffer+reslen);
		    add_item(&headers,resbuffer+reslen,cip_idx);
			reslen += len+1;
		}
			bool ismobile = adaptor.is_mobile_device(&headers,headers.request_item_arr[cip_idx].item_value);
				printf("ADAPTOR RES:%d\n",(int)ismobile);
				for(int i = 0;i<headers.info_count;i++)
				{
					printf("INDATA%d\tkey:%s\tvalue:%s\n",i,headers.request_item_arr[i].item_name,headers.request_item_arr[i].item_value);
				}
				headers.info_count = 0;
				reslen = 0;
                exit(1);

//		unsigned int readlen = 0;	
/*
		while(gets(resbuffer+reslen)!=NULL)
		//w(gets(resbuffer+reslen)!=NULL)
		{
			if(resbuffer[reslen]==0)
			{
				//new group begin
				bool ismobile = adaptor.is_mobile_device(&headers,headers.request_item_arr[cip_idx].item_value);
				printf("ADAPTOR RES:%d\n",(int)ismobile);
				for(int i = 0;i<headers.info_count;i++)
				{
					printf("INDATA%d\tkey:%s\tvalue:%s\n",i,headers.request_item_arr[i].item_name,headers.request_item_arr[i].item_value);
				}
				headers.info_count = 0;
				reslen = 0;
                exit(1);
			}else
			{
				int len = strlen(resbuffer+reslen);
				add_item(&headers,resbuffer+reslen,cip_idx);
				reslen += len+1;
			}
		}
		*/
	}else
	{
		FILE * fp = fopen(argv[1],"r");
		if(fp == NULL)
		{
			printf("open file fail! file:%s",argv[0]);
			exit(-1);
		}
		reslen = 0;
		while(0 < fgets(resbuffer+reslen,sizeof(resbuffer)-reslen,fp))
		{
            TrimString(resbuffer+reslen);
		    int len = strlen(resbuffer+reslen);
		    add_item(&headers,resbuffer+reslen,cip_idx);
			reslen += len+1;
		}
        bool ismobile = adaptor.is_mobile_device(&headers,headers.request_item_arr[cip_idx].item_value);
	    printf("ADAPTOR RES is mobile : %d\n",(int)ismobile);
		bool ispad = adaptor.is_pad_device(&headers);
		printf("ADAPTOR RES is pad : %d\n", (int)ispad);
		for(int i = 0;i<headers.info_count;i++)
		{
			printf("INDATA%d\tkey:%s\tvalue:%s\n",i,headers.request_item_arr[i].item_name,headers.request_item_arr[i].item_value);
		}
		headers.info_count = 0;
		reslen = 0;

	}
    return 0;
}
