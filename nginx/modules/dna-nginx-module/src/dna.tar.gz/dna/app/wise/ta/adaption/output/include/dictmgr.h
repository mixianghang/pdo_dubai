/*
 * =====================================================================================
 *
 *       Filename:  dictmgr.h
 *
 *    Description:  wise�ṩ�������ļ��������ļ�������
 *
 *        Version:  1.0
 *        Created:  08/10/2009 12:02:07 PM
 *       Revision:  none
 *       Compiler:  g++
 *
 *         Author:  zhangyanjing, 
 *        Company:  
 *
 * =====================================================================================
 */


#ifndef  _DICTMGR_H_
#define  _DICTMGR_H_


#include	<map>
#include	<iostream>
#include	"ul_log.h"
#include	"odict.h"
#include	"ul_sign.h"
#include 	"adaptor_def.h"
#include    "adapt_dictstruct.h"
#include	<time.h>

/*
 * =====================================================================================
 *        Class:  Dictmgr
 *  Description:  ʵ�������ļ��������ļ�������Ϊ������̷߳���ʹ��˫buffer�洢�����ļ� 
 * =====================================================================================
 */
class Dictmgr
{
    public:

        enum _dict_return_var 
        {
            SUCCESS = 0,
            LOAD_FILE_FAIL = -1,
            INPUT_PARAM_ERROR = -2,
            INIT_DICT_FAIL = -3,
            DICT_NOT_INIT = -4,
            LOAD_DICT_HIGH_FREQ = -5,
        };
		
        /* ====================  LIFECYCLE     ======================================= */
        Dictmgr ();                             /* constructor      */
        ~Dictmgr ();                            /* destructor       */

        /* ====================  ACCESSORS     ======================================= */
        int32_t       init(const char *pfilepath);
        
        bool    is_in_wap_ip_dict(const char *clientip);
        bool    is_in_ua_white_dict(const char *user_agent);
        bool    is_in_ua_black_dict(const char *user_agent);
        bool    is_in_ua_pattern(const char *user_agent);
		bool	is_in_pad_ua_black_dict(const char *user_agent);
		bool	is_in_pad_ua_white_dict(const char *user_agent);
		bool	is_in_pad_ua_black_pattern(const char *user_agent);
		bool	is_in_pad_ua_white_pattern(const char *user_agent);
        bool    is_in_sign_dict(const char *header_info);
        bool    is_in_black_phone(const char *info);
        bool    is_use_uapattern();
		bool	is_use_pad_black_uapattern();
		bool	is_use_pad_white_uapattern();
		bool    cotinue_while_agent_unmatch();
		bool    adapt_ucweb();
		int32_t GetAdaptHeaderItemNum();
		int32_t GetAgentNameIndex();
		int32_t GetAcceptNameIndex();
		int32_t SearchHeaderNameIndex(char * pname);
    	char * get_ucweb_flag();
        /* ====================  MUTATORS      ======================================= */

        /* ====================  DATA MEMBERS  ======================================= */
    private:
    	bool is_file_changed( char * file, time_t pretime);
		bool is_file_changed( char * path,char * filename, time_t pretime);
		time_t get_file_time(char * file);
		int32_t update_time_stamp(const char * pfilepath);
		char * get_file_name(int fileid);
        int32_t _init(const char *pfilepath);
        inline int32_t load_dict(const char *pfilepath,Dict_struct *pdictdata);
      //  inline int32_t load_conf(const char *pfilepath);

        Dictmgr ( const Dictmgr &other );   /* copy constructor */
        Dictmgr& operator = ( const Dictmgr &other ); /* assignment operator */

        inline void chg_curr_dict();
    //private:
    public:
        Dict_struct *m_cur_dict_group;
        Dict_struct *m_bak_dict_group;
        /*
        time_t       m_sign_dict_refresh_time;
        time_t       m_wap_ip_dict_refresh_time;
        time_t       m_agent_black_dict_refresh_time;
        time_t       m_agent_white_dict_refresh_time;
        time_t       m_phone_black_dict__refresh_time;
        time_t       m_conf_refresh_time;
		*/
		time_t		 m_data_file_update_time[AF_FILE_NUM];
        
        time_t       m_last_refresh_time;/*�ϴ��ļ��仯�ص�ʱ��*/
        bool         m_is_first_init;

}; /* -----  end of class Dictmgr  ----- */

#endif   /* ----- #ifndef dictmgr_INC  ----- */
