#ifndef __ADAPT_DICTENTRY__
#define __ADAPT_DICTENTRY__
#include	<map>
#include	<iostream>
#include	"ul_log.h"
#include	"odict.h"
#include	"ul_sign.h"
#include 	"adaptor_def.h"
#include	"odict.h"
#include	"ul_sign.h"
#include 	<stdio.h>

#if !(defined(__x86_64__) || defined(__amd64__) || defined(__ia64__))
#include	<ctype.h>
#endif

/*
 * =====================================================================================
 *        Class:  Dict_entry
 *  Description:  odict_���ݽڵ����ݷ�װ
 * =====================================================================================
 */
class Dict_entry
{
    public:

        /* ====================  LIFECYCLE     ======================================= */
        Dict_entry (uint32_t hashsize)
        {
            m_odict = odb_creat(hashsize);
        }

        ~Dict_entry ()
        {
            if ( NULL != m_odict ) 
            {
                odb_destroy(m_odict);
            }
        }
    public:
        bool is_valid() const
        {
            return m_odict != NULL;
        }
        operator sodict_build_t* () const
        {
            return m_odict;
        }
		bool isindict(char * keystr)
		{
			if(keystr == NULL || keystr[0] == 0 || m_odict == NULL)
				return false;
			sodict_snode_t snode;
			creat_sign_md64(keystr,strlen(keystr),&(snode.sign1),&(snode.sign2));
			ul_writelog(UL_LOG_DEBUG,"keystr:[%s] sign:%u|%u", keystr, snode.sign1, snode.sign2);
			snode.cuint1 = 0; snode.cuint2 = 0;
			if(odb_seek(m_odict,&snode)==ODB_SEEK_OK)
				return true;
			return false;
		}
		int32_t loaddict(char * path,char * filename)
		{
			if(path == NULL || filename == NULL || path[0] == 0 || filename[0] == 0)
				return -1;
			char pathname[MAX_DIR_LEN];
			snprintf(pathname,sizeof(pathname),"%s/%s",path,filename);
			return loaddict(pathname);
		}
		int32_t loaddict(char * pathname)
		{
			if(!is_valid() || m_odict == NULL || pathname == NULL)
			{
				ul_writelog(UL_LOG_FATAL,"Dict_entry::loaddict dict not valid!");
				return -1;
			}
			if(odb_renew(m_odict)!=ODB_RENEW_OK)
			{
				ul_writelog(UL_LOG_WARNING,"Dict_entry::loaddict renew dict fail!");
				return -1;
			}
			FILE * fp = fopen(pathname,"r");
			char line[ADAPTION_MAX_LINE_LEN];
			if(fp == NULL)
			{
				ul_writelog(UL_LOG_FATAL,"Dict_entry::loaddict open file fail! file:%s %s:%d",pathname,__FILE__,__LINE__);
				return -1;
			}
			sodict_snode_t snode;
			int addnum = 0;
			while(fgets(line,sizeof(line),fp)!= NULL)
			{
				if(line[0] == '#')
				{
					continue;
				}
                char *tmpline = TrimString(line);  
                if ((NULL == tmpline) || line[0] == 0)
                {
                    continue;
                }
				creat_sign_md64(line,strlen(line),&(snode.sign1),&(snode.sign2));
				snode.cuint1 = 0; snode.cuint2 = 0;
				if(odb_add(m_odict,&snode,1) != ODB_ADD_OK)
				{
					ul_writelog(UL_LOG_WARNING,"Dict_entry::loaddict add line fail! line:%s",line);
				}
                if(0 != strstr(pathname,"agent.forps"))
				{
					//ul_writelog(UL_LOG_DEBUG,"line:[%s] sign:%u|%u",line, snode.sign1,snode.sign2);
				}
				addnum++;
			}
			ul_writelog(UL_LOG_NOTICE,"Dict_entry::loaddict load item:%d file:%s",addnum,pathname);
			fclose(fp);
			odb_adjust(m_odict);
			return addnum;
		}
       static inline  char *TrimString(char *str)
        {
            char    *s, *e;
            if(str == NULL)
              return NULL;
            s = str;

            while (isspace(*s))
            s++;
            e = s + strlen(s);
            if (e > s) {
                 while (isspace(*(--e)))
                                     ;
                    *(++e) = 0;
             }
                                           
            if (s != str)
            memmove(str, s, e - s + 1);
            return str;
        }
       static inline int32_t str_to_lower(char* str)
       {
            static char diff = 'a' - 'A';
            while (*str) 
            {
                if (*str >= 'A' && *str <= 'Z') 
                {
                     *str += diff;
                }
                str++;
            }
            return 0;
       }
    private:
        Dict_entry& operator = ( const Dict_entry &other ); /* assignment operator */
        Dict_entry ( const Dict_entry &other );   /* copy constructor */
    private:
        sodict_build_t *m_odict;

}; /* -----  end of class Dict_entry  ----- */

#endif

