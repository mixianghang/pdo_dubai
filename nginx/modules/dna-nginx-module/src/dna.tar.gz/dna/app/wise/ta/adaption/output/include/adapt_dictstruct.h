#ifndef __ADAPT_DICTSTRUCT_H__
#define __ADAPT_DICTSTRUCT_H__
#include 	"adapt_dictentry.h"
#include 	"adapt_conf.h"
#include 	"adaptor_def.h"
#include 	"ul_log.h"
#include    "ul_dictmatch.h"
#include	<string.h>

#define MAX_UA_NUM 200
/*
 * =====================================================================================
 *        Class:  Dict_struct
 *  Description:  
 * =====================================================================================
 */
class Dict_struct
{
    public:
        /* ====================  LIFECYCLE     ======================================= */
        Dict_struct ()                             /* constructor      */
        {
            m_sign_dict = NULL;
            m_agent_white_dict = NULL;
            m_agent_black_dict = NULL;
            m_wap_ip_dict = NULL;
            m_sign_black_dict = NULL;
            m_conf = NULL;
			m_initd = false;
            m_ua_dmdict = NULL;

			//pad����ֵ�
			m_pad_agent_white_dict = NULL;
			m_pad_agent_black_dict = NULL;
			m_pad_ua_white_dmdict  = NULL;
			m_pad_ua_black_dmdict  = NULL;
        }
        ~Dict_struct ()                            /* destructor       */
        {
           
            
            if ( NULL != m_agent_white_dict ) 
            {
                delete m_agent_white_dict;
                m_agent_white_dict = NULL;
            }

            if ( NULL != m_agent_black_dict ) 
            {
                delete m_agent_black_dict;
                m_agent_black_dict = NULL;
            }
            
            if ( NULL != m_wap_ip_dict) 
            {
                delete m_wap_ip_dict;
                m_wap_ip_dict = NULL;
            }
            
            if ( NULL != m_sign_black_dict ) 
            {
                delete m_sign_black_dict;
                m_sign_black_dict = NULL;
            }

            if ( NULL != m_sign_dict ) 
            {
                delete m_sign_dict;
                m_sign_dict = NULL;
            }
			if ( NULL != m_conf )
			{
				delete m_conf;
				m_conf = NULL;
			}
            if (NULL != m_ua_dmdict)
            {
                delete m_ua_dmdict;
                m_ua_dmdict = NULL;
            }
			if ( NULL != m_pad_agent_white_dict)
			{
				delete m_pad_agent_white_dict;
				m_pad_agent_white_dict = NULL;
			}
			if ( NULL != m_pad_agent_black_dict)
			{
				delete m_pad_agent_black_dict;
				m_pad_agent_black_dict = NULL;
			}
			if ( NULL != m_pad_ua_black_dmdict)
			{
				delete m_pad_ua_black_dmdict;
				m_pad_ua_black_dmdict = NULL;
			}
			if ( NULL != m_pad_ua_white_dmdict)
			{
				delete m_pad_ua_white_dmdict;
				m_pad_ua_white_dmdict = NULL;
			}
			m_initd = false;
        }
        int32_t init()
        {
            m_sign_dict = new (std::nothrow) Dict_entry(DEFAULT_DICT_HASH); 
            if ( NULL == m_sign_dict ) 
            {
                goto error;
            }
            m_agent_white_dict = new (std::nothrow) Dict_entry(DEFAULT_DICT_HASH);
            if ( NULL == m_agent_white_dict ) 
            {
                goto error;
            }
            m_agent_black_dict = new (std::nothrow) Dict_entry(DEFAULT_DICT_HASH);
            if ( NULL == m_agent_black_dict ) 
            {
                goto error;
            }
            m_wap_ip_dict = new (std::nothrow) Dict_entry(DEFAULT_DICT_HASH);
            if ( NULL == m_wap_ip_dict ) 
            {
                goto error;
            }
            m_sign_black_dict = new (std::nothrow) Dict_entry(DEFAULT_DICT_HASH);
            if ( NULL == m_sign_black_dict ) 
            {
                goto error;
            }
           
			m_conf = new (std::nothrow) Conf_entry();
            if ( NULL == m_conf ) 
            {
                goto error;
            }
            m_ua_dmdict = dm_dict_create(MAX_UA_NUM);
            if (NULL == m_ua_dmdict)
            {
                goto error;
            }
			m_pad_agent_white_dict = new (std::nothrow) Dict_entry(DEFAULT_DICT_HASH);
			if ( NULL == m_pad_agent_white_dict )
			{
				goto error;
			}
			m_pad_agent_black_dict = new (std::nothrow) Dict_entry(DEFAULT_DICT_HASH);
			if ( NULL == m_pad_agent_black_dict )
			{
				goto error;
			}
			m_pad_ua_white_dmdict = dm_dict_create(MAX_UA_NUM);
			if ( NULL == m_pad_ua_white_dmdict )
			{
				goto error;
			}
			m_pad_ua_black_dmdict = dm_dict_create(MAX_UA_NUM);
			if ( NULL == m_pad_ua_black_dmdict )
			{
				goto error;
			}
			m_initd = true;
            return 0;
error:
            return -1;
           
        }
		bool is_inited()
		{
			return m_initd;
		}
		int32_t LoadDict(char * filepath)
		{
			if(!m_initd || filepath == NULL || filepath[0] == 0)
			{
				return -1;
			}

			char pathname[MAX_DIR_LEN];
			snprintf(pathname,sizeof(pathname),"%s",filepath);
			pathname[MAX_DIR_LEN - 1] = '\0';

			if(m_conf->LoadConf(pathname,CONF_FILE_NAME)<0)
			{
				ul_writelog(UL_LOG_WARNING,"Dict_sturct::LoadDict load conf fail! path:%s file:%s",pathname,CONF_FILE_NAME);
				return -1;
			}
			if(m_sign_dict->loaddict(pathname,HEADER_SIGN_FILE_NAME)<0)
			{
				ul_writelog(UL_LOG_WARNING,"Dict_sturct::LoadDict load signdict fail! path:%s file:%s",pathname,HEADER_SIGN_FILE_NAME);
				return -1;
			}
			if(m_sign_black_dict->loaddict(pathname,BLACK_HEADER_SIGN_FILE_NAME)<0)
			{
				ul_writelog(UL_LOG_WARNING,"Dict_sturct::LoadDict load black header dict fail! path:%s file:%s",pathname,BLACK_HEADER_SIGN_FILE_NAME);
				return -1;
			}
			if(m_agent_white_dict->loaddict(pathname,AGENT_FILE_NAME)<0)
			{
				ul_writelog(UL_LOG_WARNING,"Dict_sturct::LoadDict load agentdict fail! path:%s file:%s",pathname,AGENT_FILE_NAME);
				return -1;
			}
			if(m_agent_black_dict->loaddict(pathname,BLACK_AGENT_FILE_NAME)<0)
			{
				ul_writelog(UL_LOG_WARNING,"Dict_sturct::LoadDict load black agentdict fail! path:%s file:%s",pathname,BLACK_AGENT_FILE_NAME);
				return -1;
			}
			if(m_wap_ip_dict->loaddict(pathname,GATEWAY_IP_FILE_NAME)<0)
			{
				ul_writelog(UL_LOG_WARNING,"Dict_sturct::LoadDict load gateway ip dict fail! path:%s file:%s",pathname,GATEWAY_IP_FILE_NAME);
				return -1;
			}
			if(m_pad_agent_black_dict->loaddict(pathname,PAD_BLACK_AGENT_FILE_NAME)<0)
			{
				ul_writelog(UL_LOG_WARNING,"Dict_sturct::LoadDict load pad black agentdict fail! path:%s file:%s",pathname,PAD_BLACK_AGENT_FILE_NAME);
				return -1;
			}
			if(m_pad_agent_white_dict->loaddict(pathname,PAD_WHITE_AGENT_FILE_NAME)<0)
			{
				ul_writelog(UL_LOG_WARNING,"Dict_sturct::LoadDict load pad white agentdict fail! path:%s file:%s",pathname,PAD_WHITE_AGENT_FILE_NAME);
				return -1;
			}
            int32_t uaret = load_ua_pattern(pathname, UA_PATTERN_FILE_NAME, m_ua_dmdict);
            if (uaret != 0)
            {
                return -1;
            }
            uaret = load_ua_pattern(pathname, PAD_UA_PATTERN_WHITE_FILE_NAME, m_pad_ua_white_dmdict);
            if (uaret != 0)
            {
                return -1;
            }           
			uaret = load_ua_pattern(pathname, PAD_UA_PATTERN_BLACK_FILE_NAME, m_pad_ua_black_dmdict);
            if (uaret != 0)
            {
                return -1;
            }
			return 1;
			
		}
        /* ====================  DATA MEMBERS  ======================================= */
        Dict_entry *m_sign_dict;
        Dict_entry *m_agent_white_dict;
        Dict_entry *m_agent_black_dict;
        Dict_entry *m_wap_ip_dict;
        Dict_entry *m_sign_black_dict;
        dm_dict_t  *m_ua_dmdict; /*���uaƥ���ַ���*/
		Dict_entry *m_pad_agent_white_dict;
		Dict_entry *m_pad_agent_black_dict;
		dm_dict_t  *m_pad_ua_white_dmdict;
		dm_dict_t  *m_pad_ua_black_dmdict;
        //ulconf_data_t *m_confptr;

        uint32_t   ua_pattern_num;
		Conf_entry *m_conf;
		bool m_initd;
    private:
        Dict_struct& operator = ( const Dict_struct &other ); /* assignment operator */
        Dict_struct ( const Dict_struct &other );   /* copy constructor */

        int32_t load_ua_pattern(const char *filepath, const char *filename, dm_dict_t * &ua_dmdict)
        {
            if((NULL == filepath) || (NULL == filename))
            {
                return -1;
            }
            /*�ͷŵ�ԭ����dict�ִ�*/
            if (ua_dmdict != NULL)
            {
                dm_dict_del(ua_dmdict);
                ua_dmdict =  NULL;
            }

			ua_dmdict = dm_dict_create(MAX_UA_NUM);
			if(ua_dmdict == NULL)
			{
				return -1;
			}
            char pathname[MAX_DIR_LEN];
			snprintf(pathname,MAX_DIR_LEN,"%s/%s",filepath,filename);

        	FILE * fp = fopen(pathname,"r");
			char line[ADAPTION_MAX_LINE_LEN];
			if(fp == NULL)
			{
				ul_writelog(UL_LOG_FATAL,"load ua parttern fail, open file fail! file:%s %s:%d",pathname,__FILE__,__LINE__);
				return -1;
			}
			while(fgets(line,sizeof(line),fp)!= NULL)
			{
				if(line[0] == '#')
				{
					continue;
				}
                char *tmpline = Dict_entry::TrimString(line);  

                dm_lemma_t str_elem;
                str_elem.len = strlen(tmpline);
                str_elem.pstr = tmpline;
                str_elem.prop = 1;
                
                int32_t ret = dm_add_lemma(ua_dmdict, &str_elem);
                if (-1 == ret)
                {
			        ul_writelog(UL_LOG_NOTICE,"add ua pattern fail ua=%s" , tmpline);
                }
			}
			ul_writelog(UL_LOG_NOTICE,"load ua pattern file:%s line:%s" , pathname, line);
			fclose(fp);
            return 0;
        }
        public:
        bool ua_pattern_find(const char *user_agent, dm_dict_t * ua_dmdict)
        {
            if(NULL == user_agent
					|| ua_dmdict == NULL)
            {
                return false;
            }
            char buffer[1024];
			strncpy(buffer, user_agent, 1024);
			buffer[1023] = '\0';
			if(strlen(buffer) >= 1023)
			{
				return false;
			}
            Dict_entry::str_to_lower(buffer);

            dm_pack_t *find_pack = dm_pack_create(50);
            if (NULL == find_pack)
            {
                return false;
            }

            dm_search(ua_dmdict, find_pack, buffer, strlen(buffer));
            if (find_pack->ppseg_cnt > 0)
            {
                dm_pack_del(find_pack);
                return true;
            }
            dm_pack_del(find_pack);
            return false;
        }

}; /* -----  end of class Dict_struct  ----- */

#endif
