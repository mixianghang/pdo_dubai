#ifndef __ADAPT_CONF_H__
#define __ADAPT_CONF_H__
#include	<map>
#include	<iostream>
#include	"ul_log.h"
#include	"odict.h"
#include	"ul_sign.h"
#include 	"adaptor_def.h"
#include	"ul_conf.h"

#if !(defined(__x86_64__) || defined(__amd64__) || defined(__ia64__))
#include	<string>
#endif

/*
 * =====================================================================================
 *        Class:  Conf_entry
 *  Description:  �����ļ���װ
 * =====================================================================================
 */
class Conf_entry
{
    public:

        /* ====================  LIFECYCLE     ======================================= */
        Conf_entry ()
        {
           
			continue_while_agent_unmatch = false;
			adapt_ucweb = true;
			pnamedict = NULL;
			headernamenum = 0;
			ucwebflag = "ss/";
			agentheaderindex = -1;
			acceptheaderindex = -1;
            is_use_uapattern = 0;
			is_use_pad_black_uapattern = 0;
			is_use_pad_white_uapattern = 0;
       }
		
      
    public:
		int strToLower(char* str)
		{
			static char diff = 'a' - 'A';
			bool isch = false;
			while (*str) 
			{
				if(isch)
				{
					//str++;
					isch = false;
					//continue;
				}else if(IS_CHN(*str))
				{
					isch = true;
				}else if (*str >= 'A' && *str <= 'Z') 
				{

					*str += diff;

				}

				str++;

			}
			return 0;
		}
	   int32_t ParseNameStr(char * name, sodict_build_t * pdict,int idx)
	   	{
	   		if(name == NULL || name[0] == 0 || pdict == NULL || idx<0 || idx>=MAX_ITEM_NUM)
				return -1;
			char * pflag = NULL;
			char * pdelim = " ";
			char * pname = strtok_r(name,pdelim,&pflag);
			int addnum = 0;
			while(pname != NULL)
			{
				strToLower(pname);
				sodict_snode_t snode;
				creat_sign_md64(pname,strlen(pname),&(snode.sign1),&(snode.sign2));
				snode.cuint1 = idx; snode.cuint2 = 0;
				if(odb_add(pdict,&snode,1) != ODB_ADD_OK)
				{
					ul_writelog(UL_LOG_WARNING,"Adapt_conf::ParseNameStr add fail! str:%s idx:%d",pname,idx);
				}else
				{
					addnum++;
				}
				pname = strtok_r(NULL,pdelim,&pflag);
			}
			return addnum;
	   	}
       int32_t LoadConf(char * confpath,char * conffile)
       {
       		if(confpath == NULL || confpath[0] == 0 || conffile == NULL || conffile[0] == 0)
				return -1;
			Ul_confdata *pcf = NULL;
			pcf = ul_initconf(CONF_NUM);
			if(pcf == NULL )
			{
				ul_writelog(UL_LOG_FATAL,"Conf_entry::LoadConf initconf fail! %s:%d",__FILE__,__LINE__);
				return -1;
			}
			int ret = ul_readconf(confpath,conffile, pcf);
			if(ret <0)
			{
				ul_writelog(UL_LOG_FATAL,"Conf_entry::LoadConf raed conf file fail! path:%s file:%s %s:%d",
					confpath,conffile,__FILE__,__LINE__);
				return -1;
			}
			int confint = 0;
			continue_while_agent_unmatch = false;
			if(ul_getconfint(pcf,"CONTINUE_WHILE_AGENT_UNMATCH",&confint))
			{
				if(confint != 0)
				{
					continue_while_agent_unmatch = true;;
				}
			}

            if(ul_getconfint(pcf,"IS_USE_UAPATTERN",&is_use_uapattern))
			{
				if(is_use_uapattern != 0 && is_use_uapattern != 1)
				{
					is_use_uapattern = 0;
				}
			}
            if(ul_getconfint(pcf,"IS_USE_PAD_BLACK_UAPATTERN",&is_use_pad_black_uapattern))
			{
				if(is_use_pad_black_uapattern != 0 && is_use_pad_black_uapattern != 1)
				{
					is_use_pad_black_uapattern = 0;
				}
			}           
			if(ul_getconfint(pcf,"IS_USE_PAD_WHITE_UAPATTERN",&is_use_pad_white_uapattern))
			{
				if(is_use_pad_white_uapattern != 0 && is_use_pad_white_uapattern != 1)
				{
					is_use_pad_white_uapattern = 0;
				}
			}           
			adapt_ucweb = true;
			if(ul_getconfint(pcf,"ADAPT_UCWEB",&confint))
			{
				if(confint == 0)
				{
					adapt_ucweb = false;;
				}
			}
			//load ucweb flag
			char tmpflag[MAX_HEADER_NAME_LEN];
			if(ul_getconfstr(pcf,"UCWEB_FLAG",tmpflag))
			{
				if(tmpflag[0] != 0)
				{
					ucwebflag = tmpflag;
				}
			}
			//agent header index
			agentheaderindex = -1;
			if(!ul_getconfint(pcf,"AGENT_HEADER_NAME_INDEX",&confint))
			{
				ul_writelog(UL_LOG_WARNING,"Conf_entry::LoadConf AGENT_HEADER_NAME_INDEX unspecified!");
				ul_freeconf(pcf);
				return -1;
			}
            agentheaderindex = confint; 
			//accept header index
			acceptheaderindex = -1;
			if(!ul_getconfint(pcf,"ACCEPT_HEADER_NAME_INDEX",&confint))
			{
				ul_writelog(UL_LOG_WARNING,"Conf_entry::LoadConf ACCEPT_HEADER_NAME_INDEX unspecified!");
				ul_freeconf(pcf);
				return -1;
			}
            acceptheaderindex  = confint;
			//load header dict
			if(!ul_getconfint(pcf,"ADAPT_HEADER_NUM",&confint))
			{
				ul_writelog(UL_LOG_WARNING,"Conf_entry::LoadConf ADAPT_HEADER_NUM unspecified!");
				ul_freeconf(pcf);
				return -1;
			}
			if(confint<0)
			{
				confint = 0;
			}
            headernamenum = confint;
			if(pnamedict == NULL)
			{
				pnamedict = odb_creat(MAX_ITEM_NUM*5);
				if(pnamedict == NULL)
				{
					ul_writelog(UL_LOG_WARNING,"Conf_entry::LoadConf create namedict fail! hash:%d",MAX_ITEM_NUM*5);
					ul_freeconf(pcf);
					return -1;
				}
			}else
			{
				odb_renew(pnamedict);
			}
			char confvalue[MAX_CONF_VALUE_LEN];
			char confname[MAX_CONF_NAME_LEN];
			for(int i = 0; i<headernamenum; i++)
			{
				snprintf(confname,sizeof(confname),"ADAPT_HEADER_NAME%d",i);
				confvalue[0] = 0;
				if(!ul_getconfstr(pcf,confname,confvalue))
				{
					ul_writelog(UL_LOG_WARNING,"Conf_entry::LoadConf header name conf:%s unspecified",confname);
					ul_freeconf(pcf);
					return -1;
				}
				if(confvalue[0] == 0)
				{
					ul_writelog(UL_LOG_WARNING,"Conf_entry::LoadConf header name conf:%s is empty",confname);
					return -1;
				}
				int addnum = ParseNameStr(confvalue,pnamedict,i);
				ul_writelog(UL_LOG_DEBUG,"Adapt_conf::LoadConf header conf:%s name num:%d",confname,addnum);
				
			}
			ul_freeconf(pcf);
			return 1;
       }
    public: const char * GetUcwebFlag()
	   {
	   		return ucwebflag.c_str();
	   }
    public: int32_t SearchHeaderNameIndex(char * headername)
	   {
	   		if(headername == NULL || headername[0] == 0 || pnamedict == NULL)
				return -1;
			char tmpname[MAX_HEADER_NAME_LEN];
			strncpy(tmpname,headername,MAX_HEADER_NAME_LEN);
			tmpname[MAX_HEADER_NAME_LEN-1] = 0;
			strToLower(tmpname);
			sodict_snode_t snode;
			creat_sign_md64(tmpname,strlen(tmpname),&(snode.sign1),&(snode.sign2));
			snode.cuint1 = 0; snode.cuint2 = 0;
			if(odb_seek(pnamedict,&snode) == ODB_SEEK_OK)
			{
				return snode.cuint1;
			}
			return -1;
	   }
       
    private:
      //  Dict_entry& operator = ( const Conf_entry &other ); /* assignment operator */
      //  Conf_entry ( const Conf_entry &other );   /* copy constructor */
    public:
       	
		bool continue_while_agent_unmatch;
		bool adapt_ucweb;
		sodict_build_t * pnamedict;
		int32_t headernamenum;
		int32_t agentheaderindex;
		int32_t acceptheaderindex;
        int32_t is_use_uapattern; /*�Ƿ�����ua pattern����*/
        int32_t is_use_pad_black_uapattern; /*�Ƿ�����pad ua black pattern����*/
        int32_t is_use_pad_white_uapattern; /*�Ƿ�����pad ua white pattern����*/
		std::string ucwebflag;

}; /* -----  end of class Dict_entry  ----- */



#endif
