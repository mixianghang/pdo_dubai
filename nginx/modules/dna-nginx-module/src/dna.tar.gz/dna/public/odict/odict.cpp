/*
 * $Id: odict.cpp,v 1.32.6.1 2008/07/18 06:14:51 yingxiang Exp $
 * Description: odict library file
 * Copyright (C) 2004 Baidu.com, Inc. All rights reserved
 */
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#include <ul_conf.h>
#include <ul_log.h>
#include <ul_func.h>
#include <ul_file.h>

#include "odict.h"

// block settings
#define ODB_MID_NODE_NUM             (4*1024)    // node number for block i/o
#define ODB_NODE_BLOCK_NUM           (256*1024)  // node number in node block
#define ODB_IO_BUFFSIZE		     (4*1024*1024)    // i/o buffer
// default hash number
#define ODB_DEFAULT_HASH_NUM         1000000



// node in memory(for inner use by odict library)
typedef struct _sodict_bnode_t {
    unsigned int   sign1;  // signature 1
    unsigned int   sign2;  // signature 2
    unsigned int   cuint1; // custom data
    unsigned int   cuint2; // custom data
    struct  _sodict_bnode_t *next;   //next node
}   sodict_bnode_t;


// hash table structure
typedef struct _sodict_bhash_t {
    sodict_bnode_t *pnode; //hash table
} sodict_bhash_t;


// block used to save nodes
typedef struct _sodict_bnode_block_t {
    sodict_bnode_t        nodes[ODB_NODE_BLOCK_NUM];  // block of nodes, for build
    _sodict_bnode_block_t *next;                  // next block
} sodict_bnode_block_t;

// dictionary object definition
typedef struct _sodict_build_t{
    int hash_num;       // number of hash
    int node_num;       // number of nodes
    int cur_code;       // current operation count(by caller)

    sodict_bhash_t         *hash;            // hash table

    sodict_bnode_block_t   *nblock;          // first block
    sodict_bnode_block_t   *cur_nblock;      // current block
    int                    node_avail;       // avail node_num in cur_b

    sodict_bnode_t         *cur_node;        // current node for use
}   sodict_build_t;

// dictionary object definition of only search
typedef struct _sodict_search_t{
    int hash_num;   // number of hash
    int node_num;   // number of nodes
    int cur_code;   // current operation count

    unsigned int    *hash;  // hash table
    unsigned int    *num;   // number of nodes in hash entries
    sodict_snode_t  *node;  // nodes
}sodict_search_t;


/* form the full path string according path and filename */
static int odbi_cmps_path(const char *path, const char *filename, char *buffer, int bufsize)
{
    int len1, len2;

    assert(path);
    assert(filename);
    assert(buffer);

    buffer[0] = '\0';
    len1 = strlen(path);
    len2 = strlen(filename);
    if (len1 + len2 + 2 > bufsize)
	return -1;

    strcpy(buffer, path);
    if (*(buffer + len1 - 1) != '/')
	strcat(buffer, "/");
    strcat(buffer, filename);

    return 0;
}

/*path����Ϊ�գ�filename����Ϊ��,0�����ڣ�1����*/
static int is_file_exist(const char *path,const char *filename)
{
    char full_path[PATH_SIZE];
    struct stat statbuf;
    if (filename == NULL){
	return 0;
    }
    if (path == NULL || strlen(path) == 0){
	snprintf (full_path,sizeof(full_path),"%s",filename);
    }
    else if (path[strlen(path)-1] == '/'){
	snprintf (full_path,sizeof(full_path),"%s%s",path,filename);
    }
    else{
        snprintf(full_path, sizeof(full_path),"%s/%s", path, filename);
    }
    if(stat(full_path,&statbuf)==-1){
	return 0;
    }
    if(!S_ISREG(statbuf.st_mode)){
	return 0;
    }
    return 1;
}

/* check whether all the specified dictionary files exist */
static int odbi_is_dictionary_valid(const char *path, const char *filename)
{
    char    tname[PATH_SIZE];

    snprintf(tname, sizeof(tname), "%s.n", filename);
    if (is_file_exist(path,tname) != 1){
	return 0;
    }
    snprintf(tname, sizeof(tname),"%s.ind1", filename);
    if (is_file_exist(path,tname) != 1){
	return 0;
    }
    snprintf(tname, sizeof(tname),"%s.ind2", filename);
    if (is_file_exist(path,tname) != 1){
	return 0;
    }

    return 1;
}

/* check whether the specified dictionary files exist */
static int odbi_is_dictionary_exist(const char *path, const char *filename)
{
    char    tname[PATH_SIZE];

    snprintf(tname, sizeof(tname), "%s.n", filename);
    if (is_file_exist(path,tname) == 1){
	return 1;
    }
    snprintf(tname, sizeof(tname),"%s.ind1", filename);
    if (is_file_exist(path,tname) == 1){
	return 1;
    }
    snprintf(tname, sizeof(tname),"%s.ind2", filename);
    if (is_file_exist(path,tname) == 1){
	return 1;
    }

    return 0;
}

/* check whether it is a deleted node */
static int odbi_is_node_deleted(sodict_bnode_t *node)
{
    if (node->sign1 == 0 && node->sign2 == 0)
	return 1;
    else
	return 0;
}

int odbi_read(int fno, void *data, size_t len)
{
    ssize_t rsize = 0;
    ssize_t lsize = 0;
    if (data == NULL || fno < 0) {
	return -1;
    }
    char *ptr = (char *)data;
  
    while(len > 0) {
	rsize = (len<ODB_IO_BUFFSIZE)?len:ODB_IO_BUFFSIZE;
	lsize = ul_read(fno, ptr, rsize);
	if (lsize < 0 || lsize != rsize) {
	    return -1;
	}
	ptr += lsize;
	len -= lsize;
	
    }
    return 0;
}


/*
 * Create a dictionary object, and allocate enough memory buffer, set the hash number of the dictionary
 * object as hash_num if hash_num is more than zero, or the hash number will be set as the default hash
 * number ODB_DEFAULT_HASH_NUM.
 *
 * If create the dictionary successfully, return the dictionary object, or return NULL
 *
 * The result dictionary can be used as the parameter when calling odb_* functions(such as odb_add).
 */
sodict_build_t *odb_creat(int hash_num)
{
    sodict_build_t       *pdb = NULL;
    sodict_bhash_t       *phash = NULL;
    sodict_bnode_block_t *pblock = NULL;

    if (hash_num <= 0)
	hash_num = ODB_DEFAULT_HASH_NUM;

    /* creat dictionary structure */
    if((pdb = (sodict_build_t*)ul_malloc(sizeof(sodict_build_t))) == NULL){
	ul_writelog(UL_LOG_WARNING, "[ODICT ERROR] cannot allocate memory for dictionary object[%zu].",
		sizeof(sodict_build_t));
	return NULL;
    }

    if((phash = (sodict_bhash_t*)ul_calloc(1, hash_num*sizeof(sodict_bhash_t))) == NULL){
	ul_writelog(UL_LOG_WARNING, "[ODICT ERROR] cannot mallocate memory for hash table[%zu].",
		(hash_num*sizeof(sodict_bhash_t)));
	ul_free(pdb);
	return NULL;
    }
    if((pblock = (sodict_bnode_block_t*)ul_calloc(1, sizeof(sodict_bnode_block_t)))==NULL){
	ul_writelog(UL_LOG_WARNING, "[ODICT ERROR] cannot mallocate memory for node buffer[%zu].",
		sizeof(sodict_bnode_block_t));
	ul_free(pdb);
	ul_free(phash);
	return NULL;
    }

    /* initalize the dictionary object */
    pdb->hash_num = hash_num;
    pdb->cur_code = 0;

    pdb->node_num = 0;
    pdb->hash = phash;
    pdb->nblock = pblock;
    pdb->cur_nblock = pdb->nblock;
    pdb->cur_node = pdb->nblock->nodes;
    pdb->node_avail = ODB_NODE_BLOCK_NUM;

    /* return */
    return pdb;
}

/*
 * Create a search dictionary object, the same as odb_creat.
 */
sodict_search_t *odb_creat_search(int hash_num, int node_num)
{
    sodict_search_t  *pds = NULL;

    /* create the dictionary for searcher */
    if((pds = (sodict_search_t* )ul_calloc(1, sizeof(sodict_search_t))) == NULL){
	ul_writelog(UL_LOG_WARNING,"[ODICT ERROR] cannot create the search dictionary object.");
	return NULL;
    }

    pds->hash_num = hash_num;
    pds->node_num = node_num;
    pds->cur_code = 0;
    if((pds->hash = (unsigned int* )ul_malloc(hash_num*sizeof(int))) == NULL){
	ul_free(pds);
	return NULL;
    }
    if((pds->num = (unsigned int* )ul_malloc(hash_num*sizeof(int))) == NULL){
	ul_free(pds->hash);
	ul_free(pds);
	return NULL;
    }

    if((pds->node = (sodict_snode_t*)ul_malloc(node_num*sizeof(sodict_snode_t))) == NULL){
	ul_free(pds->hash);
	ul_free(pds->num);
	ul_free(pds);
	return NULL;
    }

    /* return */
    return pds;
}


/*
 * Create a dictionary object as the function odb_creat and fill the created dictionary with all the nodes
 * saved in the file specified by path and filename.
 *
 * If hash_num is more than zero, the hash number of the created dictionary will be set as has_num, or
 * the hash number of the created dictionary will be set as the has number saved in the file specified by
 * path and filename.
 *
 * If the file specified by path and filename does not exist, nothing will happen except that
 * ODB_LOAD_NOT_EXISTS is returned.
 * If the dictionary object is created successfully and the data is loaded successfully, it returns
 * the created dictionary object, or NULL is returned.
 */
sodict_build_t *odb_load(char *path, char *filename, int hash_num)
{
    int on_num, n_num = 0;
    int snode = sizeof(sodict_snode_t);
    int full_size = ODB_MID_NODE_NUM * snode;
    int rnum, rsize, i;
    int fno;
    size_t ind2_size = 0;

    sodict_build_t *pdb;
    sodict_snode_t sn[ODB_MID_NODE_NUM];

    char    tname[PATH_SIZE];
    char    fullpath[PATH_SIZE];

    assert(path != NULL);
    assert(filename != NULL);
    
    if (strlen(path) >= sizeof(tname)-2){
	ul_writelog(UL_LOG_WARNING, "[ODICT ERROR] odb_load path:%s too long",path);
	return NULL;
    }
    strcpy(tname,path);
    if (tname[strlen(tname)-1] != '/'){
         strcat(tname,"/");
    }
    // check the file does exist or not
    if (!odbi_is_dictionary_valid(tname, filename)){
	ul_writelog(UL_LOG_WARNING, "[ODICT ERROR] dictionary %s/%s does not exist.", tname, filename);
	return (sodict_build_t *)ODB_LOAD_NOT_EXISTS;
    }

    /* read hash number from file if need */
    if (hash_num <= 0){
	if(ul_readnum_oneint(tname, filename, "hash_num", &hash_num) != 1) {
	    ul_writelog(UL_LOG_WARNING, "[ODICT ERROR] read hash number from %s/%s.n failed.", tname, filename);
	    return NULL;
	}
    }
    if(ul_readnum_oneint(tname, filename, "node_num", &on_num) != 1) {
	ul_writelog(UL_LOG_WARNING,"[ODICT ERROR] read node number from %s/%s.n failed.", tname, filename);
	return NULL;
    }

    /* creat dictionary object */
    if ((pdb = odb_creat(hash_num)) == NULL) {
	ul_writelog(UL_LOG_WARNING,"[ODICT ERROR] cannot create the dictionary object by odb_creat.");
	return NULL;
    }

    /* read items from file */
    sprintf(tname, "%s.ind2", filename);
    ind2_size = ul_fsize(path,tname);
    if(ind2_size != on_num*sizeof(sodict_snode_t))
    {
	ul_writelog(UL_LOG_WARNING, "[ODICT ERROR] check ind2 size error!want[%zu] real[%zu]",
	       	on_num*sizeof(sodict_snode_t),ind2_size);
	odb_destroy(pdb);
	return NULL;
    }
    odbi_cmps_path(path, tname, fullpath, PATH_SIZE);
    if((fno = ul_open(fullpath, O_RDONLY, 0644)) == -1) {
	ul_writelog(UL_LOG_WARNING, "[ODICT ERROR] cannot open file %s.", fullpath);
	odb_destroy(pdb);
	return NULL;
    }

    while((rsize = ul_read(fno, sn, full_size)) > 0){
	rnum = rsize/snode;
	for (i = 0; i < rnum; i++){
	    if (ODB_ADD_ERROR == odb_add(pdb, &(sn[i]), 1)) {
		ul_writelog(UL_LOG_WARNING, "[ODICT ERROR] cannot insert node into dictionary.");
		odb_destroy(pdb);
		ul_close(fno);
		return NULL;
	    }
	}
	n_num += rnum;
    }

    if (n_num != on_num){
	ul_writelog(UL_LOG_WARNING, "[ODICT WARNING] node number error[%d != %d].", n_num, on_num);
    }

    /* close file */
    ul_close(fno);

    /* return */
    return pdb;
}

/*
 * It is the same as odb_load except that odb_load_search creates a dictionary only for searching.
 */
sodict_search_t *odb_load_search(char *path, char *filename)
{
    int fno;
    int hash_num, node_num;

    char    tname[PATH_SIZE];
    char    fullpath[PATH_SIZE];
    size_t ind1_size = 0;
    size_t ind2_size = 0;
    sodict_search_t    *pds = NULL;

    assert(path != NULL);
    assert(filename != NULL);
    if (strlen(path) >= sizeof(tname)-2){
	ul_writelog(UL_LOG_WARNING, "[ODICT ERROR] odb_load path:%s too long",path);
	return NULL;
    }
    strcpy(tname,path);
    if (tname[strlen(tname)-1] != '/'){
        strcat(tname,"/");
    }
    // check the file does exist or not
    if (!odbi_is_dictionary_valid(tname, filename)){
	ul_writelog(UL_LOG_WARNING, "[ODICT ERROR] dictionary %s/%s does not exist.", tname, filename);
	return (sodict_search_t *)ODB_LOAD_NOT_EXISTS;
    }

    /* read num from file */
    if(ul_readnum_oneint(tname, filename, "hash_num", &hash_num) != 1){
	ul_writelog(UL_LOG_WARNING, "[ODICT ERROR] read hash number from %s/%s.n failed.", tname, filename);
	return NULL;
    }
    if(ul_readnum_oneint(tname, filename, "node_num", &node_num) != 1){
	ul_writelog(UL_LOG_WARNING, "[ODICT ERROR] read node number from %s/%s.n failed.", tname, filename);
	return NULL;
    }

    /* create the dictionary for searcher */
    if ((pds = odb_creat_search(hash_num, node_num)) == NULL){
	ul_writelog(UL_LOG_WARNING,"[ODICT ERROR] cannot create the dictionary object by odb_creat_search.");
	return NULL;
    }

    /* read data from file */
    snprintf(tname,sizeof(tname), "%s.ind1", filename);
    ind1_size = ul_fsize(path,tname);
    if(ind1_size != 2*hash_num*sizeof(int))
    {
	ul_writelog(UL_LOG_WARNING, "[ODICT ERROR] check ind1 size error!want[%zu] real[%zu]",
		2*hash_num*sizeof(int),ind1_size);
	odb_destroy_search(pds);
	return NULL;
    }
    odbi_cmps_path(path, tname, fullpath, PATH_SIZE);
    if( (fno = ul_open(fullpath, O_RDONLY, 0644)) == -1 ){
	odb_destroy_search(pds);
	return NULL;
    }
    odbi_read(fno, pds->hash, (size_t)hash_num*sizeof(int));
    odbi_read(fno, pds->num, (size_t)hash_num*sizeof(int));  // read the number of nodes in hash entries
    ul_close(fno);

    snprintf(tname,sizeof(tname), "%s.ind2", filename);

    ind2_size = ul_fsize(path,tname);
    if(ind2_size != node_num*sizeof(sodict_snode_t))
    {
	ul_writelog(UL_LOG_WARNING, "[ODICT ERROR] check ind2 size error!want[%zu] real[%zu]",
		node_num*sizeof(sodict_snode_t),ind2_size);
	odb_destroy_search(pds);
	return NULL;
    }
    odbi_cmps_path(path, tname, fullpath, PATH_SIZE);
    if( (fno= ul_open(fullpath, O_RDONLY, 0644)) == -1 ){
	odb_destroy_search(pds);
	return NULL;
    }
    odbi_read(fno, pds->node, (size_t)node_num*sizeof(sodict_snode_t));
    ul_close(fno);

    /* return */
    return pds;
}

/*
 * odb_destroy frees all the resources occupied by sdb, including the dictionary object itself.
 *
 * Always return ODB_DESTROY_OK.
 */
int odb_destroy(sodict_build_t *sdb)
{
    sodict_bnode_block_t *block, *pblock;

    assert(sdb != NULL);

    free(sdb->hash);
    block = sdb->nblock;
    while (block != NULL) {
	pblock = block;
	block = pblock->next;
	free(pblock);
    }
    free(sdb);

    return ODB_DESTROY_OK;
}

/*
 * odb_destroy_search frees all the resources occupied by sdb, including the dictionary object itself.
 *
 * Always return ODB_DESTROY_OK.
 */
int odb_destroy_search(sodict_search_t *sdb)
{
    assert(sdb != NULL);

    ul_free(sdb->node);
    ul_free(sdb->hash);
    ul_free(sdb->num);
    ul_free(sdb);

    return ODB_DESTROY_OK;
}

/*
 * Save the dictionary object into the file specified by path and filename.
 *
 * If the dictionary object is saved successfully, return ODB_SAVE_OK, or return ODB_SAVE_ERROR.
 */
int odb_save(sodict_build_t *sdb, char *path, char *filename)
{
    int fno;
    int h_num = 0;
    int snode = sizeof(sodict_snode_t);
    int wt_len = 0;
    sodict_bhash_t *pbh = NULL;
    sodict_bnode_t *pnode;
    sodict_snode_t ds[ODB_MID_NODE_NUM];

    int     i, j, times;

    unsigned int   *phi;           /* the hash of dict_searcher */
    unsigned int   *pnum;          /* number of nodes in hash entries */
    int     ioff, inum;

    char    tname[PATH_SIZE];
    char    fullpath[PATH_SIZE];

    assert(sdb != NULL);
    assert(path != NULL);
    assert(filename != NULL);

    h_num = sdb->hash_num;
    pbh = sdb->hash;
    if (strlen(path) >= sizeof(tname)-2){
	ul_writelog(UL_LOG_WARNING,"[ODICT ERROR] path too long %s",path);
	return ODB_SAVE_ERROR;
    }
    strcpy(tname,path);
    if (tname[strlen(tname)-1] != '/'){
	strcat(tname,"/");
    }
    /* init vars */
    if((phi = (unsigned int *)ul_calloc(1,h_num * sizeof(int))) == NULL){
	ul_writelog(UL_LOG_WARNING,"[ODICT ERROR] cannot allocate memory for phi[%zu].",
		(h_num * sizeof(int)));
	return ODB_SAVE_ERROR;
    }
    if((pnum = (unsigned int*) ul_calloc(1, h_num * sizeof(int))) == NULL){
	ul_writelog(UL_LOG_WARNING,"[ODICT ERROR] cannot allocate memory for pnum[%zu].",
		(h_num * sizeof(int)));
	ul_free(phi);
	return ODB_SAVE_ERROR;
    }

    /* save the attribute of this dict */
    if (ul_writenum_init(tname, filename) == 1) {
	ul_writenum_oneint(tname, filename, "hash_num", sdb->hash_num);
	ul_writenum_oneint(tname, filename, "node_num", sdb->node_num);
	ul_writenum_oneint(tname, filename, "cur_code", sdb->cur_code);
    }
    else {
	ul_free(phi);
	ul_free(pnum);
	return ODB_SAVE_ERROR;
    }

    /* save the index 2 */
    sprintf(tname, "%s.ind2", filename);
    odbi_cmps_path(path, tname, fullpath, PATH_SIZE);
    if((fno = ul_open(fullpath, O_WRONLY|O_CREAT|O_TRUNC, 0644)) == -1){
	ul_writelog(UL_LOG_WARNING,"[ODICT ERROR] cannot open file[%s] for writing.", fullpath);
	ul_free(phi);
	ul_free(pnum);
	return ODB_SAVE_ERROR;
    }
    fchmod(fno,0644);

    times = 0;
    j = 0;
    ioff = inum = 0;
    for (i = 0; i < h_num; i++){
	phi[i] = ioff;
	pnode = pbh[i].pnode;
	while (pnode != NULL){
	    if (odbi_is_node_deleted(pnode)){
		pnode = pnode->next;
		continue;
	    }

	    ds[j].sign1 = pnode->sign1;
	    ds[j].sign2 = pnode->sign2;
	    ds[j].cuint1 = pnode->cuint1;
	    ds[j].cuint2 = pnode->cuint2;

	    j++;
	    pnum[i]++;
	    ioff++;

	    if (j >= ODB_MID_NODE_NUM) {
		wt_len = ODB_MID_NODE_NUM * snode;
		if (ul_write(fno, ds, wt_len) != wt_len) {
		    ul_writelog(UL_LOG_WARNING,"[ODICT ERROR] write data to file[%s] failed.", fullpath);
		    ul_free(phi);
		    ul_free(pnum);
		    ul_close(fno);
		    return ODB_SAVE_ERROR;
		}
		j = 0;
		times++;
	    }

	    pnode = pnode->next;
	}
    }

    if (j != 0) {
	wt_len = j * snode;
	if (ul_write(fno, ds, wt_len) != wt_len){
	    ul_writelog(UL_LOG_WARNING,"[ODICT ERROR] write data to file[%s] failed.", fullpath);
	    ul_free(phi);
	    ul_free(pnum);
	    ul_close(fno);
	    return ODB_SAVE_ERROR;
	}
    }

    ul_close(fno);

    /* save index1 */
    sprintf(tname, "%s.ind1", filename);
    odbi_cmps_path(path, tname, fullpath, PATH_SIZE);
    if((fno = ul_open(fullpath, O_WRONLY|O_CREAT|O_TRUNC, 0644)) == -1){
	ul_free(phi);
	ul_free(pnum);
	return ODB_SAVE_ERROR;
    }
    fchmod(fno, 0644);
    wt_len = h_num * sizeof(int);
    if (ul_write(fno, phi, wt_len) != wt_len){
	ul_writelog(UL_LOG_WARNING,"[ODICT ERROR] write data1 to file[%s] failed.", fullpath);
	ul_free(phi);
	ul_free(pnum);
	ul_close(fno);
	return ODB_SAVE_ERROR;
    }
    wt_len = h_num * sizeof(int);
    if (ul_write(fno, pnum, wt_len) != wt_len){
	ul_writelog(UL_LOG_WARNING,"[ODICT ERROR] write data2 to file[%s] failed.", fullpath);
	ul_free(phi);
	ul_free(pnum);
	ul_close(fno);
	return ODB_SAVE_ERROR;
    }

    ul_close(fno);

    /* check correction */
    if ( (times*ODB_MID_NODE_NUM+j != sdb->node_num) || (ioff != sdb->node_num) ){
	ul_writelog(UL_LOG_WARNING, "[ODICT ERROR] node number error[%d=%d].", sdb->node_num, ioff);
	ul_free(phi);
	ul_free(pnum);
	return ODB_SAVE_ERROR;
    }

    /* free */
    ul_free(phi);
    ul_free(pnum);

    sdb->cur_code++;

    /* return */
    return ODB_SAVE_OK;
}

int odb_save_search(sodict_search_t *sdb, char *path, char *filename)
{
    int fno;
    ssize_t wt_len;
    char fullpath[PATH_SIZE];
    char tname[PATH_SIZE];
    
    if (sdb == NULL || path == NULL || filename == NULL) 
	return ODB_SAVE_ERROR;

    if (strlen(path) >= sizeof(tname)-2) {
	ul_writelog(UL_LOG_WARNING,"[ODICT ERROR] path too long %s",path);
	return ODB_SAVE_ERROR;
    }

    if (path[strlen(path) - 1] != '/') {
      snprintf(tname, sizeof(tname), "%s/", path);
    } else {
      snprintf(tname, sizeof(tname), "%s", path);
    }
   
    if (ul_writenum_init(tname, filename) == 1) {
	ul_writenum_oneint(tname, filename, "hash_num", sdb->hash_num);
	ul_writenum_oneint(tname, filename, "node_num", sdb->node_num);
	ul_writenum_oneint(tname, filename, "cur_code", sdb->cur_code);
    }
    else {
	return ODB_SAVE_ERROR;
    }

    snprintf(tname, sizeof(tname), "%s.ind1", filename);
    odbi_cmps_path(path, tname, fullpath, PATH_SIZE);
    if ((fno = ul_open(fullpath, O_WRONLY | O_TRUNC | O_CREAT, 0644)) == -1) {
        return ODB_SAVE_ERROR;
    }
    wt_len = sdb->hash_num*sizeof(int);
    if (ul_write(fno, sdb->hash, wt_len) != wt_len) {
      ul_writelog(UL_LOG_WARNING, "[ODICT ERROR] odb_save_search write hash to file[%s] failed.", fullpath);
      ul_close(fno);
      return ODB_SAVE_ERROR;
    }

    wt_len = sdb->hash_num*sizeof(int);

    if (ul_write(fno, sdb->num, wt_len) != wt_len) {
      ul_writelog(UL_LOG_WARNING, "[ODICT ERROR] odb_save_search write num to file[%s] failed.", fullpath);
      ul_close(fno);
      return ODB_SAVE_ERROR;
    }
    ul_close(fno);

    snprintf(tname, sizeof(tname), "%s.ind2", filename);
    odbi_cmps_path(path, tname, fullpath, PATH_SIZE);
    if ((fno = ul_open(fullpath, O_WRONLY | O_TRUNC | O_CREAT, 0644)) == -1) {
        return ODB_SAVE_ERROR;;
    }
    wt_len = sdb->node_num*sizeof(sodict_snode_t);
    if (ul_write(fno, sdb->node, wt_len) != wt_len) {
      ul_writelog(UL_LOG_WARNING, "[ODICT ERROR] odb_save_search write node to file[%s] failed.", fullpath);
      ul_close(fno);
      return ODB_SAVE_ERROR;
    }
    ul_close(fno);

    return ODB_SAVE_OK;
}

int odb_save_search_safely(sodict_search_t *sdb, char *path, char *filename)
{
    int need_protect;
    int save_ret;

    char sname[PATH_SIZE];
    char dname[PATH_SIZE];

    if (sdb == NULL || path == NULL || filename == NULL) {
      return ODB_SAVE_ERROR; 
    }
 
    need_protect = odbi_is_dictionary_exist(path, filename);
    if (need_protect) {
      snprintf(sname, sizeof(sname), "%s.n", filename);
      snprintf(dname, sizeof(dname), ".odb.ss.%s.n", filename);
      if (is_file_exist(path, sname)) {
         if (ul_mvfile(path, sname, dname)) {
 	  ul_writelog(UL_LOG_WARNING, "[ODICT ERROR] cannot move file from [%s] to [%s].", sname, dname);
 	  return ODB_SAVE_ERROR;
 	}
      } else {
        ul_writelog(UL_LOG_WARNING,"[ODICT ERROR] file [%s/%s] not exist.", path,sname);
      }
 
      snprintf(sname, sizeof(sname), "%s.ind1", filename);
      snprintf(dname, sizeof(dname), ".odb.ss.%s.ind1", filename);
      if (is_file_exist(path, sname)) {
 	 if (ul_mvfile(path, sname, dname)) {
 	     ul_writelog(UL_LOG_WARNING,"[ODICT ERROR] cannot move file from [%s] to [%s].", sname, dname);
 	     return ODB_SAVE_ERROR;
 	 }
      } else {
        ul_writelog(UL_LOG_WARNING,"[ODICT ERROR] file [%s/%s] not exist.", path,sname);
      }
 
      snprintf(sname, sizeof(sname), "%s.ind2", filename);
      snprintf(dname, sizeof(dname), ".odb.ss.%s.ind2", filename);
      if (is_file_exist(path, sname)) {
 	 if (ul_mvfile(path, sname, dname)) {
 	     ul_writelog(UL_LOG_WARNING,"[ODICT ERROR] cannot move file from [%s] to [%s].", sname, dname);
 	     return ODB_SAVE_ERROR;
 	 }
      } else {
        ul_writelog(UL_LOG_WARNING,"[ODICT ERROR] file [%s/%s] not exist.", path,sname);
      }
    }
    /* save */
    save_ret = odb_save_search(sdb, path, filename);
 
    if (need_protect) {

	if (save_ret == ODB_SAVE_OK) {
	    snprintf(dname, sizeof(dname), ".odb.ss.%s.n", filename);
	    remove(dname);
	    snprintf(dname, sizeof(dname), ".odb.ss.%s.ind1", filename);
	    remove(dname);
	    snprintf(dname, sizeof(dname), ".odb.ss.%s.ind2", filename);
	    remove(dname);
	}
	else {
	    snprintf(dname, sizeof(dname), "%s.n", filename);
	    snprintf(sname, sizeof(sname), ".odb.ss.%s.n", filename);
	    if (ul_mvfile(path, sname, dname) != 0){
		ul_writelog(UL_LOG_WARNING,"[ODICT ERROR] cannot move file from [%s] to [%s], lost possibly.",
			sname, dname);
	    }
	    snprintf(dname, sizeof(dname), "%s.ind1", filename);
	    snprintf(sname, sizeof(sname), ".odb.ss.%s.ind1", filename);
	    if (ul_mvfile(path, sname, dname) != 0){
		ul_writelog(UL_LOG_WARNING,"[ODICT ERROR] cannot move file from [%s] to [%s], lost possibly.",
			sname, dname);
	    }
	    snprintf(dname, sizeof(dname), "%s.ind2", filename);
	    snprintf(sname, sizeof(sname), ".odb.ss.%s.ind2", filename);
	    if (ul_mvfile(path, sname, dname) != 0){
		ul_writelog(UL_LOG_WARNING,"[ODICT ERROR] cannot move file from [%s] to [%s], lost possibly.",
			sname, dname);
	    }
	}
    }

    /* return */
    return save_ret;

}


/*
 * It is the same as odb_save except that odb_save_safely can protect the old files from destroying
 * if exist.
 *
 * The temporary files with the prefix of .odb.ss. will be used to save the old files if exist.
 */
int odb_save_safely(sodict_build_t *sdb, char *path, char *filename)
{
    int  need_protect, save_ret;
    char sname[PATH_SIZE], dname[PATH_SIZE];

    assert(sdb != NULL);
    assert(path != NULL);
    assert(filename != NULL);

    need_protect = odbi_is_dictionary_exist(path, filename);
    if (need_protect) {
	snprintf(sname, sizeof(sname), "%s.n", filename);
	snprintf(dname, sizeof(dname), ".odb.ss.%s.n", filename);
	if (is_file_exist(path,sname)){
	    if (0 != ul_mvfile(path, sname, dname)){
		ul_writelog(UL_LOG_WARNING,"[ODICT ERROR] cannot move file from [%s] to [%s].", sname, dname);
	        return ODB_SAVE_ERROR;
	    }
	}
	else{
	    ul_writelog(UL_LOG_WARNING,"[ODICT ERROR] file [%s/%s] not exist.", path,sname);
	}
	snprintf(sname, sizeof(sname), "%s.ind1", filename);
	snprintf(dname, sizeof(dname), ".odb.ss.%s.ind1", filename);
	if (is_file_exist(path,sname)){
	    if (0 != ul_mvfile(path, sname, dname)){
		ul_writelog(UL_LOG_WARNING,"[ODICT ERROR] cannot move file from [%s] to [%s].", sname, dname);
	        return ODB_SAVE_ERROR;
	    }
	}
	else{
	    ul_writelog(UL_LOG_WARNING,"[ODICT ERROR] file [%s/%s] not exist.", path,sname);
	}
	snprintf(sname, sizeof(sname), "%s.ind2", filename);
	snprintf(dname, sizeof(dname), ".odb.ss.%s.ind2", filename);
	if (is_file_exist(path,sname)){
	    if (0 != ul_mvfile(path, sname, dname)){
		ul_writelog(UL_LOG_WARNING,"[ODICT ERROR] cannot move file from [%s] to [%s].", sname, dname);
		return ODB_SAVE_ERROR;
	    }
	}
	else{
	    ul_writelog(UL_LOG_WARNING,"[ODICT ERROR] file [%s/%s] not exist.", path,sname);
	}
    }

    save_ret = odb_save(sdb, path, filename);

    if (need_protect) {
	if (save_ret == ODB_SAVE_OK) {
	    snprintf(dname, sizeof(dname), ".odb.ss.%s.n", filename);
	    remove(dname);
	    snprintf(dname, sizeof(dname), ".odb.ss.%s.ind1", filename);
	    remove(dname);
	    snprintf(dname, sizeof(dname), ".odb.ss.%s.ind2", filename);
	    remove(dname);
	}
	else {
	    snprintf(dname, sizeof(dname), "%s.n", filename);
	    snprintf(sname, sizeof(sname), ".odb.ss.%s.n", filename);
	    if (0 != ul_mvfile(path, sname, dname)){
		ul_writelog(UL_LOG_WARNING,"[ODICT ERROR] cannot move file from [%s] to [%s], lost possibly.",
			sname, dname);
	    }
	    snprintf(dname, sizeof(dname), "%s.ind1", filename);
	    snprintf(sname, sizeof(sname), ".odb.ss.%s.ind1", filename);
	    if (0 != ul_mvfile(path, sname, dname)){
		ul_writelog(UL_LOG_WARNING,"[ODICT ERROR] cannot move file from [%s] to [%s], lost possibly.",
			sname, dname);
	    }
	    snprintf(dname, sizeof(dname), "%s.ind2", filename);
	    snprintf(sname, sizeof(sname), ".odb.ss.%s.ind2", filename);
	    if (0 != ul_mvfile(path, sname, dname)){
		ul_writelog(UL_LOG_WARNING,"[ODICT ERROR] cannot move file from [%s] to [%s], lost possibly.",
			sname, dname);
	    }
	}
    }

    /* return */
    return save_ret;
}

/*
 * Restore the sdb as the newly created dictionary object.
 *
 * If restore the dictionary object successfully, return ODB_RENEW_OK, or return ODB_RENEW_ERROR.
 *
 * NOTE: if odb_renew returns ODB_RENEW_ERROR, the original dictionary sdb MAY be destroyed partially, so
 * it is very dangerous to use sdb after failing in calling to odb_renew.
 */
int odb_renew(sodict_build_t *sdb)
{
    int i;
    sodict_bnode_block_t *block, *pblock;

    assert(sdb != NULL);

    for(i = 0 ; i < sdb->hash_num ; i++) {
	sdb->hash[i].pnode = NULL;
    }

    block = sdb->nblock;
    if(block != NULL) {
	pblock = block;
	block = block->next;
	pblock->next = NULL;
	while (block != NULL) {
	    pblock = block;
	    block = pblock->next;
	    free(pblock);
	}
    }

    sdb->cur_code = 0;
    sdb->node_num = 0;
    sdb->cur_nblock = sdb->nblock;
    sdb->cur_node = sdb->nblock->nodes;
    sdb->node_avail = ODB_NODE_BLOCK_NUM;

    //    memset(sdb->cur_node, 0, ODB_NODE_BLOCK_NUM*sizeof(sodict_bnode_t));

    return ODB_RENEW_OK;
}

int odb_renew_ex(sodict_build_t *sdb)
{
    return odb_renew(sdb);
}

/*
 * Add a node specified by snode into the specified dictionary object sdb.
 *
 * The parameter overwrite_if_exists can be zero or nonzero.
 * If overwrite_if_exists is equal to zero and there is the same node as snode, odb_add will
 * just return ODB_ADD_EXISTS;
 * if overwrite_if_exists is a nonzero number and there is the same node
 * as snode, the node will be overwritten by snode and odb_add will return ODB_ADD_OVERWRITE.
 * In other cases, the snode will be inserted into the dictionary object sdb and odb_add will
 * return ODB_ADD_OK.
 *
 * If odb_add fails in inserting or overwriting operation, it will return ODB_ADD_ERROR.
 *
 * If both the signatures are zero, odb_add will do nothing, and return
 * ODB_ADD_INVALID.
 */
int odb_add(sodict_build_t *sdb, sodict_snode_t *snode, int overwrite_if_exists)
{
    int hkey;
    sodict_bnode_t *pt_node, *pnode = NULL, *pfree = NULL;
    
    /* If both the signatures are zero, it is invalid. yingxiang@08.07.18 */
    if(snode->sign1 == 0 && snode->sign2 == 0){
	ul_writelog(UL_LOG_WARNING, "[ODICT ERROR] Invalid node: both the signatures are zero");
	return ODB_ADD_INVALID;
    }    

    assert(sdb != NULL);
    assert(snode != NULL);

    hkey = (snode->sign1 + snode->sign2)%sdb->hash_num;

    pt_node = sdb->hash[hkey].pnode;
    while(pt_node != NULL) {
	if ((pt_node->sign1 == snode->sign1) && (pt_node->sign2 == snode->sign2)) {
	    pnode = pt_node;
	    break;
	}
	if ((pfree == NULL) && (pt_node->sign1 == 0) && (pt_node->sign2 == 0)) {
	    pfree = pt_node;
	}
	pt_node = pt_node->next;
    }

    if (pnode != NULL) {
	if (overwrite_if_exists == 1) {
	    pnode->cuint1 = snode->cuint1;
	    pnode->cuint2 = snode->cuint2;
	    sdb->cur_code++;
	    return ODB_ADD_OVERWRITE;
	}
	else {
	    return ODB_ADD_EXISTS;
	}
    }
    else {
	if (pfree != NULL) {
	    pnode = pfree;
	    sdb->node_num++;
	    pnode->sign1 = snode->sign1;
	    pnode->sign2 = snode->sign2;
	    pnode->cuint1 = snode->cuint1;
	    pnode->cuint2 = snode->cuint2;
	}
	else {
	    /* allocate memory if no node block buffer has found */
	    if (sdb->node_avail == 0){
		sdb->cur_nblock->next = (sodict_bnode_block_t*)ul_calloc(1, sizeof(sodict_bnode_block_t));
		if (NULL == sdb->cur_nblock->next) {
		    ul_writelog(UL_LOG_WARNING,"[ODICT ERROR] cannot allocate memory for node block[%zu].",
			    sizeof(sodict_bnode_block_t));
		    return ODB_ADD_ERROR;
		}
		
		sdb->cur_nblock = sdb->cur_nblock->next;
		sdb->cur_node = sdb->cur_nblock->nodes;
		sdb->node_avail = ODB_NODE_BLOCK_NUM;
		
	    }

	    /* select the node buffer for adding */
	    pnode = sdb->cur_node;
	    pnode->next = NULL;
	    pnode->sign1 = snode->sign1;
	    pnode->sign2 = snode->sign2;
	    pnode->cuint1 = snode->cuint1;
	    pnode->cuint2 = snode->cuint2;
	    
	    //��������
	    if (sdb->hash[hkey].pnode == NULL){
		sdb->hash[hkey].pnode = pnode;
	    }
	    else {
		pnode->next = sdb->hash[hkey].pnode;
		sdb->hash[hkey].pnode = pnode;
	    }
	    
	    sdb->node_avail--;
	    sdb->node_num++;
	    /* allocate node block buffer for next action if need */
	    if (sdb->node_avail == 0){
		sdb->cur_nblock->next = (sodict_bnode_block_t*)ul_calloc(1, sizeof(sodict_bnode_block_t));
		if (NULL == sdb->cur_nblock->next) {
		    ul_writelog(UL_LOG_WARNING,"[ODICT ERROR] cannot prepare memory for node block[%zu].",
			    sizeof(sodict_bnode_block_t));
		}
		else {
		    sdb->cur_nblock = sdb->cur_nblock->next;
		    sdb->cur_node = sdb->cur_nblock->nodes;
		    sdb->node_avail = ODB_NODE_BLOCK_NUM;
		}
	    }
	    else {
		//ָ����һ��
		sdb->cur_node++;
	    }
	}
    }
    sdb->cur_code++;

    /* return */
    return ODB_ADD_OK;
}

/*
 * Delete the node specified by snode if exist.
 *
 * If the node specified by snode exists, just delete it and return ODB_DEL_OK,
 * or return ODB_DEL_NOT_EXISTS.
 *
 * If odb_del fails in deleting operation, return ODB_DEL_ERROR.
 */
int odb_del(sodict_build_t *sdb, sodict_snode_t *snode)
{
    int hkey;
    sodict_bnode_t *pt_node, *pnode = NULL;

    assert(sdb != NULL);
    assert(snode != NULL);

    hkey = (snode->sign1 + snode->sign2)%sdb->hash_num;

    pt_node = sdb->hash[hkey].pnode;
    while(pt_node != NULL) {
	if ((pt_node->sign1 == snode->sign1) && (pt_node->sign2 == snode->sign2)) {
	    pnode = pt_node;
	    break;
	}
	pt_node = pt_node->next;
    }

    if (NULL != pnode) {
	pnode->sign1 = 0;
	pnode->sign2 = 0;
	sdb->node_num--;
	sdb->cur_code++;
	return ODB_DEL_OK;
    }
    else {
	return ODB_DEL_NOT_EXISTS;
    }
}

/*
 * Seek a node in the dictionary object specified by sdb.
 *
 * If the specified node can be found in sdb, the node will be used to overwrite snode
 * and return ODB_SEEK_OK, or return ODB_SEEK_FAIL.
 *
 * If odb_seek in seeking operation, it will return ODB_SEEK_ERROR.
 */
int odb_seek(sodict_build_t *sdb, sodict_snode_t *snode)
{
    int hkey;
    sodict_bnode_t *pt_node, *pnode = NULL;

    assert(sdb != NULL);
    assert(snode != NULL);

    sdb->cur_code++;

    hkey = (snode->sign1 + snode->sign2)%sdb->hash_num;

    pt_node = sdb->hash[hkey].pnode;
    while(pt_node != NULL) {
	if ((pt_node->sign1 == snode->sign1) && (pt_node->sign2 == snode->sign2)) {
	    pnode = pt_node;
	    break;
	}
	pt_node = pt_node->next;
    }

    if (NULL != pnode) {
	snode->cuint1 = pnode->cuint1;
	snode->cuint2 = pnode->cuint2;
	return ODB_SEEK_OK;
    }
    else {
	return ODB_SEEK_FAIL;
    }
}

/*
 * The function odb_seek_search is the same as odb_seek.
 */
int odb_seek_search(sodict_search_t *sdb, sodict_snode_t *snode)
{
    int hkey, i, index;
    sodict_snode_t *pt_node, *pnode = NULL;

    assert(sdb != NULL);
    assert(snode != NULL);

    hkey = (snode->sign1 + snode->sign2)%sdb->hash_num;

    for (i = 0 ; (unsigned int)i < sdb->num[hkey] ; i++) {
	index = sdb->hash[hkey] + i;
	pt_node = &(sdb->node[index]);
	if ((pt_node->sign1 == snode->sign1) && (pt_node->sign2 == snode->sign2)){
	    pnode = pt_node;
	    break;
	}
    }
    if (NULL != pnode) {
	snode->cuint1 = pnode->cuint1;
	snode->cuint2 = pnode->cuint2;
	return ODB_SEEK_OK;
    }
    else {
	return ODB_SEEK_FAIL;
    }
}

/*
 * Modify the node in the dictionary object specified by sdb if exist.
 *
 * If the node specified by snode exists, modify the node and return ODB_MOD_OK, or return ODB_MOD_FAIL.
 *
 * If odb_mod fails in searching or modifying the node, return ODB_MOD_ERROR.
 */
int odb_mod(sodict_build_t *sdb, sodict_snode_t *snode)
{
    int hkey;
    sodict_bnode_t *pt_node, *pnode = NULL;

    assert(sdb != NULL);
    assert(snode != NULL);

    hkey = (snode->sign1 + snode->sign2)%sdb->hash_num;

    pt_node = sdb->hash[hkey].pnode;
    while(pt_node != NULL) {
	if ((pt_node->sign1 == snode->sign1) && (pt_node->sign2 == snode->sign2)) {
	    pnode = pt_node;
	    break;
	}
	pt_node = pt_node->next;
    }

    if (NULL != pnode) {
	pnode->cuint1 = snode->cuint1;
	pnode->cuint2 = snode->cuint2;
	sdb->cur_code++;
	return ODB_MOD_OK;
    }
    else {
	return ODB_MOD_FAIL;
    }
}

/*
 * Go through all the nodes in the specified dictionary object.
 */
void odb_traverse(sodict_build_t *sdb, int include_deleted,
	void (*traverse_handler)(sodict_snode_t *snode, int *stop_now))
{
    sodict_bnode_t *pnode;
    sodict_snode_t snode;
    int            stop_now;

    assert(sdb);

    for (int i = 0; i < sdb->hash_num; i++){
	pnode = sdb->hash[i].pnode;
	if (NULL != pnode) {
	    while (pnode != NULL){
		if (include_deleted != 1) {
		    if (odbi_is_node_deleted(pnode)){
			pnode = pnode->next;
			continue;
		    }
		}

		snode.sign1 = pnode->sign1;
		snode.sign2 = pnode->sign2;
		snode.cuint1 = pnode->cuint1;
		snode.cuint2 = pnode->cuint2;

		stop_now = 0;
		traverse_handler(&snode, &stop_now);
		if (stop_now == 1)
		    return;

		pnode = pnode->next;
	    }
	}
    }
}

void odb_traverse_ex(sodict_build_t *sdb, int include_deleted,
	void (*traverse_handler)(sodict_snode_t *snode, int *stop_now, void *arg), void *ex_arg)
{
    sodict_bnode_t *pnode;
    sodict_snode_t snode;
    int            stop_now;

    assert(sdb);

    for (int i = 0; i < sdb->hash_num; i++){
	pnode = sdb->hash[i].pnode;
	if (NULL != pnode) {
	    while (pnode != NULL){
		if (include_deleted != 1) {
		    if (odbi_is_node_deleted(pnode)){
			pnode = pnode->next;
			continue;
		    }
		}

		snode.sign1 = pnode->sign1;
		snode.sign2 = pnode->sign2;
		snode.cuint1 = pnode->cuint1;
		snode.cuint2 = pnode->cuint2;

		stop_now = 0;
		traverse_handler(&snode, &stop_now, ex_arg);
		if (stop_now == 1)
		    return;

		pnode = pnode->next;
	    }
	}
    }
}

void odb_traverse_search(sodict_search_t *sdb, void (*traverse_handler)(sodict_snode_t *snode, int *stop_now))
{
    int stop_now;

    assert(sdb);

    for (int i = 0 ; i < sdb->hash_num ; i++) {
	if (sdb->num[i] <= 0)
	    continue;
	for (int j = 0 ; (unsigned int)j < sdb->num[i] ; j++) {
	    stop_now = 0;
	    traverse_handler(&(sdb->node[sdb->hash[i] + j]), &stop_now);
	    if (stop_now == 1)
		return;
	}
    }
}

void odb_traverse_search_ex(sodict_search_t *sdb, void (*traverse_handler)(sodict_snode_t *snode, int *stop_now
	    ,void *arg),void *ex_arg)
{
    int stop_now;

    assert(sdb);

    for (int i = 0 ; i < sdb->hash_num ; i++) {
	if (sdb->num[i] <= 0)
	    continue;
	for (int j = 0 ; (unsigned int)j < sdb->num[i] ; j++) {
	    stop_now = 0;
	    traverse_handler(&(sdb->node[sdb->hash[i] + j]), &stop_now,ex_arg);
	    if (stop_now == 1)
		return;
	}
    }
}

/*
 * Report the status of the dictionary only for debug
 */
static void report_node(sodict_snode_t *node, int *stop_now)
{
    fprintf(stderr, "sign1: %u\n", node->sign1);
    fprintf(stderr, "sign2: %u\n", node->sign2);
    fprintf(stderr, "custom data1: %u\n", node->cuint1);
    fprintf(stderr, "custom data2: %u\n", node->cuint2);
}

void odb_build_report(sodict_build_t *sdb)
{
    odb_traverse(sdb, 0, report_node);
}

void odb_search_report(sodict_search_t *sdb)
{
    odb_traverse_search(sdb, report_node);
}

int odb_get_nodenum(sodict_build_t *sdb)
{
    if (sdb){
	return sdb->node_num;
    }
    return 0;
}

int odb_get_hashnum(sodict_build_t *sdb)
{
    if (sdb){
	return sdb->hash_num;
    }
    return 0;
}

int odb_search_get_nodenum(sodict_search_t *sdb)
{
    if (sdb){
	return sdb->node_num;
    }
    return 0;
}

int odb_search_get_hashnum(sodict_search_t *sdb)
{
     if (sdb){
         return sdb->hash_num;
     }   
     return 0;
}
 
int odb_adjust(sodict_build_t *sdb)
{
    if (!sdb){
	return -1;
    }
    sodict_bhash_t *hash;
    int h_num,n_num,hkey;
    int i,times;
    sodict_bnode_block_t *block;
    sodict_bnode_t *node;

    n_num = sdb->node_num;
    h_num = n_num/2;
    if ( (h_num % 2) == 0 ) {
        h_num++;
    }

    hash = (sodict_bhash_t *)ul_calloc(1,h_num*sizeof(sodict_bhash_t));
    if (!hash){
	return -1;
    }
    
    if (sdb->hash){
	ul_free(sdb->hash);
	sdb->hash = NULL;
    }
    sdb->hash = hash;

    sdb->hash_num = h_num;

    hkey = 0;
    block = sdb->nblock;
    while(block != NULL) {
	times = ODB_NODE_BLOCK_NUM;
	if (block->next==NULL){
	    times -= sdb->node_avail;
	}
	node = block->nodes;
	for (i = 0; i < times; i ++){
	    if (node[i].sign1 == 0 && node[i].sign2 == 0){
		//������ɾ���Ľڵ㣬��̫�ô�����������һ���ط���
		hkey = (hkey+1) % sdb->hash_num;
	    }
	    else{
		hkey = (node[i].sign1 + node[i].sign2) % sdb->hash_num;
	    }
	    if (sdb->hash[hkey].pnode == NULL){
		node[i].next = NULL;
		sdb->hash[hkey].pnode = &node[i];
	    }
	    else{
		node[i].next = sdb->hash[hkey].pnode;
		sdb->hash[hkey].pnode = &node[i];
	    }
	}
	block = block->next;
    }
    return 0;
}

int odb_is_equal_search(sodict_search_t *sdb1, sodict_search_t *sdb2)
{
    if (NULL == sdb1 || NULL == sdb2) {
	return 0;
    }

    if (NULL == sdb1->hash || NULL == sdb2->hash ||
	NULL == sdb1->num || NULL == sdb2->num ||
	NULL == sdb1->node || NULL == sdb2->node) {
	return 0;
    }

    if (sdb1->hash_num != sdb2->hash_num ||
	sdb1->node_num != sdb2->node_num ||
	sdb1->cur_code != sdb2->cur_code) {
	return 0;
    }

    if (memcmp(sdb1->hash, sdb2->hash, sdb1->hash_num*sizeof(unsigned int)) != 0 ||
	memcmp(sdb1->num, sdb2->num, sdb1->hash_num*sizeof(unsigned int)) != 0 ||
	memcmp(sdb1->node, sdb2->node, sdb1->node_num*sizeof(sodict_snode_t)) != 0) {
	return 0;
    }

    return 1;
}

// end of file odict.cpp
/* vim: set ts=8 sw=4 sts=4 tw=78 noet: */
