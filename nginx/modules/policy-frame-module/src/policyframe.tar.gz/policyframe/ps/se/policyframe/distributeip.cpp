#include "dis.h"
#include "policyframe.h"
#include "frame_util.h"
#include "mc_type.h"
#include "mc_const.h"
#include "mc_cache.h"
#include <ul_def.h>
#include <pthread.h>
#include <ul_net.h>
#include <ul_sign.h>

#ifdef USETHREAD
#include <pthread.h>
#endif

//#define WARNING(fmt,...) printf("%s-%d:"fmt"\n",__FILE__,__LINE__,##__VA_ARGS__)
//#define BWSDEBUG WARNING

#ifdef USETHREAD
static pthread_key_t process_key = 0;
#else
static unsigned int bigidcount_ptr[256];
#endif
static mc_cache * bigcache_ptr = NULL;
static const char * patterntype = "DistributeIpAttack";
static int distributeattack_create(PatternMatchInterfacePtr pmi,xmlNodePtr pxmlnode);
static void distributeattack_release(PatternMatchInterfacePtr parg);
static int distributeattack_init();
PatternMatchResult distributeattack_patternmatch(void *conn,void*arg,short* result);

PatternMatchFactory distributeattack_factory={"DistributeIpAttack",\
					REGION_PRE,\
					distributeattack_create,\
	     			        distributeattack_release,\
				        distributeattack_init
};

#ifdef USETHREAD
static void destroy_process(void *statdata)
{
    if (statdata != NULL){
        free(statdata);
	statdata = NULL;
    }
}
#endif
static void *
get_specific_data(xmlNodePtr pxmlnode)
{
    DistributeAttactConfPtr disconf_ptr = (DistributeAttactConfPtr)malloc(sizeof(DistributeAttactConf));
    if (disconf_ptr == NULL)
    {
        WARNING("Malloc DistributeAttactConf error");
	goto err1;
    }
/*    if (bigcache_ptr == NULL)
    {
        bigcache_ptr = mc_creat_cache(disconf_ptr->cachenum,sizeof (UserVisit));
        if (bigcache_ptr == NULL){
	    WARNING("DistributeIPattack: Create mc cache error");
	    goto err1;
    	}
    }*/
#ifdef USETHREAD
    if ( pthread_key_create(&process_key, destroy_process) !=0 ){
        WARNING("Create process_key Error");
        goto err1;
    }
#endif
    BWSDEBUG("GET_SPECIFIC_DATA");
    bigcache_ptr = get_specific_distribute_data(pxmlnode, disconf_ptr, bigcache_ptr);
    if (bigcache_ptr == NULL)
    {
	WARNING("get_specific_distribute_data return error");
	goto err1;
    }
    return disconf_ptr;
err1:
    if (disconf_ptr == NULL){
        free(disconf_ptr);
	disconf_ptr = NULL;
    }
    return NULL;
}
static int 
distributeattack_create(PatternMatchInterfacePtr pmi,xmlNodePtr pxmlnode)
{
    /*
     * first we should use the PatternMatchInterface node  and assign the following element in the node
     *           0. patterntype
     *           1. patternname ( this come from the "define" attribute)  
     *           2. pmatch  (this is the specific fuction) 
     *           3. pfactory (this func pinter is used to release the resource assigned in this function )
     *              and we can just give it value "distributeattack_factory"
     * second we should create specific node for the pattern
     * 		 0. patterndata (this data is released by the pmatch
     */
    xmlChar * name;
    snprintf(pmi->patterntype,PATTERNTYPELEN,"%s",patterntype);
    pmi->pfactory = &distributeattack_factory;
    pmi->pmatch = &distributeattack_patternmatch;
    pmi->patterndata = get_specific_data(pxmlnode);
    pmi->region = distributeattack_factory.region;
    if (pmi->patterndata == NULL)
	goto erro;
    name = xmlGetProp(pxmlnode, (const xmlChar*)"define");
    if (name == NULL){
	goto erro;
    }
    snprintf(pmi->patternname,PATTERNNAMELEN,"%s",name);
    xmlFree(name);
    return 0;
erro:
    return -1;
}
static int
distributeattack_init()
{
#ifdef USETHREAD
    unsigned int *bigstatidcount_ptr;
    bigstatidcount_ptr = (unsigned int*)pthread_getspecific(process_key);
    if (process_key == 0)
	return 0;
    if (bigstatidcount_ptr == NULL){
	bigstatidcount_ptr = (unsigned int*)malloc(256*sizeof(unsigned int));
        if(bigstatidcount_ptr == NULL){
	    WARNING("Not Enough Memory, Can't Malloc");
	    goto erro2;
        }
        if(pthread_setspecific(process_key, (void *)bigstatidcount_ptr)){
	    WARNING("Can't set specific process_key");
	    goto erro2;
        }
    }
    memset(bigstatidcount_ptr, 0, 256*sizeof(unsigned int));
    return 0;
erro2:
    if (bigstatidcount_ptr == NULL){
        free(bigstatidcount_ptr);
        bigstatidcount_ptr = NULL;   
    }
    return -1;
#else
    memset(bigidcount_ptr, 0, 256*sizeof(unsigned int));
    return 0;
#endif
}
static void 
distributeattack_release(PatternMatchInterfacePtr parg)
{
    /*
     * this function have just one task:
     * 1. it should release the resource in PatternMatchInterfacePtr::patterndata
     */
    /**the task**/
    DistributeAttactConfPtr disconf_ptr = (DistributeAttactConfPtr)parg->patterndata;
    if (disconf_ptr != NULL){
	free(disconf_ptr);
	parg->patterndata = NULL;
    }
    if (bigcache_ptr != NULL){
        free(bigcache_ptr);
	bigcache_ptr = NULL;
    }
    /**the second task**/
//    RELEASE_PATTERN_MATCH_INTERFACE(parg);
    return;
}
PatternMatchResult 
distributeattack_patternmatch(void *conn,void *arg,short *result)
{
    stat_t * proc = (stat_t *)conn;
    unsigned int sign[2], *count;
    DistributeAttactConfPtr disconf_ptr = (DistributeAttactConfPtr) arg;
    
    sign[0] = proc->client_addr.s_addr;                                                                     
#ifdef USEIPCOOKIE
    BWSDEBUG("USE IPCOOKIE");
    if (proc->cookie == NULL || proc->cookie[0] == 0){
	sign[0] = proc->client_addr.s_addr;
	sign[1] = disconf_ptr->statid&0xFF;
    }
    else{
    	creat_sign_f64(proc->cookie, strlen(proc->cookie), &sign[0], &sign[1]);
    	sign[1] = (sign[1]&0xFFFFFF00)|(disconf_ptr->statid&0xFF);
    }
#else
    BWSDEBUG("NO IPCOOKIE");
    sign[0] = proc->client_addr.s_addr;
    sign[1] = disconf_ptr->statid&0xFF;
#endif
    
#ifdef USETHREAD
    count = (unsigned int*)pthread_getspecific(process_key);
    if (count == NULL){
        return NotMatch;
    }
#else
    count = bigidcount_ptr;
#endif
    return distribute_stat(conn, arg, result, count, sign);    
}
