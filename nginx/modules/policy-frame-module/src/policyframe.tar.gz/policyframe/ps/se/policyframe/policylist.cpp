#include "policyframe.h"
#ifndef __PATTERNLIST__
#define __PATTERNLIST__
#define PATTERNLISTNUM 128
#define ACTIONLIST     128
extern PatternMatchFactory distributeattack_factory;
extern PatternMatchFactory distribute_agentattack_factory;
extern PatternMatchFactory distribute_uriattack_factory;
extern PatternMatchFactory distribute_referattack_factory;
extern PatternMatchFactory ipdict_factory;
extern PatternMatchFactory httpfilter_factory;

PatternMatchFactoryPtr patternlist[PATTERNLISTNUM]={&distributeattack_factory,\
						    &distribute_agentattack_factory,\
					            &distribute_referattack_factory,\
						    &distribute_uriattack_factory,\
						    &ipdict_factory,\
    						    &httpfilter_factory,\
    						    NULL};

extern ActionFactory rtcode_factory;
ActionFactoryPtr actionlist[ACTIONLIST]={&rtcode_factory,\
    					NULL};
#endif
