#ifndef __FRAME_UTIL__
#define __FRAME_UTIL__
#include <libxml/xmlmemory.h>
#include <libxml/parser.h>
#include <iconv.h>
#include <libxml/encoding.h>
#include <ul_log.h>

#define WARNING(fmt,...) ul_writelog(UL_LOG_WARNING,"%s-%d:"fmt,__FILE__,__LINE__,##__VA_ARGS__)
#define BWSDEBUG(fmt,...) ul_writelog(UL_LOG_DEBUG,"%s-%d:"fmt,__FILE__,__LINE__,##__VA_ARGS__)
int getattributevalue(xmlNodePtr pcur,char *attribute,char *value, int vlen);
int getattributeint(xmlNodePtr pcur,char *attribute,int *value);
int getcontent(xmlNodePtr pcur,char *value, int vlen);
int getcontentint(xmlNodePtr pcur, int *value);
/*
 * 0 match
 * -1 not match
 */
int tagNameMatch(xmlNodePtr cur,char * tagname);


#endif

