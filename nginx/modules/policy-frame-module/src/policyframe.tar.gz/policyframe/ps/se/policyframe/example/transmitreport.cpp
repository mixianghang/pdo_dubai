#include "transmit.h"

#define TIME_WEEK	2
#define TIME_DAY	3
#define TIME_HOUR	4
#define TIME_MINUTE	5
#define TIME_SECOND	6

bool g_terminate_flag = false;
int g_shm_key = 0x87435042;
int g_shm_id = -1;
char *g_shm_addr = NULL;
ShmConfig *g_shm_config = NULL;
Statistics *g_statistics = NULL;

void show_usage(void)
{       
	printf("\n");
	printf("Project    : %s\n", PROJECT_NAME);
	printf("Version    : %s\n", VERSION);
	printf("BuildDate  : %s\n", BuildDate);
	printf("Description: transmit report module\n");
	printf("Usage: datacenter [-k] [-i] [-f] [-h] [-v]\n");
	printf("\t-k\tshm_key, default: 0x87435042\n");
	printf("\t-i\trefresh time, can be digit[w,d,h,m,s]\n");
	printf("\t-f\tdata file, default: stderr\n");
	printf("\t-r\texternal program file and parameter, default: not execute external program\n");
	printf("\t-c\tclear statistics\n");
        printf("\t-n\tdo not print stamp in data file\n");
	printf("\t-v|-h\tshow help and version, i.e. this page\n");
	printf("\n");

	return;
}
void sig_terminate(int sig)
{       
	g_terminate_flag = true;
}       

int init_shm(void)
{
	g_shm_id = shmget(g_shm_key, 0, 0666);
	if(g_shm_id == -1) 
	{
		ul_writelog(UL_LOG_FATAL, "%s %d init_shm: shmget() error, %s", 
					__FILE__, __LINE__, strerror(errno));
		return -1;
	} 
	else 
	{
		g_shm_addr = (char *)shmat(g_shm_id, NULL, 0);
		if(g_shm_addr == (char *)-1)
		{
			ul_writelog(UL_LOG_FATAL, "%s %d init_shm: shmat() error, %s", 
						__FILE__, __LINE__, strerror(errno));
			return -1;
		}
	} 
	g_shm_config = (ShmConfig *)g_shm_addr;
	g_statistics = &(g_shm_config->statistics);

	return 0;
}

void deinit_shm(void)
{
	if(g_shm_id < 0)
		return;
	if(g_shm_addr)
		shmdt(g_shm_addr);

}

void show_current_conf()
{
	if(NULL == g_shm_config){
		return;
	}
	const Config * g_cur_config = &(g_shm_config->config[g_shm_config->cur_config]);

	fprintf(stderr, "listen_port = %d\n", g_cur_config->listen_port);
	fprintf(stderr, "max_connection_num = %d\n", g_cur_config->max_connection_num);
	fprintf(stderr, "max_outbuff_num = %d\n", g_cur_config->max_outbuff_num);
	fprintf(stderr, "log_level = %d\n", g_cur_config->log_level);
 	fprintf(stderr, "log_size = %d\n", g_cur_config->log_size);
	fprintf(stderr, "max_innocent_num = %d\n", g_cur_config->max_innocent_num);
	fprintf(stderr, "max_blacklist_num = %d\n", g_cur_config->max_blacklist_num);
	fprintf(stderr, "cur_innocent_num = %d\n", g_cur_config->cur_innocent_num);
	fprintf(stderr, "cur_blacklist_num = %d\n", g_cur_config->cur_blacklist_num);
	fprintf(stderr, "read_client_timeout = %d\n", g_cur_config->read_client_timeout);
	fprintf(stderr, "write_apache_timeout = %d\n", g_cur_config->write_apache_timeout);
	fprintf(stderr, "connect_apache_timeout = %d\n", g_cur_config->connect_apache_timeout);
	fprintf(stderr, "connect_pp_apache_timeout = %d\n", g_cur_config->connect_pp_apache_timeout);
	fprintf(stderr, "read_apache_write_client_timeout = %d\n", g_cur_config->read_apache_write_client_timeout);
	fprintf(stderr, "interval_write_client_timeout = %d\n", g_cur_config->interval_write_client_timeout);
	fprintf(stderr, "max_con_per_ip = %d\n", g_cur_config->max_con_per_ip);
	fprintf(stderr, "min_response_time_to_record = %d\n", g_cur_config->min_response_time_to_record);
	fprintf(stderr, "min_read_time_to_record = %d\n", g_cur_config->min_read_time_to_record);

	fprintf(stderr, "fast_timer = %d\n", g_cur_config->fast_timer);
	fprintf(stderr, "slow_timer = %d\n", g_cur_config->slow_timer);
	fprintf(stderr, "max_keep_alive_time = %d\n", g_cur_config->max_keep_alive_time);
	fprintf(stderr, "min_free_connection = %d\n", g_cur_config->min_free_connection);
	fprintf(stderr, "normal_read_time = %d\n", g_cur_config->normal_read_time);
	fprintf(stderr, "normal_write_time = %d\n", g_cur_config->normal_write_time);

	fprintf(stderr, "dispatch_scale = %d\n", g_cur_config->dispatch_scale);

	fprintf(stderr, "inbuff_len = %d\n", g_cur_config->inbuff_len);
	fprintf(stderr, "outbuff_len = %d\n", g_cur_config->outbuff_len);
	fprintf(stderr, "listen_num = %d\n", g_cur_config->listen_num);
	fprintf(stderr, "send_buff_size = %d\n", g_cur_config->send_buff_size);
	fprintf(stderr, "recv_buff_size = %d\n", g_cur_config->recv_buff_size);

	fprintf(stderr, "pid_file = %s\n", g_cur_config->pid_file);
	fprintf(stderr, "listen_addr = %s\n", g_cur_config->listen_addr);
	fprintf(stderr, "innocent_file = %s\n", g_cur_config->innocent_file);
	fprintf(stderr, "blacklist_file = %s\n", g_cur_config->blacklist_file);
	fprintf(stderr, "log_path = %s\n", g_cur_config->log_path);
	fprintf(stderr, "log_file = %s\n", g_cur_config->log_file);

	fprintf(stderr, "raw_log_rate = %d\n", g_cur_config->raw_log_rate);
	fprintf(stderr, "raw_log_file = %s\n", g_cur_config->raw_log_file);
	fprintf(stderr, "recover_time = %d\n", g_cur_config->recover_time);

	char prison_type[256];
	for(int turn = 0; turn < g_cur_config->prison_filters.size; ++turn){
		fprintf(stderr, "prison_type=%s; check_period=%d; stay_period=%d; threshold=%d\n",
			get_prison_type((unsigned int)g_cur_config->prison_filters.filter[turn].type, prison_type),
			g_cur_config->prison_filters.filter[turn].check_period,
			g_cur_config->prison_filters.filter[turn].stay_period,
			g_cur_config->prison_filters.filter[turn].threshold);			
	}
	
	fprintf(stderr, "search dir=");
	for(int turn = 0; turn < g_cur_config->search_dir.nelts; ++turn)
	{
		fprintf(stderr, " [%s]", g_cur_config->search_dir.data[turn]);
	}
	fprintf(stderr, "\n");

	fprintf(stderr, "pp dir = ");
	for(int turn = 0; turn < g_cur_config->pp_dir.nelts; ++turn)
	{
		fprintf(stderr, " [%s]", g_cur_config->pp_dir.data[turn]);
	}
	fprintf(stderr, "\n");
					
}

int main(int argc, char *argv[])
{
	int c;
	int time_type = TIME_SECOND;
	int refresh_interval = 1;
	int now_interval = 0;
	char *s;
	FILE *fp;
	char data_file[MAX_PATH_LEN] = "\0";
	char proc_file[MAX_PATH_LEN] = "\0";
	time_t  time_secs;
	struct tm old;
	struct tm now;
	bool show_conf = false;

        int     b_time_stamp = 1;
        
	fp = stderr;
	signal(SIGTERM, sig_terminate);


	while((c=getopt(argc, argv, "k:i:f:r:pcnhv")) != -1)
	{
		switch(c) 
		{
			case 'k':
				g_shm_key = atoi(optarg);
				break;
			case 'i':
				if((s=strchr(optarg, 'w')) != NULL)
				{
					time_type = TIME_WEEK;
					*s = '\0';
				}
				else
				if((s=strchr(optarg, 'd')) != NULL)
				{
					time_type = TIME_DAY;
					*s = '\0';
				}
				else
				if((s=strchr(optarg, 'h')) != NULL)
				{
					time_type = TIME_HOUR;
					*s = '\0';
				}
				else
				if((s=strchr(optarg, 'm')) != NULL)
				{
					time_type = TIME_MINUTE;
					*s = '\0';
				}
				else
				if((s=strchr(optarg, 's')) != NULL)
				{
					time_type = TIME_SECOND;
					*s = '\0';
				}

				refresh_interval = atoi(optarg);
				break;
			case 'f':
				snprintf(data_file, MAX_PATH_LEN, "%s", optarg);
				break;
			case 'r':
				snprintf(proc_file, MAX_PATH_LEN, "%s", optarg);
				break;
			case 'c':
                                if(init_shm() != 0)
                                {
                                    ul_writelog(UL_LOG_FATAL, "%s %d main -c: init_shm() error, exit", __FILE__, __LINE__);
                                    return -1;
                                }
                                memset(&g_statistics->closed_by_client_num, 0, 
                                       sizeof(Statistics)-(int)&(((Statistics *)NULL)->closed_by_client_num));
				g_statistics->total_request_num = g_statistics->client_con_num;
				break;
                        case 'n':
                                b_time_stamp = 0;
                                break;
			case 'p':
				show_conf = true;
				break;
			case 'h':
			case 'v':
			case '?':
				show_usage();
				exit(-1);                        
		}
	}

	if(init_shm() != 0)
	{
		ul_writelog(UL_LOG_FATAL, "%s %d main: init_shm() error, exit", __FILE__, __LINE__);
		return -1;
	}

	if(show_conf){
		show_current_conf();
		deinit_shm();
		return 0;
	}

	if(data_file[0] != '\0')
	{
		fp = fopen(data_file, "w+b");
		if(fp == NULL)
		{
			fprintf(stderr, "Open file[%s] error, %s\n", data_file, strerror(errno));
			return -1;
		}
	}
	time_secs = time(NULL);
	old = *(localtime(&time_secs));
	while(1)
	{
		if(g_terminate_flag)
			break;

		if(fp != stderr)
		{
			truncate(data_file, 0);
			fseek(fp, 0, SEEK_SET);
                        
                        if(!b_time_stamp)
                        {
                            fprintf(fp, "%d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d",
      					g_statistics->total_request_num,
					g_statistics->success_request_num,
					g_statistics->client_con_num,
					g_statistics->apache_con_num,
					g_statistics->reading_client_num,
					g_statistics->connecting_apache_num,
					g_statistics->writing_apache_num,
					g_statistics->reading_apache_writing_client_num,
					g_statistics->closed_by_client_num,
					g_statistics->reset_by_peer_num,
					g_statistics->broken_pipe_num,
					g_statistics->request_method_error_num,
					g_statistics->request_too_long_num,
					g_statistics->connect_apache_error_num,
					g_statistics->read_client_timeout_num,
					g_statistics->write_apache_timeout_num,
					g_statistics->connect_apache_timeout_num,
					g_statistics->read_apache_write_client_timeout_num,
					g_statistics->interval_write_client_timeout_num,
					g_statistics->black_deny_num,
					g_statistics->limit_deny_num,
					g_statistics->inbuff_overflow_num,
					g_statistics->outbuff_overflow_num,
					g_statistics->completed_num>0 ? \
					g_statistics->completed_time_used/g_statistics->completed_num : 0,
					g_statistics->read_client_error_num>0 ? \
					g_statistics->read_client_time_used/g_statistics->read_client_error_num : 0 +
					g_statistics->write_apache_error_num>0 ? \
					g_statistics->write_apache_time_used/g_statistics->write_apache_error_num : 0 +
					g_statistics->read_apache_write_client_error_num>0 ? \
					g_statistics->read_apache_write_client_time_used/\
					g_statistics->read_apache_write_client_error_num : 0,
                                        g_statistics->prision_deny_num,
                                        g_statistics->cycle_num>0 ? \
                                                g_statistics->select_time_used/g_statistics->cycle_num : 0,
					g_statistics->cycle_num>0 ? \
					        g_statistics->process_time_used/g_statistics->cycle_num : 0);
                        }
                        else
                        {
                            
                            fprintf(fp, "%04d-%02d-%02d %02d:%02d:%02d	%d	%d	%d	%d	%d	%d	%d	"
					"%d	%d	%d	%d	%d	%d	%d	%d	%d	%d	%d	%d	%d	%d	%d	%d	%d	%d	%d	%d	%d",
                                        old.tm_year+1900, old.tm_mon+1, old.tm_mday,
                                        old.tm_hour, old.tm_min, old.tm_sec,

                                        g_statistics->total_request_num,
					g_statistics->success_request_num,
					g_statistics->client_con_num,
					g_statistics->apache_con_num,
					g_statistics->reading_client_num,
					g_statistics->connecting_apache_num,
					g_statistics->writing_apache_num,
					g_statistics->reading_apache_writing_client_num,
					g_statistics->closed_by_client_num,
					g_statistics->reset_by_peer_num,
					g_statistics->broken_pipe_num,
					g_statistics->request_method_error_num,
					g_statistics->request_too_long_num,
					g_statistics->connect_apache_error_num,
					g_statistics->read_client_timeout_num,
					g_statistics->write_apache_timeout_num,
					g_statistics->connect_apache_timeout_num,
					g_statistics->read_apache_write_client_timeout_num,
					g_statistics->interval_write_client_timeout_num,
					g_statistics->black_deny_num,
					g_statistics->limit_deny_num,
					g_statistics->inbuff_overflow_num,
					g_statistics->outbuff_overflow_num,
					g_statistics->completed_num>0 ? \
					g_statistics->completed_time_used/g_statistics->completed_num : 0,
					g_statistics->read_client_error_num>0 ? \
					g_statistics->read_client_time_used/g_statistics->read_client_error_num : 0 +
					g_statistics->write_apache_error_num>0 ? \
					g_statistics->write_apache_time_used/g_statistics->write_apache_error_num : 0 +
					g_statistics->read_apache_write_client_error_num>0 ? \
					g_statistics->read_apache_write_client_time_used/\
                                        g_statistics->read_apache_write_client_error_num : 0,
                                        g_statistics->prision_deny_num,
					
					g_statistics->cycle_num>0 ? \
						g_statistics->select_time_used/g_statistics->cycle_num : 0,
					
					g_statistics->cycle_num>0 ? \
						g_statistics->process_time_used/g_statistics->cycle_num : 0);
                        }
                        
			fflush(fp);

			memset(&g_statistics->closed_by_client_num, 0, 
				   sizeof(Statistics)-(int)&(((Statistics *)NULL)->closed_by_client_num));
			g_statistics->total_request_num = g_statistics->client_con_num;

			if(proc_file[0] != '\0')
			{
				if(system(proc_file) == -1)
					fprintf(stderr, "Can not execute external program, %s\n", strerror(errno));
			}
		}
		else
		{
			fprintf(fp, "total_request_num: %d\n", g_statistics->total_request_num);
			fprintf(fp, "success_request_num: %d\n\n", g_statistics->success_request_num);

			fprintf(fp, "client_con_num: %d\n", g_statistics->client_con_num);
			fprintf(fp, "apache_con_num: %d\n", g_statistics->apache_con_num);
			fprintf(fp, "reading_client_num: %d\n", g_statistics->reading_client_num);
			fprintf(fp, "connecting_apache_num: %d\n", g_statistics->connecting_apache_num);
			fprintf(fp, "writing_apache_num: %d\n", g_statistics->writing_apache_num);
			fprintf(fp, "reading_apache_writing_client_num: %d\n", 
					g_statistics->reading_apache_writing_client_num);
            
			fprintf(fp, "wait_handle_num: %d\n", g_statistics->wait_handle_num);
			fprintf(fp, "\n");

			fprintf(fp, "closed_by_client_num: %d\n", g_statistics->closed_by_client_num);
			fprintf(fp, "reset_by_peer_num: %d\n", g_statistics->reset_by_peer_num);
			fprintf(fp, "broken_pipe_num: %d\n", g_statistics->broken_pipe_num);
			fprintf(fp, "request_method_error_num: %d\n", g_statistics->request_method_error_num);
			fprintf(fp, "request_too_long_num: %d\n", g_statistics->request_too_long_num);
			fprintf(fp, "connect_apache_error_num: %d\n", g_statistics->connect_apache_error_num);
			fprintf(fp, "\n");

			fprintf(fp, "read_client_timeout_num: %d\n", g_statistics->read_client_timeout_num);
			fprintf(fp, "write_apache_timeout_num: %d\n", g_statistics->write_apache_timeout_num);
			fprintf(fp, "connect_apache_timeout_num: %d\n", g_statistics->connect_apache_timeout_num);
			fprintf(fp, "read_apache_write_client_timeout_num: %d\n", 
					g_statistics->read_apache_write_client_timeout_num);
			fprintf(fp, "interval_write_client_timeout_num: %d\n", 
					g_statistics->interval_write_client_timeout_num);
			fprintf(fp, "\n");

			fprintf(fp, "black_deny_num: %d\n", g_statistics->black_deny_num);
			fprintf(fp, "limit_deny_num: %d\n", g_statistics->limit_deny_num);
			fprintf(fp, "no_inbuff_num: %d\n", g_statistics->inbuff_overflow_num);
			fprintf(fp, "no_outbuff_num: %d\n", g_statistics->outbuff_overflow_num);
			fprintf(fp, "\n");
			
			fprintf(fp, "average_request_time_used: %d\n", 
					g_statistics->completed_num>0 ? \
					g_statistics->completed_time_used/g_statistics->completed_num : 0);
			fprintf(fp, "average_error_time_used: %d\n", 
					g_statistics->read_client_error_num>0 ? \
					g_statistics->read_client_time_used/g_statistics->read_client_error_num : 0 +
					g_statistics->write_apache_error_num>0 ? \
					g_statistics->write_apache_time_used/g_statistics->write_apache_error_num : 0 +
					g_statistics->read_apache_write_client_error_num>0 ? \
					g_statistics->read_apache_write_client_time_used/\
					g_statistics->read_apache_write_client_error_num : 0);
                        fprintf(fp, "prision_deny_num: %d\n", g_statistics->prision_deny_num);
                        
			g_statistics->completed_num = 0;
			g_statistics->completed_time_used = 0;
			g_statistics->read_client_error_num = 0;
		   	g_statistics->write_apache_error_num = 0;
		   	g_statistics->read_apache_write_client_error_num = 0;
		   	g_statistics->read_client_time_used = 0;
		   	g_statistics->write_apache_time_used = 0;
			g_statistics->read_apache_write_client_time_used = 0;



#ifdef EXTRA_STATISTICS
			fprintf(fp, "\n");
			fprintf(fp, "read_client_ratio: %f\n", g_statistics->success_request_num>0 ? \
					(float)g_statistics->read_client_num/g_statistics->success_request_num : 0);
			fprintf(fp, "write_apache_ratio: %f\n", g_statistics->success_request_num>0 ? \
					(float)g_statistics->write_apache_num/g_statistics->success_request_num : 0);
			fprintf(fp, "read_apache_ratio: %f\n", g_statistics->success_request_num>0 ? \
					(float)g_statistics->read_apache_num/g_statistics->success_request_num : 0);
			fprintf(fp, "write_client_ratio: %f\n", g_statistics->success_request_num>0 ? \
					(float)g_statistics->write_client_num/g_statistics->success_request_num : 0);
			fprintf(fp, "\n");

			fprintf(fp, "read_client_wait_ratio: %f\n", g_statistics->success_request_num>0 ? \
					(float)g_statistics->read_client_wait_num/g_statistics->success_request_num : 0);
			fprintf(fp, "write_apache_wait_ratio: %f\n", g_statistics->success_request_num>0 ? \
					(float)g_statistics->write_apache_wait_num/g_statistics->success_request_num : 0);
			fprintf(fp, "read_apache_wait_ratio: %f\n", g_statistics->success_request_num>0 ? \
					(float)g_statistics->read_apache_wait_num/g_statistics->success_request_num : 0);
			fprintf(fp, "write_client_wait_ratio: %f\n", g_statistics->success_request_num>0 ? \
					(float)g_statistics->write_client_wait_num/g_statistics->success_request_num : 0);
			fprintf(fp, "\n");

			fprintf(fp, "read_client_1_ratio: %f\n", g_statistics->success_request_num>0 ? \
					(float)g_statistics->read_client_1_num/g_statistics->success_request_num : 0);
			fprintf(fp, "read_client_gt_1_le_3_ratio: %f\n", g_statistics->success_request_num>0 ? \
					(float)g_statistics->read_client_gt_1_le_3_num/g_statistics->success_request_num : 0);
			fprintf(fp, "read_client_gt_3_ratio: %f\n", g_statistics->success_request_num>0 ? \
					(float)g_statistics->read_client_gt_3_num/g_statistics->success_request_num : 0);
			fprintf(fp, "\n");

			fprintf(fp, "write_client_le_4_ratio: %f\n", g_statistics->success_request_num>0 ? \
					(float)g_statistics->write_client_le_4_num/g_statistics->success_request_num : 0);
			fprintf(fp, "write_client_gt_4_le_10_ratio: %f\n", g_statistics->success_request_num>0 ? \
					(float)g_statistics->write_client_gt_4_le_10_num/g_statistics->success_request_num : 0);
			fprintf(fp, "write_client_gt_10_ratio: %f\n", g_statistics->success_request_num>0 ? \
					(float)g_statistics->write_client_gt_10_num/g_statistics->success_request_num : 0);
			fprintf(fp, "\n");

			fprintf(fp, "time_used_le_100ms_ratio: %f\n", g_statistics->success_request_num>0 ? \
					(float)g_statistics->time_used_le_100_num/g_statistics->success_request_num : 0);
			fprintf(fp, "time_used_gt_100ms_le_300ms_ratio: %f\n", g_statistics->success_request_num>0 ? \
					(float)g_statistics->time_used_gt_100_le_300_num/g_statistics->success_request_num : 0);
			fprintf(fp, "time_used_gt_300ms_le_500ms_ratio: %f\n", g_statistics->success_request_num>0 ? \
					(float)g_statistics->time_used_gt_300_le_500_num/g_statistics->success_request_num : 0);
			fprintf(fp, "time_used_gt_500ms_ratio: %f\n", g_statistics->success_request_num>0 ? \
					(float)g_statistics->time_used_gt_500_num/g_statistics->success_request_num : 0);
			fprintf(fp, "\n");

			fprintf(fp, "select_time_used: %d\n", g_statistics->cycle_num>0 ? \
					g_statistics->select_time_used/g_statistics->cycle_num : 0);
			fprintf(fp, "cycle_time: %d\n", g_statistics->cycle_num>0 ? \
					g_statistics->process_time_used/g_statistics->cycle_num : 0); 
			fprintf(fp, "ready_handle_num: %d\n", g_statistics->cycle_num>0 ? \
					g_statistics->ready_handle_num/g_statistics->cycle_num : 0);
#endif
#ifndef EXTRA_STATISTICS
			fprintf(fp, "\n\n\n\n\n\n\n\n\n\n");
#endif
			fprintf(fp, "\n");
		}

		while(1)
		{
			if(time_type == TIME_SECOND)
				sleep(1);
			else
				sleep(10);

			time_secs = time(NULL);
			now  = *(localtime(&time_secs));
			switch(time_type)
			{
				case TIME_WEEK:
					if(now.tm_mday != old.tm_mday)
						now_interval++;
					break;

				case TIME_DAY:
					if(now.tm_mday != old.tm_mday)
						now_interval++;
					break;

				case TIME_HOUR:
					if(now.tm_hour != old.tm_hour)
						now_interval++;
					break;

				case TIME_MINUTE:
					if(now.tm_min != old.tm_min)
						now_interval++;
					break;

				case TIME_SECOND:
					if(now.tm_sec != old.tm_sec)
						now_interval++;
					break;


			}
			old = now;
			if(time_type == TIME_WEEK)
			{
				if(now_interval/7 >= refresh_interval)
					break;
			}
			else
			if(now_interval >= refresh_interval)
				break;
		}
		now_interval = 0;
	}
	if(fp != stderr)
		fclose(fp);

	deinit_shm();

	return 0;
}

