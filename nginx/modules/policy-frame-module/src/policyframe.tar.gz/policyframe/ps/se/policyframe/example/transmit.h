#ifndef __TRANSMIT__
#define __TRANSMIT__

#include "policy.h"
#include "public.h"
#include "prison.h"
#include "decode.h"

#define IP_FIELD_LEN		    33
#define MAX_PATH_LEN		    255
#define DISPATCH_NUM            1031

#define MAX_OP_NUM                  7
#define OP_ACCEPT                   1
#define OP_READ_CLIENT			    2
#define OP_CONNECTING_APACHE	    3
#define OP_WRITE_APACHE			    4
#define OP_READ_APACHE_WRITE_CLIENT 5
#define OP_COMPLETED			    6
#define OP_TESTING_APACHE		    7

#if defined(__DATE__) && defined(__TIME__)
static const char BuildDate[] = __DATE__ " " __TIME__;
#else
static const char BuildDate[] = "unknown";
#endif

#define PROJECT_NAME    "Transmit Module, Baidu.com, Incorporation"

#define CONFIG_NUM					    100
#define DEFAULT_PID_FILE				"./transmit.pid"
#define DEFAULT_CONFIG_PATH				"./conf/"
#define DEFAULT_CONFIG_FILE				"transmit.conf"
#define DEFAULT_LISTEN_PORT				8080
#define DEFAULT_LISTEN_ADDR				"any"
#define DEFAULT_APACHE_ADDR				"127.0.0.1"
#define DEFAULT_APACHE_PORT				8090

#define DEFAULT_DES_KEY                 "ZxdeacAD"

#define DEFAULT_MAX_CONNECTION_NUM			50000
#define DEFAULT_MIN_FREE_CONNECTION         3000

#define DEFAULT_MAX_OUTBUFF_NUM				1000
#define DEFAULT_READ_CLIENT_TIMEOUT			10000
#define DEFAULT_CONNECT_APACHE_TIMEOUT		10000
#define DEFAULT_CONNECT_PP_APACHE_TIMEOUT	10000

#define DEFAULT_WRITE_APACHE_TIMEOUT		10000
#define DEFAULT_READ_APACHE_WRITE_CLIENT_TIMEOUT	30000
#define DEFAULT_INTERVAL_WRITE_CLIENT_TIMEOUT		30000
#define DEFAULT_INBUFF_LEN				1024
#define DEFAULT_OUTBUFF_LEN				20*1024
#define DEFAULT_LOG_LEVEL				4
#define DEFAULT_LOG_SIZE				1024
#define DEFAULT_LOG_PATH				"./log"
#define DEFAULT_LOG_FILE				"transmit"
#define DEFAULT_LINGER_TIME				10
#define DEFAULT_SEND_BUFF_SIZE			0
#define DEFAULT_RECV_BUFF_SIZE			0
#define DEFAULT_LISTEN_NUM				5
#define DEFAULT_LISTEN_NUM				5
#define DEFAULT_MAX_CON_PER_IP		    20
#define DEFAULT_MIN_RESPONSE_TIME_TO_RECORD		0

#define DEFAULT_FAST_TIMER              100
#define DEFAULT_SLOW_TIMER              1000
#define DEFAULT_MAX_KEEP_ALIVE_TIME     180000
#define DEFAULT_NORMAL_READ_TIME        2000
#define DEFAULT_NORMAL_WRITE_TIME       8000

#define DEFAULT_MIN_READ_TIME_TO_RECORD     (-1)

#define DEFAULT_MAX_INNOCENT_NUM			    200
#define DEFAULT_MAX_BLACKLIST_NUM			    2000
#define DEFAULT_CONTIGUOUS_APACHE_ERROR_NUM		10

#define DEFAULT_PRISON_TERM				        600
#define DEFAULT_CHECK_CRIME_PERIOD			    600
#define DEFAULT_IP_CRIME_THRESHOLD			    180
#define DEFAULT_COOKIE_CRIME_THRESHOLD		    60
#define DEFAULT_PRISON_DICT_SIZE			    1000
#define DEFAULT_USER_DICT_SIZE				    60000

#define DEFAULT_DISPATCH_SCALE                  0
#define DEFAULT_RECOVER_TIME                    30

#define DEFAULT_BWS_DIR                         "/s? /baidu? /index.php?"
#define DEFAULT_BWS_PAGE                        "/ /index.html /index.htm"
#define DEFAULT_PP_APACHE_DIR                   "/pp?"

#define F_INNOCENT	    0x01

#define RETRY_NO_NEED   0
#define RETRY_FIRST     1
#define RETRY_AGAIN     2

#define COOKIE_LEN	    32
#define IP_LEN		    15

#define MAX_EVENTS_NUM  5000

#define DEFAULT_RAW_LOG_RATE    0

#define HTTP_KNOW       0
#define HTTP0_9         1
#define HTTP1_0         2
#define HTTP1_1         3

#define GATE_ENTER      0
#define GATE_LEAVE      1

// define how many levels we check crimes
#define CHECK_CRIME_LEVEL       2

/* define Apache types */
#define AP_TYPE_SINGLE          0
#define AP_TYPE_DOUBLE          1
#define AP_TYPE_RR              2

#define MAX_STR_LEN             64
#define MAX_STR_NUM             16

/*begin add by liulip 2007-11-05 */
#define DEFAULT_HOSTACL_FILE				"/home/work/search/conf/transmit/host_allow.acl"
#define DEFAULT_REFERACL_FILE				"/home/work/search/conf/transmit/refer_deny.acl"
#define DEFAULT_AGENTACL_FILE				"/home/work/search/conf/transmit/agent_deny.acl"
#define DEFAULT_HOST_FILTER         0
#define DEFAULT_REFER_FILTER         0
#define DEFAULT_AGENT_FILTER        0
#define MAX_HOSTACL_NUM 128
#define MAX_REFERACL_NUM 256
#define MAX_AGENTACL_NUM 256
#define MAX_REFERER_LEN 256 
#define MAX_CMD_LEN 255
/*end add by liulip 2007-11-05 */

typedef struct
{
    char data[MAX_STR_NUM][MAX_STR_LEN];
    int  len[MAX_STR_NUM];
    int  nelts;
}str_array_t;

#define HANDLE_INIT {-1, -1}
typedef struct 
{
    int fd;
    int status;
}handle_t;

/* define callback function return value */
#define ST_NEXT     1
#define ST_WAIT     0
#define ST_FAIL     -1

/* define events type and call back function */
#define EVT_FREE    0
#define EVT_FD      1
#define EVT_TIMER   2
#define EVT_ALWAYS  3
struct tag_Connection;
typedef int (*evt_func)(struct tag_Connection *conn, int type, int fid, int data);

typedef struct
{
	char regexp_row[MAX_CMD_LEN];
}regexp_row_t;

typedef struct tagApache
{
	int  type;
	bool available;
	int  port;
	int  contiguous_error_num;
	char host_name[MAX_PATH_LEN];
	struct in_addr addr;

	/* used for cookie */
	char         cookie_file[MAX_PATH_LEN];
	Sdict_search *cookie_dict;
	tagApache    *next;

	/* used for retrying */
	time_t  time_to_recover;
	struct tagApache *backup;
}Apache;

typedef struct
{
	int listen_port;
	int max_connection_num;	
	int max_outbuff_num;
	int log_level;
	int log_size;
	int max_innocent_num;
	int max_blacklist_num;
	int cur_innocent_num;
	int cur_blacklist_num;
	int read_client_timeout;
	int write_apache_timeout;
	int connect_apache_timeout;
	int connect_pp_apache_timeout;
	int read_apache_write_client_timeout;
	int interval_write_client_timeout;
	int max_con_per_ip;
	int min_response_time_to_record;
	int min_read_time_to_record;

	int fast_timer;
	int slow_timer;
	int max_keep_alive_time;
	int min_free_connection;
	int normal_read_time;
	int normal_write_time;

	int dispatch_scale;

	int inbuff_len;
	int outbuff_len;
	int listen_num;
	int send_buff_size;
	int recv_buff_size;
	/*begin add by liulip 2007-11-05 */

	int host_allow_on;/* ������*/
	int refer_deny_on;
	int agnet_deny_on;

	int cur_host_allow_num;/*��ǰ�������ʽ����*/
	int cur_refer_deny_num;
	int cur_agent_deny_num;

	char hostallow_acl[MAX_PATH_LEN];/*�������ʿ����б��ļ���*/
	char referdeny_acl[MAX_PATH_LEN];
	char agentdeny_acl[MAX_PATH_LEN];	
	
	regexp_row_t  host_filter[MAX_HOSTACL_NUM]; /*�������ʽ���ڴ�ṹ*/
	regexp_row_t  refer_filter[MAX_REFERACL_NUM];
	regexp_row_t  agent_filter [MAX_AGENTACL_NUM] ;

	/*end add by liulip 2007-11-05 */

	char pid_file[MAX_PATH_LEN];
	char listen_addr[MAX_PATH_LEN];
	char innocent_file[MAX_PATH_LEN];
	char blacklist_file[MAX_PATH_LEN];
	char log_path[MAX_PATH_LEN];
	char log_file[MAX_PATH_LEN];

	struct Filters prison_filters;

	int  raw_log_rate;
	char raw_log_file[MAX_PATH_LEN];

	int recover_time;   
	str_array_t search_dir;
	str_array_t search_page;
	str_array_t pp_dir;

	Apache *main_apache;
	Apache *branch_apache;
	Apache *dispatch_apache;
	Apache *bws;

	Apache *pp_apache;
	
}Config;

typedef struct 
{
	int client_con_num;
	int apache_con_num;
	int reading_client_num;
	int connecting_apache_num;
	int writing_apache_num;
	int reading_apache_writing_client_num;
	int wait_handle_num;					/* �ȴ��ľ������ */
    
	int closed_by_client_num;
	int reset_by_peer_num;
	int broken_pipe_num;
	int request_method_error_num;
	int request_too_long_num;
	int connect_apache_error_num;

	int read_client_timeout_num;
	int write_apache_timeout_num;
	int connect_apache_timeout_num;
	int read_apache_write_client_timeout_num;
	int interval_write_client_timeout_num;

	int black_deny_num;
	int limit_deny_num;
    
	int inbuff_overflow_num;
	int outbuff_overflow_num;

	int total_request_num;
	int success_request_num;

	int read_client_error_num;
	int read_client_time_used;
	int write_apache_error_num;
	int write_apache_time_used;
	int read_apache_write_client_error_num;
	int read_apache_write_client_time_used;
	int completed_num;
	int completed_time_used;
	int time_left;

    int prision_deny_num;

#ifdef	EXTRA_STATISTICS
	int read_client_num;				/* ���ͻ��˴��� */
	int write_apache_num;				/* дapache���� */
	int read_apache_num;				/* ��apache���� */
	int write_client_num;				/* д�ͻ��˴��� */

	int read_client_wait_num;			/* ���ͻ��˵ȴ��������� */
	int write_apache_wait_num;		/* дapache�ȴ������� */
	int read_apache_wait_num;			/* ��apache�ȴ������� */
	int write_client_wait_num;		/* д�ͻ��˵ȴ������� */

	int read_client_1_num;					/* һ�ζ��ͻ��˵������� */
	int read_client_gt_1_le_3_num;			/* ����1��С�ڵ���3�ζ��ͻ��˵������� */
	int read_client_gt_3_num;				/* ����3�ζ��ͻ��˵������� */

	int write_client_le_4_num;				/* С�ڵ���4��д�ͻ��˵������� */
	int write_client_gt_4_le_10_num;		/* ����4��С��10��д�ͻ��˵������� */
	int write_client_gt_10_num;				/* ����10��д�ͻ��˵������� */

	int time_used_le_100_num;				/* ��Ӧʱ��С��100����������� */
	int time_used_gt_100_le_300_num;		/* ��Ӧʱ�����100����С�ڵ���300����������� */
	int time_used_gt_300_le_500_num;		/* ��Ӧʱ�����300����С�ڵ���500����������� */
	int time_used_gt_500_num;				/* ��Ӧʱ�����500����������� */

	int cycle_num;							/* ��ѭ������ */
	int select_time_used;					/* select����ʱ�� */
	int process_time_used;					/* �����������ӻ���ʱ�� */

	int ready_handle_num;					/* �����ľ������ */
#endif

}Statistics;

typedef struct tag_OutBuff
{
	struct tag_OutBuff *next;
	bool empty;
	int  start;
	int  end;
	char buff[1];
}OutBuff;

#define MAX_TIMER_NUM 1
typedef struct tag_Connection
{
	list_t  node;

	int avail;
	int flag;
	int count;

	int         cur_op;
	evt_func	cur_proc;

	handle_t    client_sock;
	handle_t    apache_sock;

	int         inbuff_pos;
	int         inbuff_len;
	int         inbuff_next_len;

	char        *uri;

	int maybe_keepalive;
	int recv_from_server;

	struct timeval timer[MAX_TIMER_NUM];

	struct timeval enter_tv;
	struct timeval connect_apache_tv;
	struct timeval write_apache_tv;
	struct timeval read_apache_write_client_tv;
	struct timeval read_apache_write_client_data;
	struct timeval interval_write_client_tv;

#ifdef	EXTRA_STATISTICS
	int read_client_num;   /* ���ͻ��˴��� */
	int write_apache_num;	/* дapache���� */
	int read_apache_num;	/* ��apache���� */
	int write_client_num;	/* д�ͻ��˴��� */

	int read_client_wait_num; /* ���ͻ��˵ȴ��������� */
	int write_apache_wait_num; /* дapache�ȴ������� */
	int read_apache_wait_num; /* ��apache�ȴ������� */
	int write_client_wait_num; /* д�ͻ��˵ȴ������� */
#endif

	unsigned int    ip_sign[2];
	unsigned int    cookie_sign[2];
	char            ip_str[IP_LEN+1];
	char           cookie_str[COOKIE_LEN+1];
	int             http_version;

	struct in_addr  client_addr;
	    
	/* used for reading count and getting apache count */
	int             	retry_time;
	Apache          *apache;
	Apache          *first_pp_apache;
	OutBuff         *out_buff;
	char            in_buff[1];
}Connection;
/*begin modify by liulip 2007-11-05 */
typedef struct
{
	char  cur_config;	/* 0 or 1 */
	Config config[2];
	Statistics statistics;
}ShmConfig;
/*end modify by liulip 2007-11-05 */
typedef struct
{
	unsigned int start_addr;
	unsigned int end_addr;
}IpItem;

#endif
