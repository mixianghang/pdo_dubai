#include "policyframe.h"
#include "mc_type.h"
#include "mc_const.h"
#include "mc_cache.h"
#include "policy.h"
#include <ul_def.h>
#ifdef USETHREAD
#include <pthread.h>
#endif
#include <ul_net.h>

#define POLICYTEST 0
#define POLIOCYONLINE 1
#define DIS_Record    0 
#define DIS_NotRecord 1
typedef struct _UserVisit{
    int count;
    int lastcount;
    time_t time_stamp;
    short record;// this field is used to record if we are couted in the all bad user
} UserVisit;
enum BADSTAT {DANGER,SAFE} ;
typedef struct _DistributeAttactConf{
    mc_cache * cache_ptr;
#ifdef USETHREAD
    pthread_mutex_t cache_mutex;
#endif
    int period;
    int cachenum;
    int thredthold;

    int badusernum;
    enum BADSTAT laststatebaduser;
    time_t badusertimestamp;

    int baduserthreadthold;
    int baduserperiod;

    int policytest;//if test == 0 we are test

    int statid;
} DistributeAttactConf;

typedef DistributeAttactConf * DistributeAttactConfPtr;

//static
//int update_record(void *dest, int size, void *src);

mc_cache *
get_specific_distribute_data(xmlNodePtr pxmlnode, DistributeAttactConfPtr disconf_ptr, mc_cache *bigcache_ptr);

PatternMatchResult
distribute_stat(void *conn,void *arg,short *result,unsigned int *,unsigned int sign[2]);





