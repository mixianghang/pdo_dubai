#include "config.h"

const int CONFIG_TERM_NUM = 100;
const int CONFIG_FILE_NUM = 10;

static Ul_confdata * g_config_data[CONFIG_FILE_NUM];
static int g_config_size = 0;

/*
 * at most open ten configuration files.
 */ 
int add_config_data(char * config_path, char * config_file)
{
	if((NULL == config_path) || (NULL == config_file) || (CONFIG_FILE_NUM <= g_config_size)){
		return -1;
	}
	
	Ul_confdata * config_data = ul_initconf(CONFIG_TERM_NUM);
	if(config_data == NULL)
	{
		ul_writelog(UL_LOG_FATAL, "%s %d add_config_data: ul_initconfig() error",
				__FILE__, __LINE__);
		return -1;
	}
	if(ul_readconf(config_path, config_file, config_data) < 0)
	{
		ul_freeconf(config_data);
		ul_writelog(UL_LOG_FATAL, "%s %d add_config_data: ul_readconf() error",
				__FILE__, __LINE__);
		return -1;
	}

	g_config_data[g_config_size] = config_data;
	++g_config_size;

	return 0;
}

/*
 * free all resource
 */
void free_config_data()
{
	for(int turn = 0; turn < g_config_size; ++turn){
		ul_freeconf(g_config_data[turn]);
	}
	g_config_size = 0;
}

/*
 *  read int term from all open configuration files
 */
enum CONFIG_RET get_conf_int(char *name, int *pv, const int defaultv)
{
	if((0 >= g_config_size) || (NULL == name) || (NULL == pv)){
		return CONFIG_ERROR;
	}

	int turn = 0;
	while(turn < g_config_size){
		if(0 < ul_getconfint(g_config_data[turn], name, pv)){
			ul_writelog(UL_LOG_DEBUG, "transmit.conf : %s = %d", name, *pv);
			return CONFIG_FOUND;
		}
		++turn;
	}	

	if(turn >= g_config_size){
		*pv = defaultv;
		ul_writelog(UL_LOG_DEBUG, "transmit.conf : %s = %d(DFT)", name, *pv);
		return CONFIG_DEFAULT;
	}
	
	return CONFIG_ERROR;
}

/*
 * read string term from all open configuration files
 */
enum CONFIG_RET get_conf_str(char *name, char *pv, int pv_size, const char *defaultv)
{
	if((0 >= g_config_size) || (NULL == name) || (NULL == pv) || (0 >= pv_size)){
		return CONFIG_ERROR;
	}
	
	int turn = 0;
	while(turn < g_config_size){
		if(0 < ul_getconfstr(g_config_data[turn], name, pv)){
			ul_writelog(UL_LOG_DEBUG, "transmit.conf : %s = %s", name, pv);
			return CONFIG_FOUND;
		}
		++turn;
	}
	
	pv[0] = '\0';
	if((turn >= g_config_size) && (NULL != defaultv)){
		snprintf(pv, pv_size, "%s", defaultv);
		ul_writelog(UL_LOG_DEBUG, "transmit.conf : %s = %s(DFT)", name, pv);
		return CONFIG_DEFAULT;
	}
	
	return CONFIG_ERROR;
}

