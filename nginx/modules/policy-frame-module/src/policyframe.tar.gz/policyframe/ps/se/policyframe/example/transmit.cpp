#include "transmit.h"
#include "config.h"
enum {
	FILTER_HOST = 0 ,
	FILTER_REFER = 1,
	FILTER_AGENT = 2,
	FILTER_BUTT ,
} filter_type;

char g_config_path[MAX_PATH_LEN] = "\0";
char g_config_file[MAX_PATH_LEN] = "\0";

ShmConfig *g_shm_config = NULL;
Statistics *g_statistics = NULL;

/* Connections */
char *g_connection_mem = NULL;
/* 
 * In processing flow
 * connection will be taken from one queue to another 
 */ 
int    g_connection_free_num   = 0;
list_t g_connection_free       = LIST_HEAD_INIT(g_connection_free);
list_t g_connection_read       = LIST_HEAD_INIT(g_connection_read);
list_t g_connection_read_ag    = LIST_HEAD_INIT(g_connection_read_ag);
list_t g_connection_proc       = LIST_HEAD_INIT(g_connection_proc);
list_t g_connection_write      = LIST_HEAD_INIT(g_connection_write);

/* epoll file descriptor */
int g_epfd = -1;

handle_t g_accept_sock = HANDLE_INIT;

char *g_outbuff_mem = NULL;
OutBuff *g_outbuff_free = NULL;

int g_reload_proc_pid = -1;
int g_work_proc_pid = -1;

bool g_reload_flag = false;
bool g_terminate_flag = false;

int g_shm_key = 0x87435042;
int g_shm_id = -1;
char *g_shm_addr = NULL;

Sdict_reclaim *g_ip_dict = NULL;

struct timeval  g_now;

/* These pointers below are only used by work,
 * handle_connection will change
 * them if the config is reloaded */
Config *g_cur_config = NULL;
IpItem *g_cur_innocent_dict = NULL;
IpItem *g_cur_blacklist_dict = NULL;
	

/*
 *  Function property 
 */
int read_client(Connection *cur_connection, int type, int fid, int data);
int connecting_apache(Connection *cur_connection, int type, int fid, int data);
int write_apache(Connection *cur_connection, int type, int fid, int data);
int read_apache_write_client(Connection *cur_connection, int type, int fid, int data);
bool match_filter(char * buffer ,int type);

void show_usage(void)
{
printf("\n");
printf("Project    : %s\n", PROJECT_NAME);
printf("Version    : %s\n", VERSION);
printf("BuildDate  : %s\n", BuildDate);
printf("Description: transmit module\n");
printf("Usage: datacenter [-k] [-d] [-f] [-h] [-v]\n");
printf("\t-k\tshm_key, default: 0x87435042\n");
printf("\t-d\tconfig path, default: ./\n");
printf("\t-f\tconfig file, default: transmit.conf\n");
printf("\t-v|-h\tshow help and version, i.e. this page\n");
printf("\n");

return;
}

void get_option(int argc, char *argv[])
{
    int c;

    while((c=getopt(argc, argv, "k:d:f:hv")) != -1)
    {
        switch(c) 
        {
            case 'k':
                g_shm_key = atoi(optarg);
                break;
            case 'd':
                snprintf(g_config_path, MAX_PATH_LEN, "%s", optarg);
                break;
            case 'f':
                snprintf(g_config_file, MAX_PATH_LEN, "%s", optarg);
                break;
            case 'h':
            case 'v':
            case '?':
                show_usage();
			fprintf(stderr,"shm size=%d,tr_shmconfig_t=%d,%d\n",
				sizeof(ShmConfig),
				sizeof(Config),
				sizeof(Statistics));				
                exit(-1);
        }
    }
}

void sig_terminate(int sig)
{
	//ul_writelog(UL_LOG_DEBUG, "terminate signal");
    g_terminate_flag = true;
}

void sig_reload(int sig)
{
	//ul_writelog(UL_LOG_DEBUG, "reload signal");
    g_reload_flag = true;
}

int  init_signal(void)
{
    signal(SIGINT, SIG_IGN);
    signal(SIGQUIT, SIG_IGN);
    signal(SIGILL, SIG_IGN);
    signal(SIGTRAP, SIG_IGN);
    signal(SIGABRT, SIG_IGN);
    signal(SIGKILL, SIG_IGN);
    signal(SIGUSR1, SIG_IGN);
    signal(SIGUSR2, SIG_IGN);
    signal(SIGPIPE, SIG_IGN);
    signal(SIGALRM, SIG_IGN);
    signal(SIGCONT, SIG_IGN);

    signal(SIGHUP, sig_reload);
    signal(SIGTERM, sig_terminate);
    signal(SIGSTOP, sig_terminate);

    return 0;
}
/*begin add by liulip 2007-11-05 */

/*                                                                                                                                  
 * == FUNCTION DEFINITION ===================
 */
int matchstar(int c ,char * regexp ,char *text);
int matchhere(char * regexp ,char *text);

/*                                                                                                                                 
 *  support ^ $ * 
 * 
 */
int 
match(char *regexp, char *text)
{
    if  (regexp[0] == '^'){
        return matchhere(regexp+1,text);

    }   
    do{ 
        /*must look even if string is empty */
        if (matchhere(regexp,text)){
            return 1;
        }   
    }while (*text++ != '\0');
    return 0;
}

int 
matchhere(char * regexp ,char *text)
{
    if( regexp[0] == '\0' )
        return 1;
    if (regexp[1] == '*')
        return matchstar(regexp[0],regexp+2,text);
    if (regexp[0] == '$' && regexp[1] == '\0' )
        return *text == '\0' ;
    if ( *text != '\0' && ( regexp[0] == '.' || regexp[0] == *text ))
        return matchhere(regexp + 1 ,text  + 1 );

    return 0;
}
/*matchstar :search for c*regexp at beginning of text*/

int matchstar(int c ,char * regexp ,char *text)
{
    do{ /* a * matchs zero or more instances*/
        if (matchhere(regexp ,text))
            return 1;
    }while (*text != '\0' && (*text++ == c || c == '.' )); 
    return 0;
}


/*end add by liulip 2007-11-05 */
char *my_trim(char *buff)
{
    char *head;
    char *tail;

    if (buff[0] == 0)
        return buff;

    head = buff;
    tail = buff + strlen(buff) - 1;
    while (*head == ' ' || *head == '\r' || *head == '\n' || *head == '\t'
            || ((unsigned char)*head == 0xA1 && (unsigned char)*(head + 1) == 0xA1)) {
        if ((unsigned char)*head == 0xA1)
            *head++ = 0;
        *head++ = 0;
    }

    if (tail < head) {
        buff[0] = 0;
        return buff;
    }

    while (*tail == ' ' || *tail == '\r' || *tail == '\n' || *tail == '\t'
            || ((unsigned char)*tail == 0xA1 && (unsigned char)*(tail - 1) == 0XA1)) {
        if ((unsigned char)*tail == 0xA1)
            *tail -- = 0;
        *tail-- = 0;
    }

    memcpy(buff, head, tail - head + 1);

    buff[tail - head + 1] = 0;
    return buff;
}

/*
 *  timeval operation
 */
inline void __timeradd(struct timeval *a, long secs, long usecs)
{
    a->tv_sec += secs;
    if ((a->tv_usec += usecs) >= 1000000)
    {
        a->tv_sec += a->tv_usec / 1000000;
        a->tv_usec %= 1000000;
    }
}
inline void tv_add(struct timeval *a, long msecs)
{
    __timeradd(a, msecs / 1000, (msecs % 1000) * 1000);
}

/*
 *  return microseconds
 */
inline int tv_sub(const struct timeval *a, const struct timeval *b)
{
    return (a->tv_sec - b->tv_sec) * 1000 
        + (a->tv_usec - b->tv_usec) / 1000;
}

int block_read(int sock, char *buff, int blen)
{
    int ret_code;

    while(1)
    {
        ret_code = read(sock, buff, blen);
        if(ret_code<0 && errno==EINTR)
            continue;
        break;
    }

    if(ret_code < 0)
    {
        if(errno==ECONNRESET || errno==EPIPE)
        {
            if(errno == ECONNRESET)
                g_statistics->reset_by_peer_num++;
            else
                if(errno == EPIPE)
                    g_statistics->broken_pipe_num++;

            ul_writelog(UL_LOG_DEBUG, "%s %d block_read: read() error, %s", 
                    __FILE__, __LINE__, strerror(errno));
        }
        else
        {
            ul_writelog(UL_LOG_FATAL, "%s %d block_read: read() error, %s", 
                    __FILE__, __LINE__, strerror(errno));
        }
    }

    return ret_code;
}

int block_write(int sock, char *buff, int blen)
{
    int ret_code;

    while(1)
    {
        ret_code = write(sock, buff, blen);
        if(ret_code<0 && errno==EINTR)
            continue;
        break;
    }

    if(ret_code < 0)
    {
        if(errno == EAGAIN)
        {
            ret_code = 0;
        }
        else
            if(errno==ECONNRESET || errno==EPIPE)
            {
                if(errno == ECONNRESET)
                    g_statistics->reset_by_peer_num++;
                else
                    if(errno == EPIPE)
                        g_statistics->broken_pipe_num++;

                ul_writelog(UL_LOG_WARNING, "%s %d block_write: write() error, %s", 
                        __FILE__, __LINE__, strerror(errno));
            }
            else
            {
                ul_writelog(UL_LOG_FATAL, "%s %d block_write: write() error, %s", 
                        __FILE__, __LINE__, strerror(errno));
            }
    }

    return ret_code;
}

int block_close(int sock)
{
    int ret_code;

    while(1)
    {
        ret_code = close(sock);
        if(ret_code<0 && errno==EINTR)
            continue;
        break;
    }

    if(ret_code < 0)
    {
        ul_writelog(UL_LOG_FATAL, "%s %d block_close: close() error, %s", 
                __FILE__, __LINE__, strerror(errno));
    }

    return ret_code;
}
/*********************************************************************************
 *   Name     :  linger_close
 *   Comment  :�ԷǷ����ӣ�����RST����
 *   Create On: 
 *   Input    :  
 *   Output   : 
 *
 *********************************************************************************/

int linger_close(int sock)
{
    struct linger li;
    int ret_code = 0;
    li.l_onoff = 1;
    li.l_linger = 0; //ǿ�ƹرշ�RST

    if ((ret_code =setsockopt(sock, SOL_SOCKET, SO_LINGER, (char *) &li, sizeof(struct linger))) < 0) {
	 ul_writelog(UL_LOG_WARNING,  "setsockopt: (SO_LINGER),err = %d",ret_code);
    }
    ret_code = block_close(sock);
    return ret_code;
}

/* 
 *  events function
 */
int create_epoll(int num)
{
    g_epfd = epoll_create(num);
    if(g_epfd < 0)
    {
        ul_writelog(UL_LOG_FATAL, "create epoll error");
        return -1;
    }
    return 0;
}
struct epoll_event *alloc_ep_events(int num)
{
    struct epoll_event *ep;
    ep = (struct epoll_event *)malloc(sizeof(struct epoll_event) * num);
   	if(ep == NULL)
	{
		ul_writelog(UL_LOG_FATAL, "%s %d init_ep: malloc (), %s", 
					__FILE__, __LINE__, strerror(errno));
		return NULL;
	}
    memset(ep, 0, sizeof(struct epoll_event) * num);
    return ep;
}

/*
 *  epoll operation 
 */
inline int add_fd(Connection *conn, int fd, int events)
{
    int res;
    struct epoll_event evt;

    evt.events = events;
    evt.data.ptr = conn;
    res = epoll_ctl(g_epfd, EPOLL_CTL_ADD, fd, &evt);
    if(res < 0)
    {   
        ul_writelog(UL_LOG_FATAL, "%s %d add_fd: epoll_ctl(), %s",
                __FILE__, __LINE__, strerror(errno));
        return -1;
    }
    return 0;
}
inline int mod_fd(Connection *conn, int fd, int events)
{
    int res;
    struct epoll_event evt;

    evt.events = events;
    evt.data.ptr = conn;
    res = epoll_ctl(g_epfd, EPOLL_CTL_MOD, fd, &evt);
    if(res < 0)
    {   
        ul_writelog(UL_LOG_FATAL, "%s %d mod_fd: epoll_ctl(), %s",
                __FILE__, __LINE__, strerror(errno));
        return -1;
    }
    return 0;
}
inline int del_fd(int fd)
{
    int res;

    res = epoll_ctl(g_epfd, EPOLL_CTL_DEL, fd, NULL);
    if(res < 0)
    {   
        ul_writelog(UL_LOG_FATAL, "%s %d del_fd: epoll_ctl(), %s",
                __FILE__, __LINE__, strerror(errno));
        return -1;
    }
    return 0;
}

/* handle operation */
inline int init_handle(handle_t *handle)
{
    handle->fd = -1;
    handle->status = -1;
    return 0;
}
inline int add_handle(Connection *conn, handle_t *handle, int events)
{
    if(handle->fd < 0 || add_fd(conn, handle->fd, events) < 0)
    {
        return -1;
    }
    handle->status = events;

    g_statistics->wait_handle_num++;
    return 0;
}
inline int mod_handle(Connection *conn, handle_t *handle, int events)
{
    if(handle->fd < 0) 
    {
        return -1;
    }
    if(handle->status != events)
    {
        if(mod_fd(conn, handle->fd, events) < 0)
        {
            return -1;
        }
        handle->status = events;
    }
    return 0;
}
inline int del_handle(handle_t *handle)
{
    if(handle->status < 0 || handle->fd < 0)
    {
        return 0;
    }
    if(del_fd(handle->fd) < 0)
    {
        return -1;
    }
    handle->status = -1;

    g_statistics->wait_handle_num--;
    return 0;
}
inline int close_handle(handle_t *handle)
{
    del_handle(handle);
    if(handle->fd > 0)
    {
        block_close(handle->fd);
        handle->fd = -1;
    }
    return 0;
}

inline int init_timer(Connection *conn)
{
    int i;
    
    for(i = 0;i < MAX_TIMER_NUM; ++i)
    {
        conn->timer[i].tv_sec = -1;
    }
    return 0;
}
inline int mod_timer(Connection *conn, int id, int msec)
{
    if(0 <= id && id < MAX_TIMER_NUM)
    {
        conn->timer[id] = g_now;
        tv_add(&conn->timer[id], msec);
    }
    return 0;
}
/***************************/


int	del_from_ip_dict(struct in_addr *addr)
{
    Sdict_snode	dict_node;

    dict_node.sign1 = addr->s_addr;
    dict_node.sign2 = 0;

    if(dr_op1(g_ip_dict, &dict_node, SEEK) <= 0)
    {
        return -1;
    }
    else
    {
        dict_node.other--;
        if(dict_node.other <= 0)
        {
            dr_op1(g_ip_dict, &dict_node, DEL);
        }
        else
        {
            dr_op1(g_ip_dict, &dict_node, MOD);
        }
    }

    return 0;
}

int init_outbuff_mem(int max_outbuff_num, int outbuff_len)
{
    char *cur_outbuff_mem;
    OutBuff *cur_outbuff;
    OutBuff *old_outbuff;

    g_outbuff_mem = (char *)malloc((sizeof(OutBuff)+outbuff_len-1)*max_outbuff_num);
    if(g_connection_mem == NULL)
    {
        ul_writelog(UL_LOG_FATAL, "%s %d init_outbuff_mem: malloc(), %s", 
                __FILE__, __LINE__, strerror(errno));
        return -1;
    }

    memset(g_outbuff_mem, 0, (sizeof(OutBuff)+outbuff_len-1)*max_outbuff_num);
    old_outbuff = NULL;
    cur_outbuff_mem = g_outbuff_mem;
    cur_outbuff = (OutBuff *)cur_outbuff_mem;
    g_outbuff_free = cur_outbuff;
    for(int i=0; i<max_outbuff_num; i++)
    {
        if(old_outbuff)
            old_outbuff->next = cur_outbuff;
        old_outbuff = cur_outbuff;
        cur_outbuff_mem += (sizeof(OutBuff)+outbuff_len-1);
        cur_outbuff = (OutBuff *)cur_outbuff_mem;
    }

    return 0;
}

void deinit_outbuff_mem(void)
{
    if(g_outbuff_mem)
    {
        free(g_outbuff_mem);
        g_outbuff_mem = NULL;
        g_outbuff_free = NULL;
    }
}

OutBuff *alloc_outbuff(void)
{
    OutBuff *cur_outbuff = NULL;

    if(g_outbuff_free)
    {
        cur_outbuff = g_outbuff_free;
        g_outbuff_free = cur_outbuff->next;
        cur_outbuff->next = NULL;
        cur_outbuff->empty = true;
        cur_outbuff->start = 0;
        cur_outbuff->end = 0;
    }

    return cur_outbuff;
}

void free_outbuff(OutBuff *outbuff)
{
    outbuff->next = g_outbuff_free;
    g_outbuff_free = outbuff;
}



int  init_connection_mem(int max_connection_num, int inbuff_len)
{
    char *cur_connection_mem;
    Connection *cur_connection;

    g_connection_mem = (char *)malloc((sizeof(Connection)+inbuff_len-1)*max_connection_num);
    if(g_connection_mem == NULL)
    {
        ul_writelog(UL_LOG_FATAL, "%s %d init_connection_mem: malloc(), %s", 
                __FILE__, __LINE__, strerror(errno));
        return -1;
    }
    memset(g_connection_mem, 0, (sizeof(Connection)+inbuff_len-1)*max_connection_num);

    cur_connection_mem = g_connection_mem;
    cur_connection = (Connection *)cur_connection_mem;

    g_connection_free_num = max_connection_num;
    for(int i=0; i<max_connection_num; i++)
    {
        list_add(&cur_connection->node, &g_connection_free);
        cur_connection_mem += (sizeof(Connection)+inbuff_len-1);
        cur_connection = (Connection *)cur_connection_mem;
    }

    return 0;
}

void deinit_connection_mem(void)
{
    if(g_connection_mem)
    {
        free(g_connection_mem);
        g_connection_mem = NULL;

        INIT_LIST_HEAD(&g_connection_free);
        INIT_LIST_HEAD(&g_connection_read);
        INIT_LIST_HEAD(&g_connection_read_ag);
        INIT_LIST_HEAD(&g_connection_proc);
        INIT_LIST_HEAD(&g_connection_write);
    }
}

Connection *alloc_connection(list_t *to)
{
    Connection  *cur_connection = NULL;
    list_t      *node;

    if(!list_empty(&g_connection_free))
    {
        node = g_connection_free.next;
        list_move_tail(node, to);
        cur_connection = list_entry(node, Connection, node);

        cur_connection->avail = 1;
        g_connection_free_num--;
    }
    return cur_connection;
}

void record_log(Connection *cur_connection)
{    
    if((cur_connection->cur_op == OP_TESTING_APACHE)
			|| ((OP_READ_CLIENT == cur_connection->cur_op) && (1 < cur_connection->count))
			|| ((OP_READ_APACHE_WRITE_CLIENT == cur_connection->cur_op)
				&& (0 == cur_connection->write_apache_tv.tv_sec)
				&& (0 == cur_connection->write_apache_tv.tv_usec)))
    {
        return;
    }
	
    /* record the query too slow */
	char *end = strchr(cur_connection->in_buff, '\n');
	if(end != NULL)
	{
		if(end>cur_connection->in_buff && *(end-1)=='\r')
			*(end-1) = '\0';
		else 
			*end = '\0';
	}
	
	int read_client_tm = -1;
	int conn_apache_tm = -1;
	int write_apache_tm = -1;
	int write_client_tm = -1;
	if(cur_connection->cur_op > OP_READ_CLIENT){
		read_client_tm = tv_sub(&(cur_connection->connect_apache_tv), &(cur_connection->enter_tv));
	}
	if(cur_connection->cur_op > OP_CONNECTING_APACHE){
		conn_apache_tm = tv_sub(&(cur_connection->write_apache_tv), &(cur_connection->connect_apache_tv));
	}	
	if(cur_connection->cur_op > OP_WRITE_APACHE){
		write_apache_tm = tv_sub(&(cur_connection->read_apache_write_client_tv), &(cur_connection->write_apache_tv));
	}
	if(cur_connection->cur_op > OP_READ_APACHE_WRITE_CLIENT){
		write_client_tm = tv_sub(&g_now, &(cur_connection->read_apache_write_client_tv));
	}
	
	ul_writelog(UL_LOG_NOTICE, 
			"wrong process: [%s] [%d]bytes cnt[%d] op[%d] all[%d]ms [%d]ms [%d]ms [%d]ms [%d]ms [%s]",
			inet_ntoa(cur_connection->client_addr),
			cur_connection->inbuff_len,
			cur_connection->count,
			cur_connection->cur_op,
			tv_sub(&g_now, &cur_connection->enter_tv),
			read_client_tm,
			conn_apache_tm,
			write_apache_tm,
			write_client_tm,
			cur_connection->in_buff);
}

int make_testing_apache_connection(Apache *apache);

void free_connection(Connection *cur_connection)
{
    if(cur_connection->avail == 0)
    {
        return;
    }
    cur_connection->avail = 0;

    list_move(&cur_connection->node, &g_connection_free);
    g_connection_free_num++;

    record_log(cur_connection);

    if(!(cur_connection->flag&F_INNOCENT))
        del_from_ip_dict(&(cur_connection->client_addr));
    
    init_timer(cur_connection);
    close_handle(&cur_connection->client_sock);
    close_handle(&cur_connection->apache_sock);

    if(cur_connection->out_buff != NULL)
    {
        free_outbuff(cur_connection->out_buff);
        cur_connection->out_buff = NULL;
    }

    /* apache fatal error, listen port shutdown */
    if(cur_connection->cur_op != OP_TESTING_APACHE
            && cur_connection->apache!=NULL
            && cur_connection->apache->type == AP_TYPE_SINGLE
            && (cur_connection->apache)->contiguous_error_num>=DEFAULT_CONTIGUOUS_APACHE_ERROR_NUM)
    {
        if((cur_connection->apache)->available == true) 
        {
            (cur_connection->apache)->available = false;
            if(cur_connection->apache==g_cur_config->main_apache && g_accept_sock.fd >= 0)
            {
                close_handle(&g_accept_sock);
                ul_writelog(UL_LOG_WARNING, "[Apache]Listen port shutdown");
            }
        }
        if(make_testing_apache_connection(cur_connection->apache) == ST_WAIT)
        {
            (cur_connection->apache)->contiguous_error_num = 0;
        }
    }
}

int get_outbuff_data_room(OutBuff *out_buff, char **start_ptr)
{
    if(out_buff->empty == true)
        return 0;

    if(start_ptr != NULL)
        *start_ptr = &(out_buff->buff[out_buff->end]);
    if(out_buff->start > out_buff->end)
        return out_buff->start-out_buff->end;
    else
        return g_cur_config->outbuff_len-out_buff->end;
}

int move_outbuff_data_end(OutBuff *out_buff, int size)
{
    if(size == 0)
        return 0;

    if(out_buff->empty == true)
        return -1;

    out_buff->end += size;
    if(out_buff->end > g_cur_config->outbuff_len)
        return -1;
    else
        if(out_buff->end == g_cur_config->outbuff_len)
            out_buff->end = 0;

    if(out_buff->end == out_buff->start)
        out_buff->empty = true;

    return size;
}

int get_outbuff_free_room(OutBuff *out_buff, char **start_ptr)
{

    if(out_buff->empty==false && out_buff->start==out_buff->end)
        return 0;

    if(start_ptr != NULL)
        *start_ptr = &(out_buff->buff[out_buff->start]);

    if(out_buff->start >= out_buff->end)
        return g_cur_config->outbuff_len-out_buff->start;
    else
        return out_buff->end-out_buff->start;
}

int move_outbuff_data_start(OutBuff *out_buff, int size)
{
    if(size == 0)
        return 0;

    if(out_buff->empty==true || out_buff->start>out_buff->end)
    {
        out_buff->start += size;
        if(out_buff->start > g_cur_config->outbuff_len)
            return -1;

        if(out_buff->start == g_cur_config->outbuff_len)
            out_buff->start = 0;
        out_buff->empty = false;
    }
    else
        if(out_buff->start < out_buff->end)
        {
            out_buff->start += size;
            if(out_buff->start > out_buff->end)
                return -1;

        }
        else	/* full */
            return -1;

    return size;
}

int set_sock_nonblock(int s)
{
    int flag;

    while(1)
    {
        flag = fcntl(s, F_GETFL, 0);
        if(flag == -1)
        {
            if(errno == EINTR)
                continue;
            ul_writelog(UL_LOG_FATAL, "%s %d set_sock_nonblock: fcntl() error, %s", 
                    __FILE__, __LINE__, strerror(errno));
            return -1;
        }
        else
            break;
    }

    while(1)
    {
        if(fcntl(s, F_SETFL, flag|O_NONBLOCK) == -1)
        {
            if(errno == EINTR)
                continue;
            ul_writelog(UL_LOG_FATAL, "%s %d set_sock_nonblock: fcntl() error, %s", 
                    __FILE__, __LINE__, strerror(errno));
            return -1;
        }
        else
            break;
    }

    return 0;
}

/* 
 *  Write RAW log
 */
#define G2 2000000000L    
int write_raw_log(char *buf, int len)
{
    static int rawlog = -1;
    static int some_error = 0;
    static int flow_ps = 0;
    static int just = 0;

    struct stat st;
    int res;

    /* turn on raw log ? */
    if(g_cur_config->raw_log_file[0] == '\0')
    {
        goto last;
    }

    /* if we write too fast, slow it down */
    flow_ps++;
    if(time(0) > just)
    {
        just = time(0);
        flow_ps = 1;
        if(some_error > 0 && ++some_error > 10)
        {
            some_error = 0;
        }
    }
    if(flow_ps > g_cur_config->raw_log_rate)
    {
        goto last;
    }

    /* create raw log ? */
    if(rawlog == -1 && some_error == 0)
    {
        rawlog = open(g_cur_config->raw_log_file, O_WRONLY | O_CREAT, 0666);
    }
    if(rawlog == -1)
    {
        goto error;
    }

    /* test for rawlog error */
    if(stat(g_cur_config->raw_log_file, &st) == -1)
    {
        some_error = 10;
        goto error;
    }

    /* test for 2G limit */
    res = lseek(rawlog, 0, SEEK_END); 
    if(res < 0 || res > G2)
    {
        goto error;
    }

    /* write log */
    res = write(rawlog, buf, len);
    if(res < 0)
    {
        goto error;
    }
    return 0;

error:
    some_error++;
    if(rawlog != -1)
    {
        close(rawlog);
        rawlog = -1;
    }
last:
    return 0;
}

char *get_request_end(char *request, int rlen, int *last_enter)
{
    char *end = NULL;

    *last_enter = 0;
    for(int i=0; i<rlen; i++)
    {
        if(request[i]=='\r' && request[i+1]=='\n' &&
                request[i+2]=='\r' && request[i+3]=='\n')
        {
            end = &request[i + 4];
            *last_enter = 2;
            break;
        }
        else
            if(request[i]=='\n' && request[i+1]=='\n')
            {
                end = &request[i + 2];
                *last_enter = 1;
                break;
            }
    }

    return end;
}

/* 
 * return non-zero, if the current connection fits this directory
 */
int directory_dispatch(Connection *cur_connection, str_array_t *array)
{
    char *uri;
    int i;

    if(cur_connection->uri == NULL)
    {
        return 0;
    }
    uri = cur_connection->uri;

    for(i = 0;i < array->nelts;++i)
    {
        if(strncasecmp(array->data[i], uri, array->len[i]) == 0)
        {
            return 1;
        }
    }
    return 0;
}

int page_dispatch(Connection *cur_connection, str_array_t *array)
{
	char * uri_beg = NULL;
	if(NULL == (uri_beg = cur_connection->uri))
	{
		return 0;
	}	
	char * uri_end = NULL;
	if(NULL == (uri_end = strpbrk(uri_beg, " \t\r\n")))
	{
		/* uri format error */
		return 0;
	}
	
	const int uri_len = (int)(uri_end - uri_beg);	
	for(int i = 0; i < array->nelts; ++i)
	{
		if((uri_len == array->len[i])
				&& (strncmp(array->data[i], uri_beg, array->len[i]) == 0))
		{
			return 1;
		}
	}
	
	return 0;
}

Apache *get_apache(Connection *cur_connection)
{
    Sdict_snode cookie_node;
    Apache *cur_apache;
    unsigned int ip;
    time_t now = time(0);

    /* if it's time to retry the backup apache */
    if(cur_connection->retry_time > RETRY_FIRST)
    {
        cur_apache = cur_connection->apache;
        if(cur_apache == NULL)
        {
            goto return_apache;
        }
        if(cur_apache->type == AP_TYPE_DOUBLE)
        {
            if(cur_apache->available == true
                    && (cur_apache->contiguous_error_num 
                        >= DEFAULT_CONTIGUOUS_APACHE_ERROR_NUM))
            {
                ul_writelog(UL_LOG_WARNING, "[Apache]Set apache[%s] UNavailable", 
                        cur_apache->host_name);
                cur_apache->available = false;
                cur_apache->time_to_recover = 
                    now + g_cur_config->recover_time;
            }
            cur_apache = cur_apache->backup;
        }
        else if(cur_apache->type == AP_TYPE_RR)
        {
            cur_apache = cur_apache->next;
            if(cur_apache == cur_connection->first_pp_apache)
            {
                cur_apache = NULL;
            }
        }
        goto return_apache;
	}

	/* pp request */
	if(directory_dispatch(cur_connection, &(g_cur_config->pp_dir)))
	{
		ul_writelog(UL_LOG_DEBUG, "pp query");

		cur_apache = g_cur_config->pp_apache;
		if(cur_apache == NULL)
		{
			ul_writelog(UL_LOG_WARNING, "[Apache]PP request refused: No PP apache found");
			goto return_apache;
		}
		cur_connection->first_pp_apache = g_cur_config->pp_apache;

		/* Specify pp apache its own timeout value */
		mod_timer(cur_connection, 0, g_cur_config->connect_pp_apache_timeout);

		/* Round Robin */
		g_cur_config->pp_apache = g_cur_config->pp_apache->next;

		ul_writelog(UL_LOG_DEBUG, "get pp apache");
		goto return_apache;
	}

	/* search request */ 
	if(directory_dispatch(cur_connection, &(g_cur_config->search_dir))
			|| page_dispatch(cur_connection, &(g_cur_config->search_page)))
	{
		ul_writelog(UL_LOG_DEBUG, "search query");
		
        // cookie dispatch, need to use branch_apache?
        if(cur_connection->cookie_str[0] != '\0')
        {
            cookie_node.sign1 = cur_connection->cookie_sign[0];
            cookie_node.sign2 = cur_connection->cookie_sign[1];

            cur_apache = g_cur_config->branch_apache;
            while(cur_apache)
            {
                if(ds_op1(cur_apache->cookie_dict, &cookie_node, SEEK)>0)
                {
                    /* we got an apache to use in cur_apache */
                    goto return_apache;
                }
                cur_apache = cur_apache->next;
            }
        }

        // ip dispatch?
        ip = ntohl(cur_connection->client_addr.s_addr);
        if(g_cur_config->dispatch_apache != NULL
                && (int)(ip % DISPATCH_NUM) < g_cur_config->dispatch_scale)
        {
            cur_apache = g_cur_config->dispatch_apache;
            goto return_apache;
        }

        cur_apache = g_cur_config->bws;
		
		ul_writelog(UL_LOG_DEBUG, "get search apache");
        goto return_apache;
    }

    /* static request */
    cur_apache = g_cur_config->main_apache;
	ul_writelog(UL_LOG_DEBUG, "get main apache");

return_apache:
    while(cur_apache != NULL
            && cur_apache->type == AP_TYPE_DOUBLE
            && cur_apache->available == false)
    {
        if(now > cur_apache->time_to_recover)
        {
            ul_writelog(UL_LOG_WARNING, "[Apache]Reset apache[%s] available", 
                    cur_apache->host_name);
            cur_apache->available = true;
            break;
        }
        cur_apache = cur_apache->backup;
    }
   
    if(cur_apache != NULL)
    {
        ul_writelog(UL_LOG_DEBUG, "get_apache: conn[%u] apache[%s:%d]", 
                (unsigned int)cur_connection, 
                cur_apache->host_name, 
                ntohs(cur_apache->port));
    }

	if(cur_apache == g_cur_config->main_apache){
		ul_writelog(UL_LOG_DEBUG, "return main apache");
	}
	
    return cur_apache;
}

char *get_ip_in_query(char *query_string, int query_len)
{
    char *s = query_string;
    int i;
    
    for(i = 0;i < query_len; ++i)
    {
        if(*s=='\0' || *s=='\n')
            break;

        if(i + 3 < query_len && (*s=='?' || *s=='&'))
        {
            s++;
            i++;
            if(*s=='i' && *(s+1)=='p' && *(s+2)=='=')
                return s+3;
        }

        s++;
    }

    return NULL;
}

int parse_query(Connection *cur_connection)
{
	
	if((NULL == cur_connection) 
			|| (NULL == cur_connection->in_buff) 
			|| (0 >= cur_connection->inbuff_len)){
		return -1;
	}

	cur_connection->cookie_str[0] = '\0';
	
	const char con_cptr[] = "connection";
	const char close_cptr[] = "close";	
	const char cki_cptr[] = "cookie";
	const char cki_2_cptr[] = "cookie2";	
	const char baidu_id_cptr[] = "BAIDUID=";

	const char host_cptr[] = "Host";
	const char refer_cptr[] = "Referer";	
	const char agent_cptr[] = "User-Agent";
	char tmpbuff[MAX_CMD_LEN + 1];
	
	char * beg_ptr = cur_connection->in_buff;
	char * str_ptr = NULL;

	bool is_conn_par = false;
	bool is_cookie_par = false;

	bool is_host_par = false;
	bool is_refer_par = false;
	bool is_agent_par = false;
	
	while(NULL != (beg_ptr = strpbrk(beg_ptr, "\n"))){
		++beg_ptr;
		str_ptr = beg_ptr;
		is_conn_par = false;
		is_cookie_par = false;		

		 is_host_par = false;
		 is_refer_par = false;
		 is_agent_par = false;		
		 
		if( 0 == strncasecmp(str_ptr, con_cptr, sizeof(con_cptr) - 1) ){
			is_conn_par = true;
		}
		else if ( 0 == strncasecmp(str_ptr, refer_cptr, sizeof(refer_cptr) - 1) ){
			is_refer_par = true;
		}
		else if ( 0 == strncasecmp(str_ptr, agent_cptr, sizeof(agent_cptr) - 1) ){
			is_agent_par = true;
		}
		else if ( 0 == strncasecmp(str_ptr, host_cptr, sizeof(host_cptr) - 1) ){
			is_host_par = true;
		}
		else if( 0 == strncasecmp(str_ptr, cki_cptr, sizeof(cki_cptr) - 1)
				|| 0 == strncasecmp(str_ptr, cki_2_cptr, sizeof(cki_2_cptr) - 1)){
			is_cookie_par = true;
		}else{
			continue;
		}
		
		if( (NULL == (str_ptr = strpbrk(str_ptr, ":\n")))
				|| ('\n' == (*str_ptr))){
			continue;
		}
		if ( ('\0' == (*str_ptr)) || (NULL == strpbrk(str_ptr, "\n"))){
			continue;
		}
		// skip ':';
		do{
			++str_ptr;
		}while( (' ' == (*str_ptr)) || ('\t' == (*str_ptr)) || ('\r' == (*str_ptr)));
		if(is_conn_par 
				&& (0 == strncasecmp(str_ptr, close_cptr, strlen(close_cptr)))){
			
			cur_connection->maybe_keepalive = 0;
			ul_writelog(UL_LOG_DEBUG, "parse query: maybe_keepalive=%d", cur_connection->maybe_keepalive);

		}else if(is_cookie_par
				&& (0 == strncasecmp(str_ptr, baidu_id_cptr, strlen(baidu_id_cptr)))){

			str_ptr += strlen(baidu_id_cptr);

			int cookie_len = strpbrk(str_ptr, " \t\r\n:;") - str_ptr;
			cookie_len = (cookie_len <= COOKIE_LEN)? cookie_len : COOKIE_LEN;
			strncpy(cur_connection->cookie_str, str_ptr, cookie_len);
			cur_connection->cookie_str[cookie_len] = '\0';

			/*cookie may be fake*/
			if(is_valid_cookie(cur_connection->cookie_str)){
				creat_sign_fs64(cur_connection->cookie_str, cookie_len, 
						&(cur_connection->cookie_sign[0]), &(cur_connection->cookie_sign[1]));

				ul_writelog(UL_LOG_DEBUG, "parse query: cookie_str=[%s] cookie_sign=[%u]", 
						cur_connection->cookie_str, cur_connection->cookie_sign[0] + cur_connection->cookie_sign[1]);	
			}else{
				cur_connection->cookie_str[0] = '\0';
			}
		}	
		else if ((g_cur_config->host_allow_on == 1) && is_host_par){
			// ':' is order to skip  PORT;
			int host_len = strpbrk(str_ptr, " \t\r\n:") - str_ptr;	
			host_len = (host_len <= MAX_CMD_LEN)? host_len : MAX_CMD_LEN;
			strncpy(tmpbuff, str_ptr, host_len);
			tmpbuff[host_len] = '\0';	
			// skip most ,quickly
			if( 0 != memcmp(tmpbuff, "www.baidu.com", 13)){
				// case-sensitive
				for (int iter = 0; iter < host_len ;++iter){
					tmpbuff[iter] = tolower(tmpbuff[iter] );
				}			
				if (host_len > 0 && ( !match_filter(tmpbuff, FILTER_HOST) )){
					// only when dump rawlog,print
					if(g_cur_config->raw_log_file[0] != '\0'){
						ul_writelog(UL_LOG_WARNING, "parse query: host_str=[%s] ",tmpbuff);
					}
					g_statistics->black_deny_num++;
					return -1;
				}
			}
		}
		else if ((g_cur_config->refer_deny_on == 1) && is_refer_par ){
			int refer_len = strpbrk(str_ptr, " \t\r\n") - str_ptr;	
			refer_len = (refer_len <= MAX_CMD_LEN)? refer_len : MAX_CMD_LEN;
			strncpy(tmpbuff, str_ptr, refer_len);
			tmpbuff[refer_len] = '\0';
			if (refer_len > 0 && match_filter(tmpbuff, FILTER_REFER) ){
				if(g_cur_config->raw_log_file[0] != '\0'){
					ul_writelog(UL_LOG_WARNING, "parse query: refer_str=[%s] ",tmpbuff);
				}
				g_statistics->black_deny_num++;
				return -1;
			}
		}
		else if ((g_cur_config->agnet_deny_on == 1) && is_agent_par ){
			int agent_len = strpbrk(str_ptr, "\r\n") - str_ptr;	
			agent_len = (agent_len <= MAX_CMD_LEN)? agent_len : MAX_CMD_LEN;
			strncpy(tmpbuff, str_ptr, agent_len);
			tmpbuff[agent_len] = '\0';
			if (agent_len > 0 && match_filter(tmpbuff, FILTER_AGENT) ){
				if(g_cur_config->raw_log_file[0] != '\0'){
					ul_writelog(UL_LOG_WARNING, "parse query: agent_str=[%s] ",tmpbuff);
				}
				g_statistics->black_deny_num++;
				return -1;
			}
		}		
	}
	return 0;
}

int get_user_id(Connection *cur_connection)
{
    int  len;
    int  flag;
    unsigned int user_addr;
    unsigned int *ip_sign;
    char *ip = NULL;
    char *end;
    char *ip_str;
    char *user_query = cur_connection->in_buff;
	int query_len = cur_connection->inbuff_len;
    struct in_addr tmp_addr;

    user_addr = cur_connection->client_addr.s_addr;
    flag = cur_connection->flag;
    ip_sign = cur_connection->ip_sign;
    ip_str = cur_connection->ip_str;

    ip_str[0] = '\0';
    if (parse_query(cur_connection) < 0 ){
		return -1;
    }

    if(flag&F_INNOCENT)
    {
        ip = get_ip_in_query(user_query, query_len);
    }
    if(ip != NULL)
    {	
        end = strpbrk(ip, " &");
        if(end != NULL)
            len = end-ip;
        else
            len = strlen(ip);

        if(len > IP_LEN)
            return -1;

        memcpy(ip_str, ip, len);
        ip_str[len] = '\0';
        if(inet_aton(ip_str, &tmp_addr) == 0)
            return -1;

        /* use ip=, recreate the ip_sign */
        creat_sign_fs64((char *)&(tmp_addr.s_addr), sizeof(unsigned int), &ip_sign[0], &ip_sign[1]);
    }

    return 0;
}

bool is_valid_user(Connection *cur_connection)
{
	char ip_str[256];
	ip_str[0] = '\0';
	unsigned int now = (unsigned int)time(NULL);

	/* get real client ip */
	if(!(cur_connection->flag&F_INNOCENT) || ('\0' != cur_connection->ip_str[0])){
		if('\0' != cur_connection->ip_str[0]){
			snprintf(ip_str, sizeof(ip_str), "%s", cur_connection->ip_str);
		}else{
			inet_ntop(AF_INET, &(cur_connection->client_addr), ip_str, sizeof(ip_str));
		}
	}

	/* check ip crime 
	 * if assign ip= or search again in persistent connection
	 * recheck ip crime */	
	if('\0' != ip_str[0]){
		if(('\0' != cur_connection->ip_str[0]) || (1 < cur_connection->count)){
			if(0 < record_user(&(g_cur_config->prison_filters), cur_connection->ip_sign, PRISON_IP, now)){
				ul_writelog(UL_LOG_NOTICE, "Prison: uip=%s now=%u type=PRISON_IP", ip_str, now);
				return false;
			}

			if(should_deny(cur_connection->ip_sign, PRISON_IP, now)){
				ul_writelog(UL_LOG_NOTICE, "inPrison[%s]", ip_str);
				return false;
			}
		}
	}

	/* check session prison */
	if(('\0' != cur_connection->cookie_str[0]) || ('\0' != ip_str[0])){
		/* get session sign */
		char session_str[256];
		size_t session_len = 0;
		if('\0' != cur_connection->cookie_str[0]){
			session_len = snprintf(session_str, sizeof(session_str), "session=%s", cur_connection->cookie_str);
		}else{
			session_len = snprintf(session_str, sizeof(session_str), "session=%s", ip_str);
		}
		if(sizeof(session_str) <= session_len){
			session_len = sizeof(session_str) - 1;
		}
		unsigned int session_sign[2];
		creat_sign_fs64(session_str, session_len, &(session_sign[0]), &(session_sign[1]));

		if(0 < record_user(&(g_cur_config->prison_filters), session_sign, PRISON_SESSION, now)){
			ul_writelog(UL_LOG_NOTICE, 
					"Prison: ip=%s cookie=%s now=%u type=PRISON_SESSION", 
					ip_str, cur_connection->cookie_str, now);
			return false;
		}

		if(should_deny(session_sign, PRISON_SESSION, now)){
			ul_writelog(UL_LOG_NOTICE, "inPrison[%s] [%s]",	
					inet_ntoa(cur_connection->client_addr),	cur_connection->in_buff);
			return false;
		}	
	}

    return true;
}

int make_apache_connection(handle_t *con_sock, Apache *apache)
{
    int tmp_sock;
    sockaddr_in server_addr;

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = apache->port;
    (server_addr.sin_addr).s_addr = (apache->addr).s_addr;

    /* if we make connection more than twice, close the older one */
    close_handle(con_sock);
    
    if((tmp_sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)) == -1) 
    {
        ul_writelog(UL_LOG_FATAL, "%s %d make_apache_connection: socket() error, %s", 
                __FILE__, __LINE__, strerror(errno));
        return -1;
    }

    if(set_sock_nonblock(tmp_sock) == -1)
    {
        ul_writelog(UL_LOG_FATAL, "%s %d make_apache_connection: set_sock_nonblock() error", 
                __FILE__, __LINE__);
        return -1;
    }

    if(connect(tmp_sock, (struct sockaddr *)&server_addr, sizeof(struct sockaddr_in)) == -1) 
    {	
        if(errno !=  EINPROGRESS)
        {
            ul_writelog(UL_LOG_FATAL, "%s %d make_apache_connection: connect() error, %s", 
                    __FILE__, __LINE__, strerror(errno));
            block_close(tmp_sock);
            return -1;
        }
        con_sock->fd = tmp_sock;
        return 0;
    }
    con_sock->fd = tmp_sock;

    return 1;
}

void complete_statistics(Connection *cur_connection)
{
    int total_time_used = tv_sub(&g_now, &cur_connection->enter_tv);
    
    g_statistics->success_request_num++;
    g_statistics->completed_num++;
    g_statistics->completed_time_used += total_time_used;

#ifdef EXTRA_STATISTICS
    g_statistics->read_client_num += cur_connection->read_client_num;
    g_statistics->write_apache_num += cur_connection->write_apache_num;
    g_statistics->read_apache_num += cur_connection->read_apache_num;
    g_statistics->write_client_num += cur_connection->write_client_num;

    g_statistics->read_client_wait_num += cur_connection->read_client_wait_num;
    g_statistics->write_apache_wait_num += cur_connection->write_apache_wait_num;
    g_statistics->read_apache_wait_num += cur_connection->read_apache_wait_num;
    g_statistics->write_client_wait_num += cur_connection->write_client_wait_num;

    if(cur_connection->read_client_num <= 1)
        g_statistics->read_client_1_num++;
    if(cur_connection->read_client_num>1 && cur_connection->read_client_num<=3)
        g_statistics->read_client_gt_1_le_3_num++;
    if(cur_connection->read_client_num > 3)
        g_statistics->read_client_gt_3_num++;

    if(cur_connection->write_client_num <= 4)
        g_statistics->write_client_le_4_num++;
    if(cur_connection->write_client_num>4 && cur_connection->write_client_num<=10)
        g_statistics->write_client_gt_4_le_10_num++;
    if(cur_connection->write_client_num > 10)
        g_statistics->write_client_gt_10_num++;

    if(total_time_used <= 100)
        g_statistics->time_used_le_100_num++;
    else if(100 < total_time_used && total_time_used<=300)
        g_statistics->time_used_gt_100_le_300_num++;
    else if(300 < total_time_used && total_time_used<=500)
        g_statistics->time_used_gt_300_le_500_num++;
    else if(total_time_used > 500)
        g_statistics->time_used_gt_500_num++;
#endif
}

/*
 *  interface function
 */
int next_state(Connection *cur_connection, int ret_code)
{
    ul_writelog(UL_LOG_DEBUG,
            "op=[%d] ret=[%d]", cur_connection->cur_op, ret_code);
    switch(cur_connection->cur_op)
    {
        case OP_ACCEPT:
            if(add_handle(cur_connection, &cur_connection->client_sock, EPOLLIN | EPOLLERR |EPOLLHUP) < 0)
            {
                ul_writelog(UL_LOG_FATAL, "add_handle fail op[%d], fd[%d]", 
                        cur_connection->cur_op,
                        cur_connection->client_sock.fd);
                goto fail;
            }
            /* set queue timer */
            cur_connection->timer[0] = g_now;

            g_statistics->client_con_num++;
            g_statistics->reading_client_num++;

            cur_connection->cur_op = OP_READ_CLIENT;
            cur_connection->cur_proc = read_client;
            cur_connection->apache = NULL;
            break;
        case OP_READ_CLIENT:
            if(ret_code != ST_WAIT)
            {
                g_statistics->reading_client_num--;

                if(ret_code == ST_NEXT)
                {
                    if(mod_handle(cur_connection, &cur_connection->client_sock, EPOLLERR | EPOLLHUP) < 0)
                    {
                        ul_writelog(UL_LOG_FATAL, "mod_handle fail op[%d], fd[%d]", 
                                cur_connection->cur_op,
                                cur_connection->client_sock.fd);
                        goto fail;
                    }

                    list_move_tail(&cur_connection->node, &g_connection_proc);
                    mod_timer(cur_connection, 0, g_cur_config->connect_apache_timeout);
                    cur_connection->connect_apache_tv = g_now;

                    cur_connection->cur_op = OP_CONNECTING_APACHE;
                    cur_connection->cur_proc = connecting_apache;

                    g_statistics->connecting_apache_num++;
                }
                else if(ret_code == ST_FAIL)
                {
                    g_statistics->read_client_error_num++;
                    g_statistics->read_client_time_used += 
                        tv_sub(&g_now, &cur_connection->enter_tv);
                    g_statistics->client_con_num--;

                    goto fail;
                }
            }
            break;
        case OP_CONNECTING_APACHE:
            if(ret_code == ST_NEXT)
            {
                g_statistics->connecting_apache_num--;
                /* allocate out buffer */
                cur_connection->out_buff = alloc_outbuff();
                if(cur_connection->out_buff == NULL)
                {
                    g_statistics->outbuff_overflow_num++;
                    ul_writelog(UL_LOG_WARNING, 
                            "connecting_apache[%s]: alloc_outbuff(),no outbuff available",
                            cur_connection->apache->host_name);
                    g_statistics->client_con_num--;
                    goto fail;
                }

                if(mod_handle(cur_connection, &cur_connection->apache_sock, EPOLLOUT | EPOLLERR | EPOLLHUP) < 0)
                {
                    ul_writelog(UL_LOG_FATAL, "to write apache: mod handle err fd[%d]",
                            cur_connection->apache_sock.fd);
                    goto fail;
                }
                mod_timer(cur_connection, 0, g_cur_config->write_apache_timeout);
                cur_connection->write_apache_tv = g_now;

                cur_connection->cur_op = OP_WRITE_APACHE;
                cur_connection->cur_proc = write_apache;

                g_statistics->apache_con_num++;
                g_statistics->writing_apache_num++;
            }
            else if(ret_code == ST_FAIL)
            {
                if(cur_connection->apache != NULL)
                {
                    if((cur_connection->apache->type == AP_TYPE_DOUBLE
                                && cur_connection->apache->backup != NULL)
                            || cur_connection->apache->type == AP_TYPE_RR
                      ) 
                    {
                        cur_connection->retry_time = RETRY_AGAIN;
                        if(cur_connection->apache->type == AP_TYPE_DOUBLE)
                        {
                            mod_timer(cur_connection, 0, g_cur_config->connect_apache_timeout);
                        }
                        else if(cur_connection->apache->type == AP_TYPE_RR)
                        {
                            mod_timer(cur_connection, 0, g_cur_config->connect_pp_apache_timeout);
                        }
                        ret_code = ST_NEXT;
                        goto okay;
                    }
                }
                g_statistics->connecting_apache_num--;
                g_statistics->client_con_num--;
                goto fail;
            }
            break;
        case OP_WRITE_APACHE:
            if(ret_code != ST_WAIT)
            {
                g_statistics->writing_apache_num--;
                if(ret_code == ST_NEXT)
                {
                    if(mod_handle(cur_connection, &cur_connection->apache_sock, EPOLLIN | EPOLLERR | EPOLLHUP) < 0)
                    {
                        ul_writelog(UL_LOG_FATAL, "to read client: mod handle err fd[%d]",
                                cur_connection->client_sock.fd);
                        goto fail;
                    }

                    /* queue timer */
                    cur_connection->timer[0] = g_now;
                    list_move_tail(&cur_connection->node, &g_connection_write);
                   
		     cur_connection->read_apache_write_client_tv = g_now;
                    cur_connection->cur_op = OP_READ_APACHE_WRITE_CLIENT;
                    cur_connection->cur_proc = read_apache_write_client;

                    g_statistics->reading_apache_writing_client_num++;
                    ret_code = ST_WAIT;
                }
                else if(ret_code == ST_FAIL)
                {
                    g_statistics->write_apache_error_num++;
                    g_statistics->write_apache_time_used += 
                        tv_sub(&g_now, &cur_connection->write_apache_tv);
                    g_statistics->client_con_num--;
                    g_statistics->apache_con_num--;
                    goto fail;
                }
            }
            break;
        case OP_READ_APACHE_WRITE_CLIENT:
            if(ret_code == ST_NEXT)
            {
                g_statistics->reading_apache_writing_client_num--;
                complete_statistics(cur_connection);
		   if (0 != cur_connection->recv_from_server){
				ul_writelog(UL_LOG_NOTICE, 
						"complete [%s] [%d]bytes cnt[%d] all[%d]ms [%d]ms [%d]ms [%d]ms [%d]ms",
						inet_ntoa(cur_connection->client_addr),
						cur_connection->inbuff_len,
						cur_connection->count,
						tv_sub(&g_now, &cur_connection->enter_tv),
						tv_sub(&(cur_connection->connect_apache_tv), &(cur_connection->enter_tv)),
						tv_sub(&(cur_connection->write_apache_tv), &(cur_connection->connect_apache_tv)),
						tv_sub(&(cur_connection->read_apache_write_client_data), &(cur_connection->write_apache_tv)),
						tv_sub(&g_now, &(cur_connection->read_apache_write_client_data)));
				bzero(&(cur_connection->write_apache_tv), sizeof(struct timeval));
		   }
                if((g_cur_config->max_keep_alive_time <= 0)
						|| !(cur_connection->recv_from_server)
                        || !(cur_connection->maybe_keepalive))
                {
                    g_statistics->client_con_num--;
                    if(cur_connection->http_version < HTTP1_1)
                    {
                        ul_writelog(UL_LOG_DEBUG, "HTTP ver[%d] close", 
                                cur_connection->http_version);
                    }
                    goto fail;
                }
                
                /* next round */
				cur_connection->count++;
                cur_connection->retry_time = 0;
				cur_connection->recv_from_server = 0;
                ul_writelog(UL_LOG_DEBUG, "finish one cycle, once again");

                /* refresh timer */
                list_move_tail(&cur_connection->node, &g_connection_read_ag);
                cur_connection->timer[0] = g_now;

                /* free out buff */ 
                if(cur_connection->out_buff != NULL)
                {
                    free_outbuff(cur_connection->out_buff);
                    cur_connection->out_buff = NULL;
                }
                
                /* last time we left part of data in the buffer */
                if(cur_connection->inbuff_next_len > 0)
                {
                    memmove(cur_connection->in_buff, 
                            &cur_connection->in_buff[cur_connection->inbuff_len],
                            cur_connection->inbuff_next_len);

                    cur_connection->inbuff_len = cur_connection->inbuff_next_len;

                    cur_connection->enter_tv = g_now;
                    ret_code = ST_NEXT;
                } 
                else
                {
                    if(mod_handle(cur_connection, &cur_connection->client_sock, EPOLLIN | EPOLLERR | EPOLLHUP) < 0)
                    {
                        ul_writelog(UL_LOG_FATAL, "mod_handle fail op[%d], fd[%d]", 
                                cur_connection->cur_op,
                                cur_connection->client_sock.fd);
                        goto fail;
                    }

                    cur_connection->inbuff_len = 0;
                    ret_code = ST_WAIT;
                }

                cur_connection->inbuff_pos = 0;
                cur_connection->inbuff_next_len = 0;

                g_statistics->reading_client_num++;

                cur_connection->cur_proc = read_client;
                cur_connection->cur_op = OP_READ_CLIENT;
                cur_connection->apache = NULL;

#ifdef EXTRA_STATISTICS
                cur_connection->read_client_num = 0;
                cur_connection->write_apache_num = 0;
                cur_connection->read_apache_num = 0;
                cur_connection->write_client_num = 0;

                cur_connection->read_client_wait_num = 0;
                cur_connection->write_apache_wait_num = 0;
                cur_connection->read_apache_wait_num = 0;
                cur_connection->write_client_wait_num = 0;
#endif
            }
            else if(ret_code == ST_FAIL)
            { 
                if(cur_connection->avail == 0)
                {
                    ret_code = ST_WAIT;
                    goto okay;
                }
                g_statistics->client_con_num--;
                g_statistics->read_apache_write_client_error_num++;;
                g_statistics->read_apache_write_client_time_used += 
                    tv_sub(&g_now, &cur_connection->read_apache_write_client_tv);
                
                if(cur_connection->apache_sock.fd != -1)
                {
                    g_statistics->apache_con_num--;
                }
                g_statistics->reading_apache_writing_client_num--;
                goto fail;
            }
            break;
        case OP_COMPLETED:
            break;
        case OP_TESTING_APACHE:
            break;
    }
okay:    
    return ret_code;

fail:
    free_connection(cur_connection);
    return ST_FAIL;
}

int parse_first_line(Connection *cur_connection)
{
    char *start, *end;
    char *client_ip;

    client_ip = inet_ntoa(cur_connection->client_addr);
    start = cur_connection->in_buff;
    
    /* get method */
    if(strncmp(start, "GET", 3) && strncmp(start, "HEAD", 4))
    {
        g_statistics->request_method_error_num++;
        start[10] = '\0';
        if((end = strpbrk(start, " \n\r"))!=NULL)
            *end = '\0';

        ul_writelog(UL_LOG_WARNING, 
                "read_client[%s][%d]: request method[%s] is illegal", 
                client_ip, cur_connection->inbuff_len, start);
        return -1;
    }

    end = strpbrk(start, " \t\r\n");
    if(end == NULL)
    {
        start[80] = '\0';
        if((end = strpbrk(start, "\n\r"))!=NULL)
            *end = '\0';
        ul_writelog(UL_LOG_WARNING, 
                "read_client[%s][%d]: request format[%s] is illegal", 
                client_ip, cur_connection->inbuff_len, start);
        return -1;
    }
   
    /* get uri */
    start = end + 1;
    start += strspn(start, " \t\r\n");

	/* Check for HTTP/1.1 absolute URL. */
	if(strncasecmp(start, "http://", 7) == 0)
	{
		start = strchr(start + 7, '/');
		if(start == NULL)
		{
			ul_writelog(UL_LOG_WARNING, "http:// error in uri");
			return -1;
		}
	}

	if(*(start) != '/')
	{
		ul_writelog(UL_LOG_WARNING, "uri not begin with /");
		return -1;
	}
	
	cur_connection->uri = start;

    
    /* get version */
    end = strpbrk(start, " \t\r\n");
    if(end == NULL)
    {
        cur_connection->http_version = HTTP0_9;
		cur_connection->maybe_keepalive = 0;
    }
    else
    {
        start = end + 1;
        start += strspn(start, " \t\r\n");
        if(strncasecmp(start, "HTTP/1.1", 8) == 0)
        {
            cur_connection->http_version = HTTP1_1;
			if(0 != cur_connection->maybe_keepalive){
				cur_connection->maybe_keepalive = 1;
			}
        }
        else if(strncasecmp(start, "HTTP/1.0", 8) == 0)
        {
            cur_connection->http_version = HTTP1_0;
			cur_connection->maybe_keepalive = 0;
        }
        else
        {
            start = cur_connection->in_buff;
            start[80] = '\0';
            if((end = strpbrk(start, "\n\r"))!=NULL)
                *end = '\0';
            ul_writelog(UL_LOG_WARNING, 
                    "read_client[%s][%d]: request format[%s] is illegal", 
                    client_ip, cur_connection->inbuff_len, start);

            return -1;
        }
    }
    return 0;
}

int check_client_error_type(Connection *cur_connection)
{
    char *client_ip;
    int error;
    socklen_t len = sizeof(int);

    client_ip = inet_ntoa(cur_connection->client_addr);
    
    if(getsockopt(cur_connection->client_sock.fd, 
                SOL_SOCKET, SO_ERROR, (void *)&error, &len)<0)
    {
        ul_writelog(UL_LOG_FATAL, "client[%s]: getsockopt() error, %s", 
                client_ip, strerror(errno));
        return -1;
    }
    if(error != 0)
    {
        ul_writelog(UL_LOG_WARNING, "client error[%s]: [%d]%s",
                client_ip, error, strerror(error));

        if(error == ECONNRESET)
        {
            g_statistics->reset_by_peer_num++;
        }
        else if(error == EPIPE)
        {
            g_statistics->broken_pipe_num++;
        }
    }
    else
    {
        ul_writelog(UL_LOG_WARNING, "unknow error[%s]", client_ip);
    }
    return -1;
}
/*
 *  processing function
 */
int read_client(Connection *cur_connection, int type, int fid, int data)
{
    char *end;
    char *client_ip;
    char client_ip_buf[100];
    int  client_ip_len;

    int  time_used;
    int  last_enter;
    int  ret_code;

    client_ip = inet_ntoa(cur_connection->client_addr);

    if(type == EVT_TIMER)
    {
        time_used = tv_sub(&g_now, &cur_connection->enter_tv);
        if(cur_connection->count > 1)
        {
            ul_writelog(UL_LOG_NOTICE,
                    "timeout[%s][%d][%d] %dms", 
                    client_ip, cur_connection->inbuff_len, 
                    cur_connection->count, time_used);
        }
        else
        {
            g_statistics->read_client_timeout_num++;
            ul_writelog(UL_LOG_WARNING,
                    "read client timeout[%s][%d][%d] %dms", 
                    client_ip, cur_connection->inbuff_len, 
                    cur_connection->count, time_used);
        }
        goto fail;
    }
    if(type == EVT_FD)
    {

#ifdef EXTRA_STATISTICS
        cur_connection->read_client_num++;
#endif
        cur_connection->retry_time++;
        /* next round enter time is set when fd first become ready */
        if(cur_connection->count > 1 && cur_connection->retry_time == 1)
        {
            cur_connection->enter_tv = g_now;
        }

        ul_writelog(UL_LOG_DEBUG, "read client fd=%d", cur_connection->client_sock.fd);
        
        /* read 
         * leave space for IP_FIELD and '\0' */
        ret_code = block_read(cur_connection->client_sock.fd, 
                &cur_connection->in_buff[cur_connection->inbuff_len], 
                g_cur_config->inbuff_len 
                - cur_connection->inbuff_len 
                - IP_FIELD_LEN - 1);

        /* close or errors */
        if(ret_code == 0)
        {
            g_statistics->closed_by_client_num++;
            if(cur_connection->count > 1)
            {
                ul_writelog(UL_LOG_NOTICE, 
                        "close[%s] cnt=%d", 
                        client_ip, cur_connection->count - 1);
            }
            else
            {
                ul_writelog(UL_LOG_WARNING, "client close[%s]", client_ip);
            }
            goto fail;
        }
        else if(ret_code < 0)
        {
            ul_writelog(UL_LOG_WARNING, 
                    "read_client[%s][%d]: read socket error", 
                    client_ip, cur_connection->inbuff_len);
            goto fail;
        }

        /* read some data */
        if(cur_connection->count > 1)
        {
            g_statistics->total_request_num++;
        }
        cur_connection->inbuff_len += ret_code;
    }
    else if(cur_connection->inbuff_len < 0 
            || cur_connection->inbuff_len > g_cur_config->inbuff_len - 1)
    {
        goto fail;
    }
    cur_connection->in_buff[cur_connection->inbuff_len] = '\0'; 
    
    /* have we reached end */
    end = get_request_end(cur_connection->in_buff, 
            cur_connection->inbuff_len, 
            &last_enter);
    
    /* not yet */
    if(end == NULL)
    {
        /* no space left, but query still continues */
        if(g_cur_config->inbuff_len 
                - cur_connection->inbuff_len
                - IP_FIELD_LEN - 1 <= 0)
        {
            g_statistics->request_too_long_num++;
            ul_writelog(UL_LOG_WARNING, 
                    "read_client[%s]: request is too long, len=%d", 
                    client_ip, cur_connection->inbuff_len);
            goto fail;
        }

        /* continue to wait for data */
        if(type == EVT_ALWAYS && cur_connection->count > 1)
        {
            if(mod_handle(cur_connection, &cur_connection->client_sock, EPOLLIN | EPOLLERR | EPOLLHUP) < 0)
            {
                ul_writelog(UL_LOG_FATAL, "mod_handle fail:to read_ag fd[%d]", 
                        cur_connection->client_sock.fd);
                goto fail;
            }
        }
        goto wait;
    }
    
    cur_connection->inbuff_next_len = 
        cur_connection->inbuff_len - (end - cur_connection->in_buff);


    char *temp;
    int returncode;
    quest_t conn;
    
    temp = (char*)malloc(cur_connection->inbuff_len*sizeof(char));
    strncpy(temp, cur_connection->in_buff, cur_connection->inbuff_len);
    conn.in_buffer = temp;
    conn.client_addr.s_addr = cur_connection->client_addr.s_addr;
    conn.length = cur_connection->inbuff_len;
    returncode = processPolicy(&conn, 0);
    BWSDEBUG("BWS-RTCODE = %d", returncode);
    free(temp);
    /* 
     *  parse query 
     */
    if(parse_first_line(cur_connection) < 0)
    {
        goto fail;
    }
    
    if(get_user_id(cur_connection) < 0)
    {
        ul_writelog(UL_LOG_WARNING, "read_client: get_user_id error");
        goto fail;
    }

    if(!is_valid_user(cur_connection))
    {
        g_statistics->prision_deny_num++;
        goto fail;
    }

    /* add CLIENTIP header */
    client_ip_len = snprintf(client_ip_buf, sizeof(client_ip_buf), 
            "CLIENTIP: %s\r\n\r\n", inet_ntoa(cur_connection->client_addr));

    /* move next part back */
    if(cur_connection->inbuff_next_len > 0)
    {
        memmove(end + client_ip_len - last_enter, 
                end, 
                cur_connection->inbuff_next_len);
    }

    memcpy(end - last_enter, client_ip_buf, client_ip_len);
    cur_connection->inbuff_len = 
        end - cur_connection->in_buff + client_ip_len - last_enter;

    /* We got a request now, write raw log for http server testing */
    write_raw_log(cur_connection->in_buff, cur_connection->inbuff_len);

    /* 'get apache' and 'connect to apache' will be done in CONNECTING_APACHE */
    cur_connection->retry_time = RETRY_FIRST;
    
/* next: */
    return next_state(cur_connection, ST_NEXT);
    
wait:
    return ST_WAIT;
    
fail:
    return next_state(cur_connection, ST_FAIL);
}

int connecting_apache(Connection *cur_connection, int type, int fid, int data)
{
    int s;
    int error = 0, ret_code = 0;
    socklen_t len = sizeof(int);
    int time_used;

    if(type == EVT_TIMER)
    {
        if((cur_connection->apache)->available == true)
            (cur_connection->apache)->contiguous_error_num++;

        g_statistics->connect_apache_timeout_num++; 
        time_used = tv_sub(&g_now, &cur_connection->connect_apache_tv);
        ul_writelog(UL_LOG_WARNING, "[Apache]connect_apache[%s]: timeout %dms",
                cur_connection->apache->host_name,
                time_used);
        goto fail;
    }
    else if(type == EVT_ALWAYS)
    {
        cur_connection->apache = get_apache(cur_connection);
        if(cur_connection->apache == NULL)
        {
            ul_writelog(UL_LOG_WARNING, "read_client: get_apache() error");
            goto fail;
        }

        ret_code = make_apache_connection(&cur_connection->apache_sock, cur_connection->apache);
        if(ret_code >= 0)
        {
            if(add_handle(cur_connection, &cur_connection->apache_sock, 
                        EPOLLIN | EPOLLOUT | EPOLLERR | EPOLLHUP) < 0)
            {
                goto fail;
            }
            if(ret_code == 0)
            {
                goto wait;
            }
            /* ret_code > 0 */
            goto next;
        }
        else /* ret_code < 0 */
        {
            if((cur_connection->apache)->available == true)
                (cur_connection->apache)->contiguous_error_num++;

            ul_writelog(UL_LOG_FATAL, 
                    "read_client[%s]: connect_apache() error", 
                    inet_ntoa(cur_connection->client_addr));
            goto fail;
        }
    }
    else if(type == EVT_FD)
    {
        /*
         *  check apache connection
         */
        s = cur_connection->apache_sock.fd;
        if(getsockopt(s, SOL_SOCKET, SO_ERROR, (void *)&error, &len)<0)
        {
            if((cur_connection->apache)->available == true)
                (cur_connection->apache)->contiguous_error_num++;

            g_statistics->connect_apache_error_num++;
            ul_writelog(UL_LOG_FATAL, "connecting_apache[%s]: getsockopt() error, %s", 
                    cur_connection->apache->host_name, strerror(errno));
            goto fail;
        }
        if(error != 0)
        {
            if((cur_connection->apache)->available == true)
                (cur_connection->apache)->contiguous_error_num++;
            g_statistics->connect_apache_error_num++;
            ul_writelog(UL_LOG_WARNING, 
                    "[Apache]connecting_apache[%s]: getsockopt(), status is error, %d", 
                    cur_connection->apache->host_name, error);
            goto fail;
        }
        
        /*
         *  apache connection ok, client errors occurred?
         */
        if(data & (EPOLLERR | EPOLLHUP))
        {
            check_client_error_type(cur_connection);
            
            /* give up retry */
            cur_connection->apache = NULL;
            goto fail;
        }
    }
next:
    return next_state(cur_connection, ST_NEXT);

wait:
    cur_connection->retry_time = RETRY_NO_NEED;
    return ST_WAIT;

fail:
    return next_state(cur_connection, ST_FAIL);
}


int write_apache(Connection *cur_connection, int type, int fid, int data)
{
    int ret_code = 0;
    int time_used;

    if(type == EVT_TIMER)
    {
        time_used = tv_sub(&g_now, &cur_connection->write_apache_tv);
        g_statistics->write_apache_timeout_num++;
        ul_writelog(UL_LOG_WARNING, "[Apache]write_apache[%s]: timeout %dms", 
                (cur_connection->apache)->host_name,
                time_used);
        goto fail;
    }
    else if(type == EVT_FD)
    {
#ifdef EXTRA_STATISTICS
        cur_connection->write_apache_num++;
#endif
        ret_code = block_write(cur_connection->apache_sock.fd, 
                &cur_connection->in_buff[cur_connection->inbuff_pos], 
                cur_connection->inbuff_len-cur_connection->inbuff_pos);

        if(ret_code > 0)
        {
            cur_connection->inbuff_pos += ret_code;
            if(cur_connection->inbuff_pos >= cur_connection->inbuff_len)
            {
                goto next;
            }
        }
        else if(ret_code < 0)
        {
            ul_writelog(UL_LOG_FATAL, 
                    "write_apache[%s]: block_write() error", 
                    (cur_connection->apache)->host_name);
            goto fail;
        }

        /* apache socket ok, client error? */
        if(data & (EPOLLERR | EPOLLHUP))
        {
            check_client_error_type(cur_connection); 
            goto fail;
        }
 
    }
/* wait: */
    return ST_WAIT;
next:
    return next_state(cur_connection, ST_NEXT);
fail:
    return next_state(cur_connection, ST_FAIL);
}

int read_apache(Connection *cur_connection, int type, int fid, int data)
{
    int len;
    int ret_code = 0;
    char *ptr;
    char client_ip[50];
    char *apache_ip;
    OutBuff *out_buff;

    if(type != EVT_FD)
    {
        goto fail;
    }

    out_buff = cur_connection->out_buff;
    apache_ip = (cur_connection->apache)->host_name;

    if(cur_connection->apache_sock.fd == -1)
    {
        del_handle(&cur_connection->apache_sock);
        goto wait;
    }

#ifdef EXTRA_STATISTICS
    cur_connection->read_apache_num++;
#endif
    if((len=get_outbuff_free_room(out_buff, &ptr)) > 0)
    {
        ret_code = block_read(cur_connection->apache_sock.fd, ptr, len);
        if(ret_code > 0)
        {
			if(0 == cur_connection->recv_from_server){
				cur_connection->read_apache_write_client_data = g_now;
			}
			
			cur_connection->recv_from_server = 1;
            (cur_connection->apache)->contiguous_error_num  = 0;
            if(move_outbuff_data_start(cur_connection->out_buff, ret_code) < 0)
            {
                strcpy(client_ip, inet_ntoa(cur_connection->client_addr));
                ul_writelog(UL_LOG_FATAL, "read_apache_write_client[%s %s]: "
                        "move_outbuff_data_start() error, "
                        "start=%d, end=%d, empty=%d, add_size=%d", 
                        apache_ip, client_ip, out_buff->start, out_buff->end,
                        out_buff->empty, ret_code);
                goto fail;
            }
        }
        else if(ret_code == 0)
        {
            ul_writelog(UL_LOG_DEBUG, "finish reading apache");
            g_statistics->apache_con_num--;

            close_handle(&cur_connection->apache_sock);
        }
        else /* ret_code < 0 */
        {
            strcpy(client_ip, inet_ntoa(cur_connection->client_addr));
            ul_writelog(UL_LOG_FATAL, 
                    "read_apache_write_client[%s %s]: block_read() error",
                    apache_ip, client_ip);
            goto fail;
        }
    }
    else
    {
        /* 
         * no space left, stop waiting apache, 
         * wait client instead, see code below 
         */
        if(mod_handle(cur_connection, &cur_connection->apache_sock, 
                    EPOLLERR | EPOLLHUP) < 0)
        {
            ul_writelog(UL_LOG_FATAL, "read apache: mod handle err fd[%d]",
                    cur_connection->apache_sock.fd);
            goto fail;
        }

#ifdef EXTRA_STATISTICS
        cur_connection->read_apache_wait_num++;
#endif
    }
    /* we can write to client 
     * when no space left in the buffer or data(eof) arrived at apache */
    if(len <= 0 || ret_code >= 0)
    {
        if(mod_handle(cur_connection, &cur_connection->client_sock, 
                    EPOLLOUT | EPOLLERR | EPOLLHUP) < 0)
        {
            ul_writelog(UL_LOG_FATAL, "read apache: mod handle err fd[%d]",
                    cur_connection->client_sock.fd);
            goto fail;
        }
    }
    
wait:
    return ST_WAIT;
    
fail:
    return next_state(cur_connection, ST_FAIL);
}

int write_client(Connection *cur_connection, int type, int fid, int data)
{
    int len;
    int ret_code = 0;
    char *ptr;
    char client_ip[50];
    int time_used;
    char *apache_ip = (cur_connection->apache)->host_name;;
    OutBuff *out_buff = cur_connection->out_buff;
    
    if(type == EVT_TIMER)
    {
        time_used = tv_sub(&g_now, &cur_connection->read_apache_write_client_tv);
        strcpy(client_ip, inet_ntoa(cur_connection->client_addr));
        
        g_statistics->interval_write_client_timeout_num++;
        ul_writelog(UL_LOG_WARNING, 
                "read_apache_write_client[%s %s]: interval write client timeout %dms", 
                apache_ip, client_ip, time_used);
        goto fail;
    }
    if(type != EVT_FD)
    {
        goto fail;
    }

#ifdef EXTRA_STATISTICS
    if(!out_buff->empty || cur_connection->apache_sock.fd !=-1)
        cur_connection->write_client_num++;
#endif

    if(out_buff->empty && cur_connection->apache_sock.fd==-1)
    {
        goto next;
    }
    else if((len=get_outbuff_data_room(out_buff, &ptr)) > 0)
    {
        ret_code = block_write(cur_connection->client_sock.fd, ptr, len);
        
        ul_writelog(UL_LOG_DEBUG, "buf len=[%d], wrt=[%d]", len, ret_code);
        
        if(ret_code > 0)
        {
            /* refrush timer */
            list_move_tail(&cur_connection->node, &g_connection_write);
            cur_connection->timer[0] = g_now;
            
            if(move_outbuff_data_end(cur_connection->out_buff, ret_code) < 0)
            {	
                strcpy(client_ip, inet_ntoa(cur_connection->client_addr));
                ul_writelog(UL_LOG_FATAL, 
                        "read_apache_write_client[%s %s]: move_outbuff_data_end() "
                        "error, start=%d, end=%d, empty=%d, del_size=%d", 
                        apache_ip, client_ip, out_buff->start, out_buff->end,
                        out_buff->empty, ret_code);
                goto fail;
            }
        }
        else if(ret_code < 0)
        {
            strcpy(client_ip, inet_ntoa(cur_connection->client_addr));
            ul_writelog(UL_LOG_WARNING, 
                    "read_apache_write_client[%s %s]: write_client() error",
                    apache_ip, client_ip);
            goto fail;
        }
    } 

    /*
     *  no data left now, finish or stop waiting client 
     *  and wait for apache, see code below
     */
    if(len <= 0 || out_buff->empty)
    {
        if(cur_connection->apache_sock.fd==-1)
        {
            goto next;
        }
        else
        {
            if(mod_handle(cur_connection, &cur_connection->client_sock, EPOLLERR | EPOLLHUP) < 0)
            {
                ul_writelog(UL_LOG_FATAL, "write client: mod handle err fd[%d]",
                        cur_connection->client_sock.fd);
                goto fail;
            }
        }
#ifdef EXTRA_STATISTICS
        cur_connection->write_client_wait_num++;
#endif
    }
    /*  we can read apache 
     *  when apache is alive 
     *      and no data left in the buffer or data(eof) have been taken away from client */
    if(cur_connection->apache_sock.fd > 0
            && (len <= 0 || ret_code > 0 || out_buff->empty))      
    {
        if(mod_handle(cur_connection, &cur_connection->apache_sock, 
                    EPOLLIN | EPOLLERR | EPOLLHUP) < 0)
        {
            ul_writelog(UL_LOG_FATAL, "write client: mod handle err fd[%d]",
                    cur_connection->apache_sock.fd);
            goto fail;
        }
    }
 
/* wait: */
    return ST_WAIT;
    
next:
    return next_state(cur_connection, ST_NEXT);

fail:
    return next_state(cur_connection, ST_FAIL);
}

int read_apache_write_client(Connection *cur_connection, int type, int fid, int data)
{
    char client_ip[50], *apache_ip;
	
    int time_used;

    time_used = tv_sub(&g_now, &cur_connection->read_apache_write_client_tv);
    if(time_used > g_cur_config->read_apache_write_client_timeout)
    {
        strcpy(client_ip, inet_ntoa(cur_connection->client_addr));
        apache_ip = (cur_connection->apache)->host_name;

        g_statistics->read_apache_write_client_timeout_num++;
        ul_writelog(UL_LOG_WARNING, "read_apache_write_client[%s %s]: timeout %dms", 
                apache_ip, client_ip, time_used);
        goto fail;
    }
    if(type == EVT_TIMER)
    {
        return write_client(cur_connection, type, fid, data);
    }
    else if(type == EVT_FD)
    {
        if(data & EPOLLIN)
        {
            return read_apache(cur_connection, type, fid, data);
        }
        else if(data & EPOLLOUT)
        {
            return write_client(cur_connection, type, fid, data);
        }
    }
fail:
    return next_state(cur_connection, ST_FAIL);
}
/*********************************************************************************
 *   Name     :  ip_sort_cmp
 *   Comment  :��start_addr ���дӴ�С����
 *   Create On: 2007-03-27 add by liulp for sort 
 *   Input    :  
 *   Output   : 
 *
 *********************************************************************************/
static int 
ip_sort_cmp(const  void * a,const void *b)
{
	IpItem * aa = (IpItem *)a;
	IpItem * bb = (IpItem *)b;
	if (aa->start_addr < bb->start_addr){
		return 1;
	}
	if (aa->start_addr >bb->start_addr){
		return -1;
	}
	return 0;
}
/*********************************************************************************
 *	 Name	  :  ����������ֲ��� ,�����������������������С�Ĵ�����
 *	 Comment  ://search 	a.	 ������ 
 *	 Input	  :  
 *	 Output   : 
 *
 *********************************************************************************/
static inline int
ip_bisearch_desc(IpItem * a, int lower, int upper, unsigned int t)
{
    if (upper - lower == 1 || (upper == 0 && lower == 0)) {
	 //t	 is between upper and lower
        if (a[lower].start_addr <= t)
            return lower;
        return upper;
    }
    // bigger is at front
    int mid = (lower + upper) / 2;
    if (a[mid].start_addr < t) {
	  // found first equal;
        return ip_bisearch_desc(a, lower, mid, t);
    }
    if (a[mid].start_addr > t){
    	return ip_bisearch_desc(a, mid, upper, t);
    }
    return mid;
}
/*********************************************************************************
 *   Name     :  seek_dict_entry
 *   Comment  :
 *   Create on : 
 *   Input    :  
 *   Output   : 
 *   Last Modified   :2007-03-27 add by liulp for sort 
 *********************************************************************************/

int 
seek_dict_entry(IpItem *dict, int size, unsigned int addr)
{
	if ( size < 1) {
		return -1;
	}
	int mid = ip_bisearch_desc(dict,0,size-1,addr);
	if(addr>=dict[mid].start_addr && addr<=dict[mid].end_addr){
		return 0;
	}
      return -1;
}

int insert_into_dict(IpItem *dict, int cur_size, IpItem addr)
{

    dict[cur_size] = addr;

    return 1;
}

int load_dict(IpItem *dict, int size, char *file_name)
{
    int  ip_num = 0;
    int  ret_code;
    char *start;
    char line[255];
    char addr_str1[100];
    char addr_str2[100];
    char addr_str3[100];
    FILE *fp;
    struct in_addr start_addr;
    struct in_addr end_addr;
    IpItem addr_item;

    if(file_name[0] == '\0')
        return 0;

    if((fp=fopen(file_name, "rb")) == NULL) 
    {
        ul_writelog(UL_LOG_FATAL, "%s %d load_dict: fopen(%s) error, %s", 
                __FILE__, __LINE__, file_name, strerror(errno));
        return -1;
    }

    while(1)
    {
        if(fgets(line, sizeof(line), fp) == NULL)
            break;

        start = line;
        while(1)
        {
            if(*start!=' ' && *start!='\t')
                break;

            start++;
        }

        if(start[0]=='#' || start[0]=='\r' || start[0]=='\n') 
            continue;

        ret_code = sscanf(start, "%s %s %s", addr_str1, addr_str2, addr_str3);
        if(ret_code == 1)
            strcpy(addr_str2, addr_str1);
        else
            if(ret_code == 2)
            {
                if(inet_aton(addr_str2, &end_addr) == 0)
                    strcpy(addr_str2, addr_str1);
            }
            else
                if(ret_code == 3)
                {
                    strcpy(addr_str2, addr_str3);
                }

        ret_code = inet_aton(addr_str1, &start_addr);
        if(ret_code == 0) 
        {
            ul_writelog(UL_LOG_WARNING, "load_dict: the format of start-IP is error, start-IP=%s", addr_str1);
            continue;
        }

        ret_code = inet_aton(addr_str2, &end_addr);
        if(ret_code == 0) 
        {
            ul_writelog(UL_LOG_WARNING, "load_dict: the format of end-IP is error, end-IP=%s", addr_str2);
            continue;
        }

        if(ip_num >= size)
        {
            ul_writelog(UL_LOG_WARNING, "load_dict: entry size exceeded");
            break;
        }
        addr_item.start_addr = ntohl(start_addr.s_addr);
        addr_item.end_addr = ntohl(end_addr.s_addr);
	  if (addr_item.start_addr >addr_item.end_addr){
	  	ul_writelog(UL_LOG_WARNING, "load_dict: start_addr larger end_addr,ignore");
	  	continue;
	  }
        ip_num += insert_into_dict(dict, ip_num, addr_item);
    }

    fclose(fp);

	/*Begin : 2007-03-27 add by liulp for sort  */
	if (ip_num >0){
		// (�Ӵ�С)
		qsort(dict,ip_num,sizeof(IpItem),ip_sort_cmp);
	}
	/*End */
	/*check overlap*/
	if (ip_num<=0){
		return ip_num;
	}
	int merge_item_cnt = 0;
	for (int ii = 0; ii < ip_num - 1; ++ii) {
		if (dict[ii].end_addr == 0 || dict[ii].start_addr == 0) {
			continue;
		}
		for (int jj = ii + 1; jj < ip_num; ++jj) {
		        if (dict[jj].end_addr == 0 || dict[jj].start_addr == 0) {
		            continue;
		        }
		        if (dict[jj].end_addr >= dict[ii].start_addr) {
		            //change start
		            dict[ii].start_addr = dict[jj].start_addr;
		            // change end
		            if (dict[jj].end_addr >= dict[ii].end_addr) {
		                dict[ii].end_addr = dict[jj].end_addr;
		            }
		            dict[jj].start_addr = 0;
		            dict[jj].end_addr = 0;
		            merge_item_cnt++;
		            // merge item;
		            for (int kk = ii + 1; kk < jj; ++kk) {
		                if (dict[kk].end_addr == 0 || dict[kk].start_addr == 0) {
		                    continue;
		                }
		                dict[kk].start_addr = 0;
		                dict[kk].end_addr = 0;
		                merge_item_cnt++;
		            }
		        }
		 }
	}   
	if (ip_num >0 && merge_item_cnt>0){
		// (�Ӵ�С)
		qsort(dict,ip_num,sizeof(IpItem),ip_sort_cmp);
		ul_writelog(UL_LOG_WARNING,"ip overlap found,%s,orig=%d,merge=%d",file_name,ip_num,merge_item_cnt);
		ip_num-=merge_item_cnt;
	}	
	for (int ii = 0 ; ii < ip_num ; ++ii){
		ul_writelog(UL_LOG_NOTICE,"%s,%d,ip1=%u,ip2=%u",file_name,ii,dict[ii].start_addr,dict[ii].end_addr);
	}
    return ip_num;
}


int create_ip_dict(void)
{
    if((g_ip_dict=dr_creat(g_cur_config->max_connection_num, 0)) == NULL) 
    {
        ul_writelog(UL_LOG_FATAL, "%s %d build_ip_dict: dr_creat() error", __FILE__, __LINE__);
        return -1;
    }

    return 0;
}

void delete_ip_dict(void)
{
    if(g_ip_dict == NULL)
        return;
    dr_del(g_ip_dict);
    g_ip_dict = NULL;
}

bool is_innocent(unsigned int addr)
{
    if(g_cur_innocent_dict == NULL)
        return false;

    if(seek_dict_entry(g_cur_innocent_dict, g_cur_config->cur_innocent_num, addr) >= 0)
        return true;

    return false;
}

bool is_in_blacklist(unsigned int addr)
{
    if(g_cur_blacklist_dict == NULL) 
        return false;

    if(seek_dict_entry(g_cur_blacklist_dict, g_cur_config->cur_blacklist_num, addr) >= 0)
        return true;


    return false;
}

bool connection_exceeded(struct in_addr addr)
{
    int ret_code;
    Sdict_snode	dict_node;

    dict_node.sign1 = addr.s_addr;
    dict_node.sign2 = 0;

    ret_code = dr_op1(g_ip_dict, &dict_node, SEEK);
    if(ret_code < 0)
    {
        ul_writelog(UL_LOG_WARNING, "connecion_exceeded: dr_op1(SEEK) error");
    }
    else
        if(ret_code == 0)
        {
            dict_node.other = 1;
            if(dr_op1(g_ip_dict, &dict_node, ADD) < 0)
                ul_writelog(UL_LOG_WARNING, "connecion_exceeded: dr_op1(ADD) error");
        }
        else
        {
            if((int)dict_node.other >= g_cur_config->max_con_per_ip)
                return true;
            else
            {
                dict_node.other++;
                if(dr_op1(g_ip_dict, &dict_node, MOD) < 0)
                    ul_writelog(UL_LOG_WARNING, "connecion_exceeded: dr_op1(MOD) error");
            }
        }

    return false;
}


bool is_valid_connection(struct in_addr client_addr, int *flag)
{
    unsigned int host_addr;

    *flag = 0;
    host_addr = ntohl(client_addr.s_addr);
    if(is_innocent(host_addr) == true)
    {
        *flag = F_INNOCENT;
        return true;
    }

    if(is_in_blacklist(host_addr) == true)
    {
        g_statistics->black_deny_num++;
        ul_writelog(UL_LOG_WARNING, "check_connection[%s]: in black list", inet_ntoa(client_addr));
        return false;
    }
    if(connection_exceeded(client_addr) == true)
    {
        g_statistics->limit_deny_num++;
        ul_writelog(UL_LOG_WARNING, "check_connection[%s]: connection exceeded", inet_ntoa(client_addr));
        return false;
    }

    return true;
}

int accept_new_connection()
{
    int flag;
    int client_sock;
    socklen_t addr_len;
    struct sockaddr client_addr;
    struct in_addr addr;
    Connection *cur_connection;
    unsigned int ip_sign[2];

    if(g_accept_sock.fd == -1)
    {
        return 0;
    }

    while(1)
    {
        addr_len = sizeof(client_addr);
        client_sock = accept(g_accept_sock.fd, &client_addr, &addr_len);

        ul_writelog(UL_LOG_DEBUG, "accept fd=%d", client_sock);
        
        if(client_sock < 0)
        {
            if(errno == EINTR)
            {
                continue;
            }
            else if(errno == EAGAIN || errno == EWOULDBLOCK)
            {
                break;
            }
            else if(errno == EMFILE)
            {
                ul_writelog(UL_LOG_FATAL, "accept_new_connection: accept() error, %s", strerror(errno));
                break;
            }
            else if(errno == ECONNABORTED)
            {
                ul_writelog(UL_LOG_FATAL, "accept_new_connection: accept() error, %s", strerror(errno));
                break;
            }
            else
            {
                ul_writelog(UL_LOG_FATAL, "accept_new_connection: accept() error, %s", strerror(errno));
                return -1;
            }
        }

        g_statistics->total_request_num++;

        if(is_valid_connection(((sockaddr_in *)&client_addr)->sin_addr, &flag) == false)
        {
            //block_close(client_sock);
            linger_close(client_sock);
            continue;
        }

        /* create ip sign for IP crime check */
        addr = ((sockaddr_in *)&client_addr)->sin_addr;
        creat_sign_fs64((char *)&addr, sizeof(struct in_addr), &ip_sign[0], &ip_sign[1]);
		unsigned int now = (unsigned int)time(NULL);
		
        if(!(flag & F_INNOCENT))
		{
			bool deny = false;
			
			char ip_str[256];
			inet_ntop(AF_INET, &(((sockaddr_in *)&client_addr)->sin_addr), ip_str, sizeof(ip_str));
						
			int prison_type = 0;
			if(0 != (prison_type = record_user(&(g_cur_config->prison_filters), ip_sign, PRISON_CONN | PRISON_IP, now)))
			{
				char p_t[256];
				ul_writelog(UL_LOG_NOTICE, "Prison : uip=%s now=%u type=%s", 
						ip_str, now, get_prison_type(prison_type, p_t));				
				deny = true;
			}
			
			if( !deny && should_deny(ip_sign, PRISON_CONN | PRISON_IP, now))
			{			
				ul_writelog(UL_LOG_NOTICE, "inPrison[%s]", ip_str);
				deny = true;
			}
			
			if(deny){
				g_statistics->prision_deny_num++;
				//block_close(client_sock);
				linger_close(client_sock);
				del_from_ip_dict(&addr);
				continue;
			}
        }

        cur_connection = alloc_connection(&g_connection_read);
        if(cur_connection == NULL)
        {
            del_from_ip_dict(&(((sockaddr_in *)&client_addr)->sin_addr));
            g_statistics->inbuff_overflow_num++;
            block_close(client_sock);
            ul_writelog(UL_LOG_FATAL, "accept_new_connection: alloc_connection(), "
                    "no connection unit available;");
            break;
        }
        if(set_sock_nonblock(client_sock) == -1)
        {
            del_from_ip_dict(&(((sockaddr_in *)&client_addr)->sin_addr));
            ul_writelog(UL_LOG_FATAL, "accept_new_connection: set_sock_nonblock() error");
            return -1;
        }		

        cur_connection->flag = flag;
        cur_connection->count = 1;
        cur_connection->client_sock.fd      = client_sock;
        cur_connection->client_sock.status  = -1;
        cur_connection->apache_sock.fd      = -1;
        cur_connection->apache_sock.status  = -1;
        
        cur_connection->client_addr = ((sockaddr_in *)&client_addr)->sin_addr;
        cur_connection->ip_sign[0] = ip_sign[0];
        cur_connection->ip_sign[1] = ip_sign[1];
        
        cur_connection->out_buff = NULL;
		cur_connection->recv_from_server = 0;
		cur_connection->maybe_keepalive = 1;

        cur_connection->enter_tv = g_now;
        cur_connection->retry_time = 0;
        init_timer(cur_connection);

#ifdef EXTRA_STATISTICS
        cur_connection->read_client_num = 0;
        cur_connection->write_apache_num = 0;
        cur_connection->read_apache_num = 0;
        cur_connection->write_client_num = 0;

        cur_connection->read_client_wait_num = 0;
        cur_connection->write_apache_wait_num = 0;
        cur_connection->read_apache_wait_num = 0;
        cur_connection->write_client_wait_num = 0;
#endif
        cur_connection->inbuff_pos = 0;
        cur_connection->inbuff_len = 0;
        cur_connection->inbuff_next_len = 0;
        cur_connection->in_buff[0] = '\0';
        
        cur_connection->cur_op = OP_ACCEPT;
        if(next_state(cur_connection, ST_WAIT) == ST_FAIL)
        {
            return ST_FAIL;
        }
    }
    return 0;
}

int testing_apache(Connection *cur_connection, int type, int fid, int data)
{
    int s;
    int error = 0;
    int ret_code;
    char obuff[25];
    char *apache_ip;
    socklen_t len = sizeof(int);

    mod_timer(cur_connection, 0, 2000);
    apache_ip = (cur_connection->apache)->host_name;
    if(cur_connection->apache_sock.fd == -1)
    {
        ret_code = make_apache_connection(&cur_connection->apache_sock, cur_connection->apache);
        if(ret_code == 1)
        {
            if(block_write(cur_connection->apache_sock.fd, 
                        cur_connection->in_buff,
                        cur_connection->inbuff_len) != cur_connection->inbuff_len)
            {
                ul_writelog(UL_LOG_WARNING, 
                        "[Apache]testing_apache[%s]: write apache error", apache_ip);
                goto fail;
            }
            cur_connection->inbuff_len = 0;
        }
        else if(ret_code < 0)
        {
            ul_writelog(UL_LOG_FATAL, 
                    "%s %d testing_apache: make_apache_connection() error", 
                    __FILE__, __LINE__);
            return ST_FAIL;
        }
        else /* wait for connect */
        {
            if(add_handle(cur_connection, &cur_connection->apache_sock, 
                        EPOLLIN | EPOLLOUT | EPOLLERR | EPOLLHUP) < 0)
            {
                goto fail;
            }
            goto wait;
        }
    }
    else if(cur_connection->inbuff_len != 0)
    {
        s = cur_connection->apache_sock.fd;
        if(type == EVT_FD)
        {
            if(getsockopt(s, SOL_SOCKET, SO_ERROR, (void *)&error, &len)<0)
            {
                ul_writelog(UL_LOG_FATAL, 
                        "testing_apache[%s]: getsockopt() error, %s", 
                        apache_ip, strerror(errno));
                goto fail;
            }
            if(error != 0)
            {
                ul_writelog(UL_LOG_WARNING, 
                        "[Apache]testing_apache[%s]: getsockopt(), status is error, %d", 
                        apache_ip, error);
                goto fail;
            }

            if(block_write(cur_connection->apache_sock.fd, 
                        cur_connection->in_buff,
                        cur_connection->inbuff_len) != cur_connection->inbuff_len)
            {
                ul_writelog(UL_LOG_WARNING, 
                        "[Apache]testing_apache[%s]: write apache error", apache_ip);
                goto fail;
            }
            if(mod_handle(cur_connection, &cur_connection->apache_sock, 
                        EPOLLIN | EPOLLERR | EPOLLHUP) < 0)
            {
                ul_writelog(UL_LOG_FATAL, 
                        "[Apache]testing_apache[%s]: to read mod handle error", apache_ip);
            }
            cur_connection->inbuff_len = 0;
        }
        else if(type == EVT_TIMER)
        {
            ul_writelog(UL_LOG_WARNING, 
                    "[Apache]testing_apache[%s]: connection time out", apache_ip);
            goto fail;
        }
    }
    else
    {
        if(type == EVT_FD)
        {
            if(block_read(cur_connection->apache_sock.fd, obuff, 20) != 20)
            {
                ul_writelog(UL_LOG_WARNING, 
                        "[Apache]testing_apache[%s]: read apache error", apache_ip);
                goto fail;
            }
            obuff[20] = '\0';
            if(strstr(obuff, "200") == NULL)
            {
                ul_writelog(UL_LOG_WARNING, 
                        "[Apache]testing_apache[%s]: apache return error", apache_ip);
                goto fail;
            }
            (cur_connection->apache)->available = true;
            ul_writelog(UL_LOG_WARNING, 
                    "[Apache]testing_apache[%s]: recovered", apache_ip);
            goto fail;
        }
    }
    if(type == EVT_TIMER)
    {
        ul_writelog(UL_LOG_WARNING,
                "[Apache]testing_apache[%s]: read time out", apache_ip);
        goto fail;
    }
    
wait:
    return ST_WAIT;
fail:
    if(!g_terminate_flag && cur_connection->apache->available == false)
    {
        make_testing_apache_connection(cur_connection->apache);
    }
    free_connection(cur_connection);
    return ST_FAIL;
}

int make_testing_apache_connection(Apache *apache)
{
    Connection *cur_connection;

    cur_connection = alloc_connection(&g_connection_proc);
    if(cur_connection == NULL)
    {
        g_statistics->inbuff_overflow_num++;
        ul_writelog(UL_LOG_FATAL, "make_testing_apache_connection: alloc_connection(), "
                "no connection unit available;");
        return ST_FAIL;
    }

    cur_connection->cur_op = OP_TESTING_APACHE;
    cur_connection->cur_proc = testing_apache;

    cur_connection->client_sock.fd      = -1;
    cur_connection->client_sock.status  = -1;
    cur_connection->apache_sock.fd      = -1;
    cur_connection->apache_sock.status  = -1;

    memset(&cur_connection->client_addr, 0, sizeof(cur_connection->client_addr)) ;
    cur_connection->apache = apache;
    cur_connection->out_buff = NULL;
    
    mod_timer(cur_connection, 0, 2000);
    cur_connection->enter_tv = g_now;

    cur_connection->inbuff_pos = 0;
    strcpy(cur_connection->in_buff, "GET / HTTP/1.0\r\n\r\n");
    cur_connection->inbuff_len = strlen(cur_connection->in_buff);

    return ST_WAIT;
}

int init_shm(Config *config)
{
    int dict_size;
    struct shmid_ds  info_shm;
    int is_exist = 0;

    dict_size = (config->max_blacklist_num+config->max_innocent_num)*sizeof(IpItem)*2;

    g_shm_id = shmget(g_shm_key,  sizeof(ShmConfig)+dict_size, 0666|IPC_CREAT|IPC_EXCL);
    if(g_shm_id == -1) 
    {
        if (errno == EEXIST)
        {
            ul_writelog(UL_LOG_WARNING, "%s %d init_shm: shmget(), %s", 
                    __FILE__, __LINE__, strerror(errno));
            g_shm_id = shmget(g_shm_key, 0, 0666);
	     is_exist = 1;
        }
    }

    if(g_shm_id == -1) 
    {
        ul_writelog(UL_LOG_FATAL, "%s %d init_shm: shmget() error, %s", 
                __FILE__, __LINE__, strerror(errno));
        return -1;
    } 
    else 
    {
    	if (is_exist){
		/*get shm_segsz */
		if ( -1 == shmctl(g_shm_id,IPC_STAT,&info_shm)){
	            ul_writelog(UL_LOG_WARNING, "%s %d init_shm: shmctl(), %s", 
	                    __FILE__, __LINE__, strerror(errno));
			return -1;
		}
		/*�����С���ȣ�Ӧ����û������ɵĹ����ڴ�ṹ����*/
		if (info_shm.shm_segsz!=sizeof(ShmConfig)+dict_size){
	            ul_writelog(UL_LOG_WARNING, "%s %d init_shm: segment size is diffrent,old=%d,new=%d,[should ipcrm shmkey]", 
	                    __FILE__, __LINE__,info_shm.shm_segsz, sizeof(ShmConfig)+dict_size);
			return -1;		
		}
    	}
	/*only size is same*/
        g_shm_addr = (char *)shmat(g_shm_id, NULL, 0);
        if(g_shm_addr == (char *)-1)
        {
            ul_writelog(UL_LOG_FATAL, "%s %d init_shm: shmat() error, %s", 
                    __FILE__, __LINE__, strerror(errno));
            return -1;
        }
    } 
    g_shm_config = (ShmConfig *)g_shm_addr;
    g_statistics = &(g_shm_config->statistics);
    g_shm_config->cur_config = 0;
    g_cur_config = &(g_shm_config->config[0]);

    g_cur_innocent_dict = (IpItem *)(g_shm_addr + sizeof(ShmConfig));
    g_cur_blacklist_dict = (IpItem *)(g_shm_addr + sizeof(ShmConfig) +
            g_cur_config->max_innocent_num * sizeof(IpItem) * 2);


    memcpy(&(g_shm_config->config[0]), config, sizeof(Config));
    memcpy(&(g_shm_config->config[1]), config, sizeof(Config));

    return 0;
}


void deinit_shm(void)
{
    if(g_shm_id < 0)
        return;
    if(g_shm_addr)
        shmdt(g_shm_addr);

    shmctl(g_shm_id, IPC_RMID, NULL);
}

void get_listen(char *param, char *listen_addr, int *listen_port)
{
    int clen;
    char *p;

    *listen_port = DEFAULT_LISTEN_PORT;
    strcpy(listen_addr, DEFAULT_LISTEN_ADDR);

    p = strchr(param, ':');
    if(p == NULL)
        *listen_port = atoi(param);
    else
    {
        *listen_port = atoi(p+1);
        clen = p-param>MAX_PATH_LEN-1 ? MAX_PATH_LEN-1 : p-param;
        strncpy(listen_addr, param, clen);
        listen_addr[clen] = '\0';
    }
}

int init_log(char *log_path, char *log_file, int log_size, int log_level)
{
    ul_logstat_t log_stat;

    log_stat.events = log_level;
    log_stat.spec = 0;
    log_stat.to_syslog = 0;
    if(ul_openlog(log_path, log_file, &log_stat, log_size) < 0)
    {
        ul_writelog(UL_LOG_FATAL, "%s  %d  init_log: ul_openlog() error", 
                __FILE__, __LINE__);
        return -1;
    }

    return 0;
}

int init_apache(void)
{
    char *path_end;
    char line[MAX_PATH_LEN];
    char file_path[MAX_PATH_LEN];
    char file_name[MAX_PATH_LEN];
    FILE *fp;
    Sdict_build *dict;
    Sdict_snode node;
    Apache *cur_apache;

    cur_apache = g_cur_config->branch_apache;

    while(cur_apache)
    {
        path_end = strrchr(cur_apache->cookie_file, '/');
        if(path_end == NULL)
        {
            strcpy(file_path, "./");
            strcpy(file_name, cur_apache->cookie_file);
        }
        else
        {
            strncpy(file_path, cur_apache->cookie_file, path_end-cur_apache->cookie_file);
            file_path[path_end-cur_apache->cookie_file] = '\0';
            strcpy(file_name, path_end);
        }

        if((dict = db_creat(100000, 0)) == NULL) 
        {
            ul_writelog(UL_LOG_FATAL, "init_apache: db_creat error!");
            return -1;
        }

        if((fp = fopen(cur_apache->cookie_file, "r")) == NULL) 
        {
            ul_writelog(UL_LOG_FATAL, "init_apache: file open error, %s", cur_apache->cookie_file);
            db_del(dict);
            return -1;
        }

        while(1)
        {
            if(fgets(line, MAX_PATH_LEN, fp) == NULL) 
                break;

            line[MAX_PATH_LEN-1] = 0;
            my_trim(line);
            if(line[0] == '\0')
                continue;

            creat_sign_f64(line, strlen(line), &node.sign1, &node.sign2);
            node.code = -1;
            db_op1(dict, &node, ADD);
        }

        fclose(fp);

        if(db_adjust(dict) < 0) 
        {
            ul_writelog(UL_LOG_FATAL, "init_apache: dict adjust error!");
            db_del(dict);
            return -1;
        }

        if (db_save(dict, file_path, file_name) < 0) 
        {
            ul_writelog(UL_LOG_FATAL, "init_apache: dict save error, %s %s", file_path, file_name);
            db_del(dict);
            return -1;
        }

        db_del(dict);


        cur_apache->cookie_dict = ds_load(file_path, file_name);
        if(cur_apache->cookie_dict == NULL)
        {

            ul_writelog(UL_LOG_FATAL, "%s %d init_apache: ds_load(%s/%s) error", 
                    __FILE__, __LINE__, file_path, file_name);
            return -1;
        }

        cur_apache = cur_apache->next;
    }

    return 0;
}

void deinit_apache(void)
{
    Apache *cur_apache;

    cur_apache = g_cur_config->branch_apache;

    while(cur_apache)
    {
        if(cur_apache->cookie_dict)
        {
            ds_del(cur_apache->cookie_dict);
            cur_apache->cookie_dict = NULL;
        }
        cur_apache = cur_apache->next;
    }

}

void free_apache(void)
{
    Apache *old_apache;
    Apache *cur_apache;

    if(g_cur_config->dispatch_apache 
            && g_cur_config->dispatch_apache != g_cur_config->bws)
    {
        free(g_cur_config->dispatch_apache);
        g_cur_config->dispatch_apache = NULL;
    }

    if(g_cur_config->bws
            && g_cur_config->bws != g_cur_config->main_apache)
    {
        free(g_cur_config->bws);
        g_cur_config->bws = NULL;
    }

    if(g_cur_config->main_apache != NULL)
    {
        free(g_cur_config->main_apache);
        g_cur_config->main_apache = NULL;
    }

    cur_apache = g_cur_config->pp_apache;
    if(cur_apache != NULL)
    {
        do
        {
            old_apache = cur_apache;
            cur_apache = cur_apache->next;
            free(old_apache);
        }while(cur_apache != g_cur_config->pp_apache);
    }
    g_cur_config->pp_apache = NULL;

    cur_apache = g_cur_config->branch_apache;
    while(cur_apache)
    {
        old_apache = cur_apache;
        cur_apache = cur_apache->next;
        free(old_apache);
    }
    g_cur_config->branch_apache = NULL;
}

int load_apache(Apache **apache_ptr, char *param, int type)
{
	
    int  clen;
    char *p;
    char tmp_buff[MAX_PATH_LEN+20];
    Apache apache;
    struct hostent *hep;

	*apache_ptr = NULL;

    memset(&apache, 0, sizeof(apache));

    sscanf(param, "%s %s", tmp_buff, apache.cookie_file);

    p = strchr(tmp_buff, ':');
    if(p == NULL)
    {
        ul_writelog(UL_LOG_FATAL, "%s %d load_apache: no port, %s", 
                __FILE__, __LINE__, param);
        return -1;
    }

    apache.type = type;
    apache.time_to_recover = 0;
    apache.backup = NULL;

    apache.available = true;
    apache.port = htons(atoi(p+1));
    clen = p-tmp_buff>MAX_PATH_LEN-1 ? MAX_PATH_LEN-1 : p-tmp_buff;
    strncpy(apache.host_name, tmp_buff, clen);
    apache.host_name[clen] = '\0';

    hep = gethostbyname(apache.host_name);
    if(hep == NULL)
    {
        ul_writelog(UL_LOG_FATAL, "%s %d load_apache: gethostbyname(%s) error, %s", 
                __FILE__, __LINE__, apache.host_name, strerror(errno));
        return -1;
    }
    (apache.addr).s_addr = ((struct in_addr *) (hep->h_addr))->s_addr;

    if(NULL == (*apache_ptr = (Apache *)malloc(sizeof(Apache)))){
		ul_writelog(UL_LOG_FATAL, "%s %d load_apache: no enough memory for Apache",
				__FILE__, __LINE__);
		return -1;
	}
	
    memcpy(*apache_ptr, &apache, sizeof(Apache));

    return 0;
}

int load_directory(char *buf, str_array_t *array)
{
    char *word;
    int i = 0;

    while((word = strsep(&buf, " \t")) != NULL)
    {
        if(word[0] == '\0') continue;

        strncpy(array->data[i], word, MAX_STR_LEN - 1);
        array->data[i][MAX_STR_LEN - 1] = '\0';

        array->len[i] = strlen(array->data[i]);

        if(++i >= MAX_STR_NUM)
        {
            return -1;
        }
    }
    array->nelts = i;
    return 0;
}

int load_apache_config(Config *config)
{
	if(NULL == config){
		return -1;
	}

	int  i = 0;
	char apachen[100];
	char tmp_buff[2*MAX_PATH_LEN];
	Apache *cur_apache = NULL, *tail = NULL;

	/*
	 * -------+IP DISPATCH \
	 * Seache |COOKIE       \
	 * request|--------------BWS->
	 * -------|                   \
	 * Static |                    \
	 * request+---------------------Local Apache
	 * -------|
	 * PP     |
	 * request+-->PP apache
	 * -------
	 * */

	/* load Local Apache */
	if(CONFIG_FOUND == get_conf_str("LOCAL_APACHE", tmp_buff, sizeof(tmp_buff), NULL))
	{
		if(load_apache(&(config->main_apache), tmp_buff, AP_TYPE_SINGLE) < 0)
		{
			ul_writelog(UL_LOG_FATAL, "DEFAULT:  load LOCAL_APACHE error");
			return -1;
		}
	}else{
		ul_writelog(UL_LOG_FATAL, "LOCAL_APACHE not found.");
		return -1;
	}
	
	config->main_apache->backup = NULL;
	ul_writelog(UL_LOG_DEBUG, "transmit.conf: LOCAL_APACHE %s:%d",
			config->main_apache->host_name, ntohs(config->main_apache->port));

	/* load BWS */
	if(CONFIG_FOUND == get_conf_str("BWS", tmp_buff, sizeof(tmp_buff), NULL))
	{
		if(load_apache(&(config->bws), tmp_buff, AP_TYPE_DOUBLE) < 0)
		{
			ul_writelog(UL_LOG_FATAL, "load BWS error");
			return -1;
		}
		/* when BWS fails, use LOCAL Apache */
		config->bws->backup = config->main_apache;
		ul_writelog(UL_LOG_DEBUG, "transmit.conf: BWS %s:%d",
				config->bws->host_name, ntohs(config->bws->port));
	}
	else
	{
		config->bws = config->main_apache;
		ul_writelog(UL_LOG_DEBUG, "DEFAULT:  use LOCAL_APACHE as BWS");
	}

	/* load IP Dispatch Apache */
	if(CONFIG_FOUND == get_conf_str("DISPATCH_APACHE", tmp_buff, sizeof(tmp_buff), NULL))
	{
		if(load_apache(&(config->dispatch_apache), tmp_buff, AP_TYPE_DOUBLE) < 0)
		{
			ul_writelog(UL_LOG_FATAL, "load IP DISPATCH apache error");
			return -1;
		}
		/* if DISPATCH apache fails, use BWS instead */
		config->dispatch_apache->backup = config->bws;
		ul_writelog(UL_LOG_DEBUG, "transmit.conf: DISPATCH_APACHE %s:%d",
				config->dispatch_apache->host_name, ntohs(config->dispatch_apache->port));
	}
	else
	{
		ul_writelog(UL_LOG_DEBUG, "DEFAULT:  use BWS as DISPATCH_APACHE");
		config->dispatch_apache = config->bws;
	}

	/* load PP apache */
	config->pp_apache = NULL;
	for(i = 0; ; ++i)
	{
		snprintf(apachen, sizeof(apachen), "PP_APACHE%d", i);
		if(CONFIG_FOUND != get_conf_str(apachen, tmp_buff, sizeof(tmp_buff), NULL))
		{
			break;
		}
		if(load_apache(&cur_apache, tmp_buff, AP_TYPE_RR) < 0)
		{
			ul_writelog(UL_LOG_FATAL,
					"load_config:  load_pp_apache[%d] error", i);
			return -1;
		}
		if(config->pp_apache == NULL)
		{
			tail = cur_apache;
			config->pp_apache = cur_apache;
		}
		tail->next = cur_apache;
		cur_apache->next = config->pp_apache;
		config->pp_apache = cur_apache;
	}
	if(config->pp_apache == NULL)
	{
		ul_writelog(UL_LOG_DEBUG, "DEFAULT:  No PP_APACHE");
	}


	/* load Cookie dispatch apache */
	for(i=0; ; i++)
	{
		sprintf(apachen, "COOKIE_APACHE%d", i);
		if(CONFIG_FOUND != get_conf_str(apachen, tmp_buff, sizeof(tmp_buff), NULL))
		{
			break;
		}
		if(load_apache(&cur_apache, tmp_buff, AP_TYPE_DOUBLE) < 0)
		{
			ul_writelog(UL_LOG_FATAL, "load_config:  load_apache error");
			return -1;
		}
		cur_apache->backup = config->bws;

		ul_writelog(UL_LOG_DEBUG, "transmit.conf:  %s.port = %d", apachen, ntohs(cur_apache->port));
		ul_writelog(UL_LOG_DEBUG, "transmit.conf:  %s.host_name = %s", apachen, cur_apache->host_name);
		ul_writelog(UL_LOG_DEBUG, "transmit.conf:  %s.cookie_file = %s", apachen, cur_apache->cookie_file);
		if(cur_apache->cookie_file[0] == '\0')
		{
			ul_writelog(UL_LOG_FATAL, "load_config: no cookie file found in COOKIE_APACHE%d", i);
			return -1;
		}
		else
		{
			cur_apache->next = config->branch_apache;
			config->branch_apache = cur_apache;
		}
	}

	return 0;
}


int load_config_item(Config *config, bool all)
{
	char tmp_buff[2*MAX_PATH_LEN];			

	if(0 > load_prison_conf(&(config->prison_filters), all))
	{
		ul_writelog(UL_LOG_FATAL, "%s %d : load_prison_conf() error",
				__FILE__, __LINE__);

		return -1;
	}

	get_conf_int("READ_CLIENT_TIMEOUT", &(config->read_client_timeout), DEFAULT_READ_CLIENT_TIMEOUT);
	get_conf_int("CONNECT_APACHE_TIMEOUT", &(config->connect_apache_timeout), DEFAULT_CONNECT_APACHE_TIMEOUT);

	/* specify the timeout value for pp apache */
	get_conf_int("CONNECT_PP_APACHE_TIMEOUT", &(config->connect_pp_apache_timeout),DEFAULT_CONNECT_PP_APACHE_TIMEOUT);
	get_conf_int("WRITE_APACHE_TIMEOUT", &(config->write_apache_timeout), DEFAULT_WRITE_APACHE_TIMEOUT);
	get_conf_int("READ_APACHE_WRITE_CLIENT_TIMEOUT", &(config->read_apache_write_client_timeout),
			DEFAULT_READ_APACHE_WRITE_CLIENT_TIMEOUT);

	get_conf_int("INTERVAL_WRITE_CLIENT_TIMEOUT", &(config->interval_write_client_timeout),
			DEFAULT_INTERVAL_WRITE_CLIENT_TIMEOUT);
	get_conf_int("MAX_CON_PER_IP", &(config->max_con_per_ip), DEFAULT_MAX_CON_PER_IP);
	get_conf_int("MIN_READ_TIME_TO_RECORD", &(config->min_read_time_to_record), DEFAULT_MIN_READ_TIME_TO_RECORD);

	get_conf_int("MIN_RESPONSE_TIME_TO_RECORD", &(config->min_response_time_to_record),
			DEFAULT_MIN_RESPONSE_TIME_TO_RECORD);

	get_conf_str("INNOCENT_FILE", config->innocent_file, sizeof(config->innocent_file), NULL);
	get_conf_str("BLACKLIST_FILE", config->blacklist_file, sizeof(config->blacklist_file), NULL);

	if(CONFIG_FOUND == get_conf_str("DISPATCH_SCALE", tmp_buff, sizeof(tmp_buff), NULL))
	{
		config->dispatch_scale = (int)(DISPATCH_NUM * atof(tmp_buff) / 100);

		if(config->dispatch_scale < 0 || config->dispatch_scale > DISPATCH_NUM)
		{
			config->dispatch_scale = DEFAULT_DISPATCH_SCALE;
		}

		ul_writelog(UL_LOG_DEBUG, "transmit.conf:  DISPATCH_SCALE = %s, scalenum = %d", 
				tmp_buff, config->dispatch_scale);
	}
	else
	{
		config->dispatch_scale = DEFAULT_DISPATCH_SCALE;
		ul_writelog(UL_LOG_DEBUG, "DEFAULT:  DISPATCH_SCALE = 0, scalenum = %d", 
				config->dispatch_scale);
	}

	/* load timer check interval value */
	get_conf_int("FAST_TIMER", &(config->fast_timer), DEFAULT_FAST_TIMER);
	get_conf_int("SLOW_TIMER", &(config->slow_timer), DEFAULT_SLOW_TIMER);
	get_conf_int("MAX_KEEP_ALIVE_TIME", &(config->max_keep_alive_time), DEFAULT_MAX_KEEP_ALIVE_TIME);
	get_conf_int("MIN_FREE_CONNECTION", &(config->min_free_connection), DEFAULT_MIN_FREE_CONNECTION);
	get_conf_int("NORMAL_READ_TIME", &(config->normal_read_time), DEFAULT_NORMAL_READ_TIME);
	get_conf_int("NORMAL_WRITE_TIME", &(config->normal_write_time), DEFAULT_NORMAL_WRITE_TIME);
	get_conf_int("RECOVER_TIME", &(config->recover_time), DEFAULT_RECOVER_TIME);
	
	/* load Raw log rate */
	get_conf_int("RAW_LOG_RATE", &(config->raw_log_rate), DEFAULT_RAW_LOG_RATE);

	/* load Raw log file name */
	if((CONFIG_FOUND != get_conf_str("RAW_LOG_FILE", config->raw_log_file, sizeof(config->raw_log_file), NULL))
			|| ('\0' == config->raw_log_file[0])){
		ul_writelog(UL_LOG_DEBUG, "DEFAULT:  Do not write RAW_LOG_FILE");
	}

	/* load BWS Directory */
	get_conf_str("BWS_DIR", tmp_buff, sizeof(tmp_buff), DEFAULT_BWS_DIR);
	if(load_directory(tmp_buff, &(config->search_dir)))
	{
		ul_writelog(UL_LOG_FATAL, "transmit.conf: error BWS_DIR");
		return -1;
	}

	/* load main page */
	get_conf_str("BWS_PAGE", tmp_buff, sizeof(tmp_buff), DEFAULT_BWS_PAGE);
	if(load_directory(tmp_buff, &(config->search_page)))
	{
		ul_writelog(UL_LOG_FATAL, "transmit.conf: error BWS_PAGE");
		return -1;
	}

	/* load PP Directory */
	get_conf_str("PP_APACHE_DIR", tmp_buff, sizeof(tmp_buff), DEFAULT_PP_APACHE_DIR);
	if(load_directory(tmp_buff, &(config->pp_dir)))
	{
		ul_writelog(UL_LOG_FATAL, "transmit.conf: error PP_APACHE_DIR"); 
		return -1;
	}
	// begin Add by liuliping 2007-11-11
	/* request filter acl */
	get_conf_int("ALLOW_HOST_ON", &(config->host_allow_on), DEFAULT_HOST_FILTER);
	get_conf_int("DENY_REFER_ON", &(config->refer_deny_on), DEFAULT_REFER_FILTER);
	get_conf_int("DENY_USRAGENT_ON", &(config->agnet_deny_on), DEFAULT_AGENT_FILTER);
	
	get_conf_str("HostAllow_ACL", config->hostallow_acl,sizeof(config->hostallow_acl), DEFAULT_HOSTACL_FILE);
	get_conf_str("ReferDeny_ACL", config->referdeny_acl, sizeof(config->referdeny_acl),DEFAULT_REFERACL_FILE);
	get_conf_str("AgentDeny_ACL", config->agentdeny_acl, sizeof(config->agentdeny_acl),DEFAULT_AGENTACL_FILE);
	// end  Add by liuliping 2007-11-11

	char frame_s[256], dtd_s[256], ns_path[256];
	get_conf_str("FRAME_DIR", ns_path, sizeof(ns_path), NULL);
	get_conf_str("FRAME_CONF", frame_s, sizeof(frame_s), NULL);
	get_conf_str("FRAME_CONF_DTD", dtd_s, sizeof(dtd_s), NULL);
	if (load_policyframe_conf(ns_path, dtd_s, frame_s))
	{
	    WARNING("LOAD FRAME CONFIG ERROR");
	    return -1;
	}
	
	if(all)
	{
		if(CONFIG_FOUND == get_conf_str("LISTEN", tmp_buff, sizeof(tmp_buff), NULL))
		{
			get_listen(tmp_buff, config->listen_addr, &(config->listen_port));
			ul_writelog(UL_LOG_DEBUG, "transmit.conf:  LISTEN = %s:%d", 
					config->listen_addr, config->listen_port);
		}
		else
		{
			config->listen_port = DEFAULT_LISTEN_PORT;
			strcpy(config->listen_addr, DEFAULT_LISTEN_ADDR);
			ul_writelog(UL_LOG_DEBUG, "DEFAULT:  LISTEN = %s:%d", config->listen_addr, config->listen_port);
		}

		if((CONFIG_ERROR == get_conf_str("DES_KEY", tmp_buff, sizeof(tmp_buff), DEFAULT_DES_KEY))
				|| (0 > init_decode(tmp_buff))){
			ul_writelog(UL_LOG_FATAL, "transmit.conf: init DES encode error");
			return -1;
		}

		get_conf_int("MAX_CONNECTION_NUM", &(config->max_connection_num), DEFAULT_MAX_CONNECTION_NUM);
		get_conf_int("MAX_OUTBUFF_NUM", &(config->max_outbuff_num), DEFAULT_MAX_OUTBUFF_NUM);
		get_conf_int("MAX_INNOCENT_NUM", &(config->max_innocent_num), DEFAULT_MAX_INNOCENT_NUM);
		get_conf_int("MAX_BLACKLIST_NUM", &(config->max_blacklist_num), DEFAULT_MAX_BLACKLIST_NUM);
		get_conf_int("LISTEN_NUM", &(config->listen_num), DEFAULT_LISTEN_NUM);
		get_conf_int("SEND_BUFF_SIZE", &(config->send_buff_size), DEFAULT_SEND_BUFF_SIZE);
		get_conf_int("RECV_BUFF_SIZE", &(config->recv_buff_size), DEFAULT_RECV_BUFF_SIZE);
		get_conf_str("PID_FILE", config->pid_file, sizeof(config->pid_file), DEFAULT_PID_FILE);
		
		get_conf_int("INBUFF_LEN", &(config->inbuff_len), DEFAULT_INBUFF_LEN);
		get_conf_int("OUTBUFF_LEN", &(config->outbuff_len), DEFAULT_OUTBUFF_LEN);
		
		get_conf_int("LOG_LEVEL", &(config->log_level), DEFAULT_LOG_LEVEL);
		get_conf_int("LOG_SIZE", &(config->log_size), DEFAULT_LOG_SIZE);
		get_conf_str("LOG_PATH", config->log_path, sizeof(config->log_path), DEFAULT_LOG_PATH); 
		get_conf_str("LOG_FILE", config->log_file, sizeof(config->log_file), DEFAULT_LOG_FILE);
		if(0 > load_apache_config(config)){
			ul_writelog(UL_LOG_WARNING, "Failed to read all apache configuration");
			return -1;
		}
	}

	return 0;
}
/*********************************************************************************
 *Name     :  read_filter_acl
 *Comment  : read GET request filter file --*.acl
 				
 *Input    :		
 			
 *Output   : 
 *
 *NOTE: create by liulp 2007-11-20
 *********************************************************************************/

int read_filter_acl (Config *config ,int type)
{
   // int  ret_code;
    char line[MAX_CMD_LEN];
    FILE *fp;
    char *start = NULL;
    char * filename = NULL;
    int maxnum = 0;
    int *p_curnum = NULL;
    regexp_row_t * p_filterlist = NULL;
    if (config == NULL ){
	return -1;
    }

    if ( type == FILTER_HOST ){
	memset(config->host_filter,0,sizeof(config->host_filter) );
	config->cur_host_allow_num = 0;
	filename = config->hostallow_acl;
	p_curnum = &config->cur_host_allow_num;
	maxnum = MAX_HOSTACL_NUM;
	p_filterlist = config->host_filter;
    }
    else if ( type == FILTER_REFER ){
	memset(config->refer_filter,0,sizeof(config->refer_filter) );
	config->cur_refer_deny_num = 0;
	filename = config->referdeny_acl;
	p_curnum = &config->cur_refer_deny_num;
	maxnum = MAX_REFERACL_NUM;
	p_filterlist = config->refer_filter;
    }
    else if ( type == FILTER_AGENT ){
	memset(config->agent_filter,0,sizeof(config->agent_filter));
	config->cur_agent_deny_num = 0;
	filename = config->agentdeny_acl;
	p_curnum = &config->cur_agent_deny_num;
	maxnum =MAX_AGENTACL_NUM;
	p_filterlist = config->agent_filter;
    }	
   else {
   	return -1; 
   }
    my_trim(filename);
    if(filename[0] == '\0')
        return -1;
	
    if((fp=fopen(filename, "rb")) == NULL) {
        ul_writelog(UL_LOG_FATAL, "%s %d read_filter_acl: fopen(%s) error, %s", 
                __FILE__, __LINE__, filename, strerror(errno));
        return -1;
    }
    *p_curnum = 0;
    while(1)
    {
	memset(line,0, sizeof(line));
        if(fgets(line, sizeof(line) - 1, fp) == NULL)
            break;

        start = line;
        while(1)
        {
            if(*start!=' ' && *start!='\t')
                break;
            start++;
        }

        if(start[0]=='#' || start[0]=='\r' || start[0]=='\n') 
            continue;
	my_trim(line);
	if (strlen(line) == 0 ){
		continue;
	}
	strncpy(p_filterlist[*p_curnum].regexp_row , line ,strlen(line));

       ul_writelog(UL_LOG_NOTICE, "%s" ,p_filterlist[*p_curnum].regexp_row);//print

	(*p_curnum)++;
        if((*p_curnum) >= maxnum)
        {
            ul_writelog(UL_LOG_WARNING, "read_filter_acl: entry size exceeded.type = %d ,max=%d" ,type,maxnum);
            break;
        }

    }

    fclose(fp);

	return 0;
}
/*********************************************************************************
 *Name     :  load_filter
 *Comment  : read GET request filter file --*.acl
 				
 *Input    :		
 			
 *Output   : 
 *
 *NOTE: create by liulp 2007-11-20
 *********************************************************************************/

int load_filter(Config *config)
{

	int ret = 0;
	if(NULL == config){
		return -1;
	}	
	if (config->host_allow_on == 1){
		ret =read_filter_acl(config , FILTER_HOST );
		if (ret < 0) {
			ul_writelog(UL_LOG_WARNING,"read_filter_acl  [hostallow_acl] fail ");
			return -1;			
		}
	}
       else {
		memset(config->host_filter,0,sizeof(config->host_filter) );
		config->cur_host_allow_num = 0;
       	}
	if (config->refer_deny_on == 1){
		ret =read_filter_acl(config ,FILTER_REFER );
		if (ret < 0) {
			ul_writelog(UL_LOG_WARNING,"read_filter_acl  [referdeny_acl] fail ");
			return -1;				
		}
	}	
       else {
		memset(config->refer_filter,0,sizeof(config->refer_filter) );
		config->cur_refer_deny_num = 0;
	}
	
	if (config->agnet_deny_on == 1){
		ret =read_filter_acl(config ,FILTER_AGENT );
		if (ret < 0) {
			ul_writelog(UL_LOG_WARNING,"read_filter_acl  [agentdeny_acl] fail ");
			return -1;				
		}		
	}	
       else {
		memset(config->agent_filter,0,sizeof(config->agent_filter) );
		config->cur_agent_deny_num = 0;
       	}

	return 0;
}
bool
match_filter(char * buffer ,int type)
{
	if (type == FILTER_HOST){
		for ( int i = 0 ; i < g_cur_config->cur_host_allow_num ;++i){
			if (match(g_cur_config->host_filter[i].regexp_row,buffer)){
				return true;
			}
		}
	}
	else if (type == FILTER_REFER){
		for ( int i = 0 ; i < g_cur_config->cur_refer_deny_num ;++i){
			if (match(g_cur_config->refer_filter[i].regexp_row,buffer)){
				return true;
			}
		}
	}
	else if (type == FILTER_AGENT){
		for ( int i = 0 ; i < g_cur_config->cur_agent_deny_num ;++i){
			if (match(g_cur_config->agent_filter[i].regexp_row,buffer)){
				return true;
			}
		}
	}	
	return false;
}

/*end add by liuliping  2007-11-07*/
int load_config(Config *config, bool all)
{
	if(NULL == config){
		return -1;
	}
	
	char tmp_buff[2*MAX_PATH_LEN];

	if(g_config_path[0] == '\0')
		strcpy(g_config_path, DEFAULT_CONFIG_PATH);
	if(g_config_file[0] == '\0')
		strcpy(g_config_file, DEFAULT_CONFIG_FILE);

	if(0 > add_config_data(g_config_path, g_config_file))
	{
		ul_writelog(UL_LOG_WARNING, "%s %d load_config: add_config_data() error",
				__FILE__, __LINE__);
		return -1;
	}

	if(CONFIG_FOUND == get_conf_str("OTHER_CONF_FILE", tmp_buff, sizeof(tmp_buff), NULL))
	{
		if(0 > add_config_data(g_config_path, tmp_buff)){
			ul_writelog(UL_LOG_FATAL, "%s %d load_apache_config: add_config_data() error",
					__FILE__, __LINE__);
			free_config_data();
			return -1;
		}
	}else{
		ul_writelog(UL_LOG_DEBUG, "transmit.conf: OTHER_CONF_FILE: no other configure");
	}

	int ret_code = load_config_item(config, all);
	free_config_data();
	
	return ret_code;
}

int init_reload(void)
{
	char log_file[MAX_PATH_LEN];

	ul_closelog(0);
	snprintf(log_file, MAX_PATH_LEN, "%sreload", g_cur_config->log_file);
	if(init_log(g_cur_config->log_path, log_file, g_cur_config->log_size, g_cur_config->log_level) < 0)
	{
		ul_writelog(UL_LOG_FATAL, "%s  %d  init_reload: unit_log() error", 
				__FILE__, __LINE__);
		return -1;
	}

	return 0;
}

void deinit_reload(void)
{
	ul_closelog(0);
	//free_apache();
}

int load_all_dict(Config *config, int dict_pos)
{
	int ret_code;
	IpItem *innocent_dict;
	IpItem *blacklist_dict;

	innocent_dict = (IpItem *)(g_shm_addr + sizeof(ShmConfig) +
			dict_pos * config->max_innocent_num * sizeof(IpItem));
	blacklist_dict = (IpItem *)(g_shm_addr + sizeof(ShmConfig) +
			2 * config->max_innocent_num * sizeof(IpItem) +
			dict_pos * config->max_blacklist_num * sizeof(IpItem));

	ret_code = load_dict(innocent_dict, config->max_innocent_num, config->innocent_file);
	if(ret_code < 0)
	{
		ul_writelog(UL_LOG_FATAL, "%s %d load_all_dict: load_dict(%s) error", 
				__FILE__, __LINE__, config->innocent_file);
		return -1;
	}
	config->cur_innocent_num = ret_code;

	ret_code = load_dict(blacklist_dict, config->max_blacklist_num, config->blacklist_file);
	if(ret_code < 0)
	{
		ul_writelog(UL_LOG_FATAL, "%s %d load_all_dict: load_dict(%s) error", 
				__FILE__, __LINE__, config->blacklist_file);
		return -1;
	}
	config->cur_blacklist_num = ret_code;


	
	return 0;
}

void reload()
{
	int cur_config;

	if(init_reload() < 0)
	{
		ul_writelog(UL_LOG_FATAL, "%s  %d  reload: init_reload() error, reload exit", 
				__FILE__, __LINE__);
		return;
	}

	while(1)
	{
		if(g_terminate_flag){
			ul_writelog(UL_LOG_DEBUG, "reload terminate");
			break;
		}

		if(g_reload_flag)
		{
			if(g_shm_config->cur_config == 0)
				cur_config = 1;
			else
				cur_config = 0;

			if((load_config(&(g_shm_config->config[cur_config]), false)==0 )&&
					(load_all_dict(&(g_shm_config->config[cur_config]), cur_config)==0)&&
					(load_filter(&(g_shm_config->config[cur_config])) == 0))
			{
				ul_writelog(UL_LOG_NOTICE, "reload: load_config rigit");
				g_shm_config->cur_config = cur_config;
			}
			else
				ul_writelog(UL_LOG_FATAL, "reload: load_config error");
		
			g_reload_flag = false;
			//signal(SIGHUP, sig_reload);
		}

		sleep(2);
	}

	ul_writelog(UL_LOG_NOTICE, "transmit_reload terminate normally");
	deinit_reload();
}

int detach(void)
{
	int x;

	if ((x = fork()) > 0)
		exit(0);
	else 
		if(x == -1) 
		{
			ul_writelog(UL_LOG_FATAL, "%s  %d  detach: fork() error, %s", 
					__FILE__, __LINE__, strerror(errno));
			return -1;
		}

	if(setsid() == -1) 
	{
		ul_writelog(UL_LOG_FATAL, "%s  %d  detach: setsid() error, %s", 
				__FILE__, __LINE__, strerror(errno));
		return -1;
	}

	return 0;
}

void deinit_log(void)
{
	ul_closelog(0);
}

int write_pid_file(void)
{
	int  pid;
	FILE *fp;

	fp = fopen(g_cur_config->pid_file, "w+b");
	if(fp == NULL)
	{
		ul_writelog(UL_LOG_FATAL, "%s %d write_pid_file: fopen(), %s", 
				__FILE__, __LINE__, strerror(errno));
		return -1;
	}

	pid = getpid();
	if(fwrite((char *)&pid, 1, sizeof(pid), fp) != sizeof(pid))
	{
		ul_writelog(UL_LOG_FATAL, "%s %d write_pid_file: fwrite(), %s", 
				__FILE__, __LINE__, strerror(errno));
		fclose(fp);
		return -1;
	}

	fclose(fp);

	return 0;
}

int check_pid_file(char *file_name)
{
	int  pid;
	FILE *fp;

	fp = fopen(file_name, "r+b");
	if(fp == NULL)
		return -1;

	if(fread((char *)&pid, 1, sizeof(pid), fp) < sizeof(pid))
	{
		fclose(fp);
		return -1;
	}
	fclose(fp);

	if(kill(pid, 0) == 0)
		return pid;

	return -1;
}

void clear_pid_file(void)
{
	unlink(g_cur_config->pid_file);
}

int init_transmit(void)
{
	int pid;
	Config config;

	memset(&config, 0, sizeof(Config));
	if(load_config(&config, true) < 0)
	{
		ul_writelog(UL_LOG_FATAL, "%s  %d  init_transmit: load_config() error", 
				__FILE__, __LINE__);
		return -1;
	}

	pid = check_pid_file(config.pid_file);
	if(pid >= 0)
	{
		ul_writelog(UL_LOG_FATAL, "%s %d init_transmit: check_pid_file(), transmit (pid %d) already running",
				__FILE__, __LINE__, pid);
		exit(-1);
	}

	if(init_signal() < 0)
	{
		ul_writelog(UL_LOG_FATAL, "%s  %d  init_transmit: init_signal() error", 
				__FILE__, __LINE__);
		return -1;
	}

	if(init_shm(&config) < 0)
	{
		ul_writelog(UL_LOG_FATAL, "%s  %d  init_transmit: init_shm() error", 
				__FILE__, __LINE__);
		return -1;
	}

	if(init_log(g_cur_config->log_path, g_cur_config->log_file, 
				g_cur_config->log_size, g_cur_config->log_level) < 0)
	{
		ul_writelog(UL_LOG_FATAL, "%s  %d  init_transmit: unit_log() error", 
				__FILE__, __LINE__);
		return -1;
	}

	if(load_all_dict(g_cur_config, 0) < 0)
	{
		ul_writelog(UL_LOG_FATAL, "%s %d init_transmit: load_all_dict() error", 
				__FILE__, __LINE__);
		return -1;
	}


	if (load_filter(g_cur_config) < 0){
		ul_writelog(UL_LOG_FATAL, "%s %d init_transmit: load_filter() error", 
				__FILE__, __LINE__);		
		return -1;		
	}
	return 0;
}

void deinit_transmit(void)
{
	deinit_shm();
	deinit_log();
	clear_pid_file();

}

int make_listen_sock(void)
{
	int s;
	int one = 1;
	sockaddr_in server_addr;
	struct hostent *hep;

	server_addr.sin_family = AF_INET;
	server_addr.sin_port = htons(g_cur_config->listen_port);
	if(!strcmp(g_cur_config->listen_addr, "any"))
	{
		(server_addr.sin_addr).s_addr = htonl(INADDR_ANY);
	}
	else
	{
		hep = gethostbyname(g_cur_config->listen_addr);
		if(hep == NULL)
		{
			ul_writelog(UL_LOG_FATAL, "%s %d make_listen_socket: gethostbyname(%s) error, %s", 
					__FILE__, __LINE__, g_cur_config->listen_addr, strerror(errno));
			return -1;
		}
		(server_addr.sin_addr).s_addr = ((struct in_addr *) (hep->h_addr))->s_addr;

	}

	if((s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)) == -1) 
	{
		ul_writelog(UL_LOG_FATAL, "%s %d make_listen_socket: socket() error, %s", 
				__FILE__, __LINE__, strerror(errno));
		return -1;
	}


	if(setsockopt(s, SOL_SOCKET, SO_REUSEADDR, (char *) &one, sizeof(int)) < 0) 
	{
		ul_writelog(UL_LOG_FATAL, "%s %d make_listen_sock: setsockopt() error, %s", 
                __FILE__, __LINE__, strerror(errno));
        close(s);
        return -1;
    }

    /*
       one = 1;
       if (setsockopt(s, SOL_SOCKET, SO_KEEPALIVE, (char *) &one, sizeof(int)) < 0) 
       {
       ul_writelog(UL_LOG_FATAL, "%s %d make_listen_sock: setsockopt() error, %s", 
       __FILE__, __LINE__, strerror(errno));
       close(s);
       return -1;
       }*/

    /* The Nagle algorithm says that we should delay sending partial
     * packets in hopes of getting more data.  We don't want to do
     * this; we are not telnet.  There are bad interactions between
     * persistent connections and Nagle's algorithm that have very severe
     * performance penalties.  (Failing to disable Nagle is not much of a
     * problem with simple HTTP.)
     *
     * In spite of these problems, failure here is not a shooting offense.
     */
    if (setsockopt(s, IPPROTO_TCP, TCP_NODELAY, (char *) &one, sizeof(int)) < 0) 
    {
        ul_writelog(UL_LOG_FATAL, "%s %d make_listen_sock: setsockopt() error, %s", 
                __FILE__, __LINE__, strerror(errno));
        close(s);
        return -1;
    }

    if(g_cur_config->send_buff_size) 
    {
        if(setsockopt(s, SOL_SOCKET, SO_SNDBUF, (char *)&g_cur_config->send_buff_size, sizeof(int)) < 0)
        {
            ul_writelog(UL_LOG_FATAL, "%s %d make_listen_sock: setsockopt() error, %s", 
                    __FILE__, __LINE__, strerror(errno));
            close(s);
            return -1;
        }
    }

    if(g_cur_config->recv_buff_size) 
    {
        if(setsockopt(s, SOL_SOCKET, SO_RCVBUF, (char *)&g_cur_config->recv_buff_size, sizeof(int)) < 0)
        {
            ul_writelog(UL_LOG_FATAL, "%s %d make_listen_sock: setsockopt() error, %s", 
                    __FILE__, __LINE__, strerror(errno));
            close(s);
            return -1;
        }
    }


    if(bind(s, (struct sockaddr *)&server_addr, sizeof(struct sockaddr_in)) == -1) 
    {	
        ul_writelog(UL_LOG_FATAL, "%s %d make_listen_sock: bind() error, %s", 
                __FILE__, __LINE__, strerror(errno));
        close(s);
        return -1;
    }

    if(listen(s, g_cur_config->listen_num) == -1) 
    {
        ul_writelog(UL_LOG_FATAL, "%s %d make_listen_sock: listen() error, %s", 
                __FILE__, __LINE__, strerror(errno));
        close(s);
        return -1;
    }

    if(set_sock_nonblock(s) == -1)
    {
        ul_writelog(UL_LOG_FATAL, "%s %d make_listen_sock: set_sock_nonblock() error", 
                __FILE__, __LINE__);
        close(s);
        return -1;
    }


    return s;
}

void check_config_change()
{
    if(g_cur_config != &(g_shm_config->config[g_shm_config->cur_config]))
    {
        g_cur_config = &(g_shm_config->config[g_shm_config->cur_config]);
        g_cur_innocent_dict = (IpItem *)(g_shm_addr + sizeof(ShmConfig) +
                g_shm_config->cur_config * g_cur_config->max_innocent_num * sizeof(IpItem));
        g_cur_blacklist_dict = (IpItem *)(g_shm_addr + sizeof(ShmConfig) +
                2 * g_cur_config->max_innocent_num * sizeof(IpItem) +
                g_shm_config->cur_config * g_cur_config->max_blacklist_num * sizeof(IpItem));
		
		reset_prison_record();

        ul_writelog(UL_LOG_NOTICE, "The config changed");
    }
}

inline int service_idle()
{
    return (list_empty(&g_connection_read) 
            && list_empty(&g_connection_read_ag)
            && list_empty(&g_connection_proc) 
            && list_empty(&g_connection_write));
}

inline void handle_callback(Connection *cur_conn, int type, int fid, int data)
{
    if(cur_conn->avail == 0)
    {
        return;
    }
    ul_writelog(UL_LOG_DEBUG, "op[%d] type[%d] apache=[%d] client=[%d] evt[%d]", 
            cur_conn->cur_op, type,
            cur_conn->apache_sock.fd,
            cur_conn->client_sock.fd,
            data
            );

    if(cur_conn->cur_proc(cur_conn, type, fid, data) == ST_NEXT)
    {
        while(cur_conn->cur_proc(cur_conn, EVT_ALWAYS, 0, 0) == ST_NEXT)
        {}
    }
}
int handle_timeout_queue(list_t *queue, int timeo, int normal_timeo)
{
    Connection  *cur_conn;
    list_t      *node, *n;
    int         msec_diff;
    
    list_for_each_safe(node, n, queue)
    {
        cur_conn = list_entry(node, Connection, node); 

        /* how long past */
        msec_diff = tv_sub(&g_now, &cur_conn->timer[0]);

        /* timeout or (connection free num not enough and shorter timeout) */
        if(msec_diff > timeo
                || (g_connection_free_num < g_cur_config->min_free_connection
                    && msec_diff > normal_timeo
                   )
          )
        {
            handle_callback(cur_conn, EVT_TIMER, 0, 0);
        }
        else
        {
            break;    
        }
    }
    return 0;
}

int handle_timeout_list(list_t *list)
{
    Connection  *cur_conn;
    list_t      *node, *n;
    int         i;
    
    list_for_each_safe(node, n, list)
    {
        /* get front node from the queue */
        cur_conn = list_entry(node, Connection, node); 

        for(i = 0;i < MAX_TIMER_NUM; ++i)
        {
            if(cur_conn->timer[i].tv_sec < 0)
            {
                break;
            }
            /* time pasted timer set before */
            if(tv_sub(&g_now, &cur_conn->timer[i]) > 0)
            {
                handle_callback(cur_conn, EVT_TIMER, i, 0);
            }
        }
    }
    return 0;
}

int handle_timeout()
{
    static struct timeval fast_last_tm = g_now;
    static struct timeval slow_last_tm = g_now;
    
    /* fast timer */
    if(tv_sub(&g_now, &fast_last_tm) > g_cur_config->fast_timer)
    {
        fast_last_tm = g_now;
        handle_timeout_list(&g_connection_proc);
    }
    /* slow timer */
    if(tv_sub(&g_now, &slow_last_tm) > g_cur_config->slow_timer)
    {
        slow_last_tm = g_now;

        handle_timeout_queue(&g_connection_read_ag, 
                g_cur_config->max_keep_alive_time, 
                g_cur_config->normal_read_time);
        
        handle_timeout_queue(&g_connection_read, 
                g_cur_config->read_client_timeout, 
                g_cur_config->normal_read_time);
        
        handle_timeout_queue(&g_connection_write,
                g_cur_config->interval_write_client_timeout,
                g_cur_config->normal_write_time);
        
    }
    return 0;
}

int handle_epoll(epoll_event *ep_evt, int ready_num)
{
    Connection *cur_connection;
    int i;
    
    for(i = 0;i < ready_num; ++i)
    {
        if(ep_evt[i].data.ptr == NULL)
        {
            if(ep_evt[i].events & (EPOLLERR | EPOLLHUP))
            {
                ul_writelog(UL_LOG_FATAL, "listen fd: ERR|HUP: [%d]%s",
                        errno, strerror(errno));
                return -1;
            }
            if(accept_new_connection() < 0)
            {
                return -1;
            }
            break;
        }
    }
    for(i = 0;i < ready_num; ++i)
    {
        if(ep_evt[i].data.ptr != NULL)
        {
            cur_connection = (Connection *)ep_evt[i].data.ptr;
            handle_callback(cur_connection, EVT_FD, 0, ep_evt[i].events);
        }
    }
    return 0;
}

void handle_connection(void)
{
    int ready_num;
    
    struct epoll_event *ep_evt;
#ifdef EXTRA_STATISTICS
    struct timeval tv1;
    struct timeval tv2;
    struct timeval tv3;
#endif

    /* alloc epoll and epoll events poll */
    if(create_epoll(10000) < 0)
    {
        goto out;
    }
    ep_evt = alloc_ep_events(MAX_EVENTS_NUM);
    if(ep_evt == NULL)
    {
        goto out;
    }

    /* main loop */
    while(1)
    {
        check_config_change();

        if(g_terminate_flag)
        {
            g_cur_config->max_keep_alive_time = 0;
            if(g_accept_sock.fd >= 0)
            {
                close_handle(&g_accept_sock);
            }
            if(service_idle())
            {
                break;
            }
        }
        /* create listen socket */
        if(!g_terminate_flag && g_accept_sock.fd==-1 && (g_cur_config->main_apache)->available==true)
        {
            g_accept_sock.fd = make_listen_sock();
            if(g_accept_sock.fd < 0)
            {
                ul_writelog(UL_LOG_FATAL, "%s %d work: make_listen_sock() error, transmit exit", 
                        __FILE__, __LINE__);
                goto out;
            }
            
            if(add_handle(NULL, &g_accept_sock, EPOLLIN | EPOLLERR | EPOLLHUP) < 0)
            {
                goto out;
            }
        }

        /* get current time */
        gettimeofday(&g_now, NULL);

        /* 
         *  timeout trigger 
         */
        if(handle_timeout() < 0)
        {
            goto out;
        }


#ifdef EXTRA_STATISTICS
        gettimeofday(&tv1, NULL);
#endif
        while(1)
        {
            ready_num = epoll_wait(g_epfd, ep_evt, MAX_EVENTS_NUM, g_cur_config->fast_timer);
            if(ready_num < 0)
            {
                if(errno == EINTR)
                {
                    continue;
                }
                ul_writelog(UL_LOG_FATAL, "%s %d hand_connection: epoll_wait(), %s", 
                        __FILE__, __LINE__, strerror(errno));
                goto out;
            }
            break;
        }
        
#ifdef EXTRA_STATISTICS
        g_statistics->cycle_num++;
        g_statistics->ready_handle_num += ready_num;

        gettimeofday(&tv2, NULL);
        g_statistics->select_time_used += 
            (tv2.tv_sec-tv1.tv_sec)*1000000 + (tv2.tv_usec-tv1.tv_usec);
#endif

        /* 
         *  handler events trigger
         */
        if(handle_epoll(ep_evt, ready_num) < 0)
        {
            goto out;
        }

#ifdef EXTRA_STATISTICS
        gettimeofday(&tv3, NULL);
        g_statistics->process_time_used += 
            (tv3.tv_sec-g_now.tv_sec)*1000000+(tv3.tv_usec-g_now.tv_usec);
#endif
    }

out:
    if(ep_evt != NULL)
    {
        free(ep_evt);
    }
    if(g_accept_sock.fd != -1)
    {
        close_handle(&g_accept_sock);
        ul_writelog(UL_LOG_WARNING, "Listen port shutdown--Error occurred");
    }
    if(g_epfd != -1)
    {
        close(g_epfd);
        g_epfd = -1;
    }
}

int init_work(void)
{
    char log_file[MAX_PATH_LEN];

    memset(g_statistics, 0, sizeof(Statistics));

    g_cur_innocent_dict = (IpItem *)(g_shm_addr + sizeof(ShmConfig) +
            g_shm_config->cur_config * g_cur_config->max_innocent_num * sizeof(IpItem));
    g_cur_blacklist_dict = (IpItem *)(g_shm_addr + sizeof(ShmConfig) +
            2 * g_cur_config->max_innocent_num * sizeof(IpItem) +
            g_shm_config->cur_config * g_cur_config->max_blacklist_num * sizeof(IpItem));

    ul_closelog(0);
    snprintf(log_file, MAX_PATH_LEN, "%swork", g_cur_config->log_file);
    if(init_log(g_cur_config->log_path, log_file, g_cur_config->log_size, g_cur_config->log_level) < 0)
    {
        ul_writelog(UL_LOG_FATAL, "%s  %d  init_work: unit_log() error", 
                __FILE__, __LINE__);
        return -1;
    }

    if(init_connection_mem(g_cur_config->max_connection_num, g_cur_config->inbuff_len) < 0)
    {
        ul_writelog(UL_LOG_FATAL, "%s  %d  init_work: init_connection_mem() error", 
                __FILE__, __LINE__);
        return -1;
    }
    if(init_outbuff_mem(g_cur_config->max_outbuff_num, g_cur_config->outbuff_len) < 0)
    {
        ul_writelog(UL_LOG_FATAL, "%s  %d  init_work: init_outbuff_mem() error", 
                __FILE__, __LINE__);
        return -1;
    }

    if(create_ip_dict() < 0)
    {
        ul_writelog(UL_LOG_FATAL, "%s  %d  init_work: create_ip_dict() error", 
                __FILE__, __LINE__);
        return -1;
    }

	if(0 > init_prison()){
		ul_writelog(UL_LOG_FATAL, "%s  %d  init_work: init_prison error",
				__FILE__, __LINE__);
		return -1;				
	}

    if(init_apache() < 0)
    {
        ul_writelog(UL_LOG_FATAL, "%s  %d  init_work: init_apache error", 
                __FILE__, __LINE__);
        return -1;
    }

    return 0;
}

void deinit_work(void)
{
    deinit_connection_mem();
    deinit_outbuff_mem();
    delete_ip_dict();
    deinit_apache();
/*    free_apache(); */
    ul_closelog(0);
}

void work(void)
{
    if(init_work() < 0)
    {
        ul_writelog(UL_LOG_FATAL, "%s %d work: init_work() error, transmit exit", 
                __FILE__, __LINE__);
        return ;
    }

    handle_connection();

    ul_writelog(UL_LOG_NOTICE, "transmit_work terminate normally");
    deinit_work();
}

int main(int argc, char *argv[])
{
	int status;

	get_option(argc, argv);
	if(init_transmit() < 0)
	{
		ul_writelog(UL_LOG_FATAL, "%s %d main: init_transmit error, transmit exit", __FILE__, __LINE__);
		exit(-1);
	}

	if(detach() < 0)
	{
		ul_writelog(UL_LOG_FATAL, "%s %d main: detach() error",
					__FILE__, __LINE__);
		exit(-1);
	}
	if(write_pid_file() < 0)
	{
		ul_writelog(UL_LOG_FATAL, "%s %d main: write_pid_file() error",
					__FILE__, __LINE__);
		exit(-1);
	}

	init_signal();

	while(1)
	{
		if(g_terminate_flag)
		{
			if(g_reload_proc_pid==-1 && g_work_proc_pid==-1)
			{
				ul_writelog(UL_LOG_NOTICE, "transmit terminate normally");
				break;
			}
				
		}

		if(!g_terminate_flag && g_reload_proc_pid == -1)
		{
			g_reload_proc_pid = fork();
			if(g_reload_proc_pid < 0)
			{
				ul_writelog(UL_LOG_FATAL, "%s %d main: fork() error, %s",
							__FILE__, __LINE__, strerror(errno));
			}
			else
			if(g_reload_proc_pid == 0)
			{
				reload();
				return 0;
			}
		}

        if(!g_terminate_flag && g_work_proc_pid==-1)
		{
			g_work_proc_pid = fork();
			if(g_work_proc_pid < 0)
			{
				ul_writelog(UL_LOG_FATAL, "%s %d main: fork() error, %s",
							__FILE__, __LINE__, strerror(errno));
			}
			else
			if(g_work_proc_pid == 0)
			{
				work();
				return 0;
			}
		}

		wait(&status);
        
        ul_writelog(UL_LOG_NOTICE, "main process wake up");

		if(g_reload_proc_pid!=-1 && kill(g_reload_proc_pid, 0) < 0)
		{
			if(!g_terminate_flag)
				ul_writelog(UL_LOG_NOTICE, "reload process exit abnormally");
			g_reload_proc_pid = -1;
		}
		if(g_work_proc_pid!=-1 && kill(g_work_proc_pid, 0) < 0)
		{
			if(!g_terminate_flag)
				ul_writelog(UL_LOG_NOTICE, "work process exit abnormally");
			g_work_proc_pid = -1;
		}
	}

	deinit_transmit();

	return 0;
}


