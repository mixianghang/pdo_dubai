#include <stdio.h>
#include <string.h>
#include <libxml/xmlmemory.h>
#include <libxml/parser.h>
#include <iconv.h>
#include <libxml/encoding.h>
#include <ul_log.h>
#include "policyframe.h"
#include "frame_util.h"
#define PATTERDEFINE "PatternDefine"
#define POLICYRULE "Rule"
#define PATTERN "Pattern"
#define ACTION "Action"
//#define WARNING(fmt,...) printf("%s-%d:"fmt"\n",__FILE__,__LINE__,##__VA_ARGS__)
//#define BWSDEBUG WARNING

extern PatternMatchFactoryPtr patternlist[];
extern ActionFactoryPtr	actionlist[];

#define DEFINE_PATTERN_LIST_NUM 512

#define NOT_DEFINE_PATTERN_LIST_NUM 512

#define ACTION_LIST_NUM 512

typedef struct _ActionGroup{
    ActionInterfacePtr ActionInterfaceList[ACTION_LIST_NUM];
    int ActionNum;
} ActionGroup;
typedef ActionGroup* ActionGroupPtr;
static ActionGroup actiongroup;

typedef struct _PatternGroup{
    PatternMatchInterfacePtr DefinePatternList[DEFINE_PATTERN_LIST_NUM];
    int DefinePatternNum;
    PatternMatchInterfacePtr NotDefinePatternList[NOT_DEFINE_PATTERN_LIST_NUM];
    int NotDefinePatternNum;
}PatternGroup;
typedef PatternGroup* PatternGroupPtr;
static PatternGroup patterngroup;

#define POLICY_NUM 512
typedef struct _RuleGroup{
    Rule prePolicyList[POLICY_NUM];
    int PrePolicyNum;
    Rule handlerPolicyList[POLICY_NUM];
    int handlerPolicyNum;
    Rule upstreamPlicyList[POLICY_NUM];
    int upstreamPlicyNum;
} RuleGroup;
typedef RuleGroup* RuleGroupPtr;
static RuleGroup rulegroup;

/*
 * 0 match
 * -1 not match
 */
static inline int
attributevalueMatch(xmlNodePtr pcur,char *attribute,char *value)
{
   xmlChar *name; 
   name = xmlGetProp(pcur, (const xmlChar*)attribute);                                                                                   
   if (name == NULL)
       return -1;
   if ((xmlStrlen(name) == (int) strlen(value))&&\
	   (xmlStrcmp(name,(xmlChar*)value) == 0)){
       xmlFree(name);
       return 0;
   }
   xmlFree(name);
   return -1;

}
static PatternMatchInterfacePtr
findFromDefinePatternList(PatternGroupPtr ppatterngroup,xmlNodePtr pxmlcur)
{
    for(int i=0;i< ppatterngroup->DefinePatternNum;i++){
	if (tagNameMatch(pxmlcur,ppatterngroup->DefinePatternList[i]->patterntype) == 0){
	    if (attributevalueMatch(pxmlcur,"match",ppatterngroup->DefinePatternList[i]->patternname) == 0 ||\
		    attributevalueMatch(pxmlcur,"notmatch",ppatterngroup->DefinePatternList[i]->patternname) == 0){
		return ppatterngroup->DefinePatternList[i];
	    }
	}
    }
    return NULL;
}
/* 0 success
 * -1 the list is full
 */
static int
addtoActionList(ActionGroupPtr pactiongroup,ActionInterfacePtr node)
{
    if (pactiongroup->ActionNum < ACTION_LIST_NUM - 1)
	pactiongroup->ActionInterfaceList[pactiongroup->ActionNum++] = node;
    else	    
	return -1;
    return 0;
}
static void
freeActionList(ActionGroupPtr pactiongroup)
{
    ActionInterfacePtr pai;
    ActionFactoryPtr   paf;
    for(int i=0;i < pactiongroup->ActionNum  ;i++){
	pai = pactiongroup->ActionInterfaceList[i];
	paf = pai->pfactory;
	if (paf == NULL || paf->prelease == NULL){
	    WARNING("Not give the ACTION[%s] release function",paf->actionname);
	    RELEASE_ACTION_INTERFACE(pai);
	    continue;
	}
	BWSDEBUG("Start to release Action[%s]",paf->actionname);
	paf->prelease(pai);
	RELEASE_ACTION_INTERFACE(pai);
    }
    pactiongroup->ActionNum = 0;
}
static ActionFactoryPtr 
findActionFactory(const xmlChar* name)
{   
    int i=0;
    int len = xmlStrlen(name);
    while(actionlist[i] != NULL){
	if ((strlen(actionlist[i]->actionname) == (unsigned)len)&&\
		(xmlStrcmp((xmlChar*)actionlist[i]->actionname,name) == 0))
		return actionlist[i];
	i++;
    }
    return NULL;

}
/*fix me*/
/* this function shold look alike buildAndOr */
static ActionInterfacePtr 
createAction(ActionGroupPtr pactiongroup,REGION region,xmlNodePtr pcur)
{
    ActionFactoryPtr pf = NULL;
    ActionInterfacePtr pi = NULL;
    int res = -1;
    while (pcur != NULL && pcur->type != XML_ELEMENT_NODE ) pcur = pcur->next;    //skip the comment element 
    if (pcur == NULL) {
	WARNING("There is no Element in the Action tag!!");
	return NULL;
    }
    pf = findActionFactory(pcur->name);
    if (pf == NULL){
	WARNING("Can't find any ActionInterfacePtr for Action[%s]",pcur->name);
	return NULL;
    }
    if (pf->pcreate != NULL ){
	NEW_ACTION_INTERFACE(pi);
	if (pi == NULL){
	    WARNING("Get ActionInterface Error! ");
	    return NULL;
	}
	res = pf->pcreate(pi,pcur);	
	if (-1 == res){
	    RELEASE_ACTION_INTERFACE(pi);
	    WARNING("Create the Action[%s] fail!",pcur->name);
	    return NULL;
	}
	if (!(pi->region & region)){
	    WARNING("This Action[%s] should not apear the [%s] REGION",pcur->name,RegionName(region));
	    pf->prelease(pi);
	    RELEASE_PATTERN_MATCH_INTERFACE(pi);
	    return NULL;
	}
	if (0 != addtoActionList(pactiongroup,pi)){
	    pf->prelease(pi);
	    RELEASE_PATTERN_MATCH_INTERFACE(pi);
	    WARNING("The ActionList is Full!");
	    return NULL;
	}
	BWSDEBUG("Build Rule Action	[%s]",pf->actionname);
    }else{
	WARNING("No create is assigned for Action[%s]!",pcur->name);
	return NULL;
    }
    pcur = pcur->next;
    while ( pcur != NULL && pcur->type != XML_ELEMENT_NODE) pcur = pcur->next;
    if (pcur != NULL){
	WARNING("There is more than one element node in the Action tag.[%s]",pcur->name);
	return NULL;
    }else
	return pi;
}

/*
 * 0 sucess
 * -1 the list is full
 */
static int
addtoNotDefinePatternList(PatternGroupPtr ppatterngroup,PatternMatchInterfacePtr node)
{
    if (ppatterngroup->NotDefinePatternNum < NOT_DEFINE_PATTERN_LIST_NUM -1){
	node->listoffset = ppatterngroup->NotDefinePatternNum;
	ppatterngroup->NotDefinePatternList[ppatterngroup->NotDefinePatternNum++] = node;
    }
    else
	return -1;
    return 0;
}

/*
 * 0 sucess 
 * -1 the list is full
 */
static int
addtoDefinePatternList(PatternGroupPtr ppatterngroup,PatternMatchInterfacePtr node)
{
    if (ppatterngroup->DefinePatternNum < DEFINE_PATTERN_LIST_NUM - 1){
	node->listoffset = ppatterngroup->DefinePatternNum;
	ppatterngroup->DefinePatternList[ppatterngroup->DefinePatternNum++] = node;
    }
    else
	return -1;
    return 0;
}
static void 
freeAllNotDefinePatternList(PatternGroupPtr ppatterngroup)
{
    int i = 0;
    PatternMatchInterfacePtr pi;
    PatternMatchFactoryPtr pf;
    for(;i < ppatterngroup->NotDefinePatternNum ;i++){
	pi = ppatterngroup->NotDefinePatternList[i];
	pf = pi->pfactory;
	if (NULL == pf || NULL == pf->prelease){
	    WARNING("The [NotDefine]Pattern[%s] Name[%s] is not given Factory to release the Resource!(Maybe Cause memory leak!)",\
		    pi->patterntype,pi->patternname);
	    continue;
	    RELEASE_PATTERN_MATCH_INTERFACE(pi);
	}
	BWSDEBUG("Start to Free [NotDefine][%s][%s] resource",pi->patterntype,pi->patternname);
	pf->prelease(pi);
	RELEASE_PATTERN_MATCH_INTERFACE(pi);
    }
    ppatterngroup->NotDefinePatternNum = 0;
}

static void 
freeAllDefinePatternList(PatternGroupPtr ppatterngroup)
{
    int i = 0;
    PatternMatchInterfacePtr pi;
    PatternMatchFactoryPtr pf;
    for(;i < ppatterngroup->DefinePatternNum ;i++){
	pi = ppatterngroup->DefinePatternList[i];
	pf = pi->pfactory;
	if (NULL == pf || NULL == pf->prelease){
	    WARNING("The Pattern[%s] Name[%s] is not given Factory to release the Resource!(Maybe Cause memory leak!)",\
		    pi->patterntype,pi->patternname);
	    RELEASE_PATTERN_MATCH_INTERFACE(pi);
	    continue;
	}
	BWSDEBUG("Start to Free [%s][%s] resource",pi->patterntype,pi->patternname);
	pf->prelease(pi);
	RELEASE_PATTERN_MATCH_INTERFACE(pi);
    }
    ppatterngroup->DefinePatternNum = 0;
}
/*
 * 0  Success 
 * -1 prePolicyList if full!
 */
static int
addtoPolicyList(RuleGroupPtr prg,RulePtr prule)
{
    if (strlen(prule->RuleType) == strlen("PRE")&&strncmp(prule->RuleType,"PRE",strlen("PRE")) == 0){
	  if (prg->PrePolicyNum < POLICY_NUM - 1){
		prg->prePolicyList[prg->PrePolicyNum++] = *prule;
		return 0;
	    }else
	    	return -1;
    }else if (strlen(prule->RuleType) == strlen("HANDLE")&&strncmp(prule->RuleType,"HANDLE",strlen("HANDLE")) == 0){
	if  ( prg->handlerPolicyNum < POLICY_NUM -1 ){
		prg->handlerPolicyList[prg->handlerPolicyNum++] = *prule;
		return 0;
	}else
		return -1;
    }else if (strlen(prule->RuleType) == strlen("UPSTREAM")&&strncmp(prule->RuleType,"UPSTREAM",strlen("UPSTREAM")) == 0){
	if (prg->upstreamPlicyNum < POLICY_NUM - 1){
	    prg->upstreamPlicyList[prg->upstreamPlicyNum++] = *prule;
	    return 0;
	}else
	    	return -1;
    }
    return -1;
}
static void 
freeOnePolicy(RuleNodePtr prulenode)
{
    if (prulenode == NULL)
	return;
    freeOnePolicy(prulenode->link);prulenode->link = NULL;
    freeOnePolicy(prulenode->next);prulenode->next = NULL;
    free (prulenode);
    return;
}
static void 
freeallPolicy(RuleGroupPtr prg)
{
    for(int i =0;i < prg->PrePolicyNum;i++){
	freeOnePolicy(&(prg->prePolicyList[i].RuleListHead));
    }
    for(int i=0;i < prg->handlerPolicyNum;i++){
	freeOnePolicy(&(prg->handlerPolicyList[i].RuleListHead));
    }
    prg->PrePolicyNum = 0;
    prg->handlerPolicyNum = 0;
}
static PatternMatchFactoryPtr
findFactory(const xmlChar *name)
{
    int i=0;
    int len = xmlStrlen(name);
    while(patternlist[i] != NULL){
	if ((strlen(patternlist[i]->patterntype) == (unsigned)len)&&\
		(xmlStrcmp((xmlChar*)patternlist[i]->patterntype,name) == 0))
		return patternlist[i];
	i++;
    }
    return NULL;
}
/*
 * 0 success
 * -1 error
 */
static int 
createPatternDefine(PatternGroupPtr ppatterngroup,xmlNodePtr pcur)
{
    PatternMatchFactoryPtr pf = NULL;
    PatternMatchInterfacePtr pi = NULL;
    int res = -1;
    pf = findFactory(pcur->name);
    if (pf == NULL){
	WARNING("Can't find any PatternMatchInterfacePtr for the Pattern[%s]",pcur->name);
	return -1;
    }
    if (pf->pcreate != NULL ){
	NEW_PATTERN_MATCH_INTERFACE(pi);
	if (pi == NULL) {
	    WARNING("Create Pattern Match Interface failed");
	    return -1;
	}
	res = pf->pcreate(pi,pcur);
	if (-1 == res){
	    RELEASE_PATTERN_MATCH_INTERFACE(pi);
	    WARNING("Create the Pattern[%s] in %s error!",pcur->name,PATTERDEFINE);
	    return -1;
	}
	pi->listype = DEFINE_LIST;
	if (0 != addtoDefinePatternList(ppatterngroup,pi)){
	    pf->prelease(pi);
	    RELEASE_PATTERN_MATCH_INTERFACE(pi);
	    WARNING("The DefinePatterList is Full!");
	    return -1;
	}
    }else{
	WARNING("No create is assigned for Pattern[%s]!",pcur->name);
	return -1;
    }
    return 0;
}
/*
 * 0  success build all define pattern
 * -1 error occorued
 */
static int
patternDefine(PatternGroupPtr ppatterngroup,xmlNodePtr pcur)
{
    xmlNodePtr pnode = pcur->xmlChildrenNode;
    while(pnode != NULL){
	if (pnode->type == XML_ELEMENT_NODE){
	    if (createPatternDefine(ppatterngroup,pnode) != 0){//we should release all the resource that come from the pattern define!
		break;	
	    }
	}
	pnode = pnode->next;
    }
    if (pnode == NULL){
	BWSDEBUG("%s","Success Define all the Pattern!");
	return 0;
    }
    BWSDEBUG("%s","Some Error occoured in the Pattern define Process");
    freeAllDefinePatternList(ppatterngroup);
    return -1;
}
static PatternMatchInterfacePtr
createPatternNotDefine(PatternGroupPtr ppatterngroup,xmlNodePtr pcur)
{
    PatternMatchFactoryPtr pf = NULL;
    PatternMatchInterfacePtr pi = NULL;
    int res = -1;
    pf = findFactory(pcur->name);
    if (pf == NULL){
	WARNING("Can't find any PatternMatchInterfacePtr for the Not Define Pattern[%s] ",pcur->name);
	return NULL;
    }
    if (pf->pcreate != NULL ){
	NEW_PATTERN_MATCH_INTERFACE(pi); 
	if (pi == NULL){
	    WARNING("Create Pattern Match Interface failed");
	    return NULL;
	}
	res = pf->pcreate(pi,pcur);	
	if (-1 == res){
	    RELEASE_PATTERN_MATCH_INTERFACE(pi);
	    WARNING("Create the [NotDefine]Pattern[%s] in NotDefine error!",pcur->name);
	    return NULL;
	}
	pi->listype = NOTDEFINE_LIST;
	if (0 != addtoNotDefinePatternList(ppatterngroup,pi)){
	    pf->prelease(pi);
	    RELEASE_ACTION_INTERFACE(pi);
	    WARNING("The NotDefinePatterList is Full!");
	    return NULL;
	}
    }else{
	WARNING("No create is assigned for [NotDefine]Pattern[%s]!",pcur->name);
	return NULL;
    }
    return pi;



}
static PatternMatchInterfacePtr
getPatternMatchInterface(PatternGroupPtr ppatterngroup,xmlNodePtr pcur) 
{
    PatternMatchInterfacePtr ppmi = NULL;
    /*
     * first we find the PatternMatchInterface in the DefinePatternList
     */
    ppmi = findFromDefinePatternList(ppatterngroup,pcur);
    if (ppmi != NULL)
	return ppmi;
    /*
     * if we can't find ,we create!
     */
    ppmi = createPatternNotDefine(ppatterngroup,pcur);
    return ppmi;
}
/*
 * In the RuleNode structure there is two lists:
 * the first is "link",
 * the other is "next".
 * In build the two list ,there is 2 case:
 * 1. normal pattern, we add a RuleNode to the "link" list.
 * 2. and or pattern, we add a RuleNode to the "link" list and then build the "next" list.
 */
static RuleNodePtr
buildAndOr(PatternGroupPtr ppatterngroup,REGION region,xmlNodePtr pxmlcur)
{
    PatternMatchInterfacePtr ppmi;
    RuleNode head;
    RuleNodePtr prulecur,tmprule;
    initRuleNode(&head);
    prulecur = &head;
    while(pxmlcur != NULL){
	if (pxmlcur->type == XML_ELEMENT_NODE){
	    NEW_INIT_RULE_NODE(prulecur->link);
	    if (prulecur->link == NULL)
		goto err;
	}else{
	    pxmlcur = pxmlcur->next;
	    continue;
	}
	if (tagNameMatch(pxmlcur,"AND") == 0){
	    prulecur->link->nodetype = And;
	    if ( NULL == (prulecur->link->next = buildAndOr(ppatterngroup,region,pxmlcur->xmlChildrenNode)))
		goto err;
	}else if (tagNameMatch(pxmlcur,"OR") == 0){
	    prulecur->link->nodetype = Or;
	    if ( NULL == (prulecur->link->next = buildAndOr(ppatterngroup,region,pxmlcur->xmlChildrenNode)))
		goto err;
	}else if (pxmlcur->type == XML_ELEMENT_NODE){
	   if (NULL == (ppmi = getPatternMatchInterface(ppatterngroup,pxmlcur))) 
	       goto err;
	   BWSDEBUG("Build Rule Node	[%s]",pxmlcur->name);
	   if (!(ppmi->region & region)){
	       WARNING("This Pattern[%s] Should not Appear [%s] REGION!",ppmi->patternname,RegionName(region));
	       goto err;
	   }
	   prulecur->link->nodetype = Normal;
	   prulecur->link->ppmatch_interface = ppmi;
	}
	pxmlcur = pxmlcur->next;
	prulecur = prulecur->link;
    }
    return head.link;
err:
    prulecur = head.link;
    while (prulecur != NULL){
	tmprule = prulecur;
	prulecur = prulecur->link;
	free(tmprule);
    }
    BWSDEBUG("WE ARE OUT");
    return NULL;
}
static int
buildPatternCombination(PatternGroupPtr ppatterngroup,xmlNodePtr cur,RuleNodePtr head,REGION region)
{
 /*
  * PatternMatchInterface is the _resource_ in the RuleNodePtr 
  * but we only pay attention to the RuleNode.
  * PatternMatchInterface is released by the List:
  * DefinePatternList && NotDefinePatternList
  */
  if (NULL != (head->link = buildAndOr(ppatterngroup,region,cur)))
      return 0;
  return -1;
} 
static int
ruleBuild(PatternGroupPtr ppatterngroup,ActionGroupPtr pactiongroup,RuleGroupPtr prulegroup,xmlNodePtr pcur)
{
    xmlNodePtr pnode = pcur->xmlChildrenNode;  
    Rule rule;
    initRule(&rule);
    if (getattributevalue(pcur,"type",rule.RuleType,sizeof rule.RuleType) != 0) return -1;
    if (getattributeint(pcur,"skip",&rule.skip) != 0) return -1;
    if (rule.skip <= 0) {
	WARNING("GIVE A WRONG _skip_ value[%d]!we will use the defualt value[100]",rule.skip);
        rule.skip = 100;
    }
    setRuleRegion(&rule,rule.RuleType);
    if (rule.region == REGION_NOTDEFINE){
	WARNING("Rule Type set Error!");
	return -1;
    }
    BWSDEBUG("skip = %d",rule.skip);
    while (pnode != NULL){
	if (pnode->type == XML_ELEMENT_NODE){
	    if (tagNameMatch(pnode,PATTERN) == 0){
		if (buildPatternCombination(ppatterngroup,pnode->xmlChildrenNode,&(rule.RuleListHead),rule.region) != 0){
		    break;
		}
	    }else if (tagNameMatch(pnode,ACTION) == 0){
		if ((rule.action = createAction(pactiongroup,rule.region,pnode->xmlChildrenNode)) == NULL)
		    break;
	    }
	}
	pnode = pnode->next;
    }
    if (pnode == NULL){
	//add the _rule_ to the list
	if (addtoPolicyList(prulegroup,&rule) != 0){
	    WARNING("Add To PolicyList error");
	    return -1;
	}
	return 0;
    }
    else
	return -1;
}
static void libxml_log(void *ctx, const char *fmt, ...) 
{ 
    char buf[2048];
    va_list ap; 
    va_start(ap, fmt); 
    memset(buf,0,sizeof buf);
    vsnprintf(buf,sizeof buf,fmt,ap);
    ul_writelog(UL_LOG_WARNING,"%s",buf);
    va_end(ap); 
}       
static int
parseDoc(char *docname,const xmlChar *dtdname) {
    xmlDocPtr doc;
    xmlNodePtr cur;
    xmlDtdPtr dtd;
    xmlKeepBlanksDefault(0);

    char xml_errbuf[1024];
    xmlSetGenericErrorFunc(NULL, (xmlGenericErrorFunc)libxml_log);
    doc = xmlParseFile(docname);
    if (doc == NULL ) {
	WARNING("Document not parsed successfully.\n");
	return -1;
    }
    dtd = xmlParseDTD(NULL,dtdname);

    if (NULL == dtd){
	xmlFreeDoc(doc);
	WARNING("Dtd File error!");
	return -1;
    }
    cur = xmlDocGetRootElement(doc);
    if (cur == NULL) {
	WARNING("empty document\n");
	xmlFreeDtd(dtd);
	xmlFreeDoc(doc);
	return -1;
    }
    xmlValidCtxt cvp;
    cvp.userData = (void *) xml_errbuf;                                                 
    cvp.error    = (xmlValidityErrorFunc) sprintf;  
    if (!xmlValidateDtd(&cvp, doc, dtd)) {
	WARNING("%s",xml_errbuf);
	xmlFreeDoc(doc);
	xmlFreeDtd(dtd);
	return -1;
    }
    cur = cur->xmlChildrenNode;
    /*
     * when parse the frame.xml
     * all the tag
     * 1.<PatternDefin>
     * 2.<Rule>
     * 3.<ActionDefine>
     * may be create some resource!
     * But we release these resource here ,we don't
     * release the resource in the tag parse process!
     */
    while(cur != NULL){
	if ((xmlStrlen(cur->name) == (int)strlen (PATTERDEFINE))&&\
		(xmlStrcmp(cur->name,(xmlChar*)PATTERDEFINE) == 0)){
		if (patternDefine(&patterngroup,cur) != 0)
		    break;
	}
	if ((xmlStrlen(cur->name) == (int)strlen (POLICYRULE))&&\
		(xmlStrcmp(cur->name,(xmlChar*)POLICYRULE) ==0 )) {
	    if (ruleBuild(&patterngroup,&actiongroup,&rulegroup,cur) != 0)
		break;
	}
	cur = cur->next;
    }
    if (cur != NULL){// resource release!
	freeallPolicy(&rulegroup);
	freeAllNotDefinePatternList(&patterngroup);
	freeAllDefinePatternList(&patterngroup);
	freeActionList(&actiongroup);
	xmlFreeDtd(dtd);
	xmlFreeDoc(doc);
	return -1;
    }
    xmlFreeDtd(dtd);
    xmlFreeDoc(doc);
    return 0;
}

static enum PatternMatchResult storagemap[]={Match,NotMatch};
static PatternMatchResult 
processPattern(RuleNodePtr prulenode,RuleNodeType list_type,void *proc,short resultstorage[][POLICY_RESULT_NUM])
{
    PatternMatchResult result;
    PatternMatchInterfacePtr pmi;
  
    while (prulenode != NULL){
	if (prulenode->nodetype != Normal){
	    result = processPattern(prulenode->next,prulenode->nodetype,proc,resultstorage);
	}else {
	    pmi = prulenode->ppmatch_interface;
	    short *oneresult = &resultstorage[pmi->listype][pmi->listoffset];
	    if ( *oneresult == NOTPROCESS){
		result = pmi->pmatch(proc,pmi->patterndata,oneresult);
	    }else{
		BWSDEBUG("WE Have a buffer result!");
		result = storagemap[*oneresult - 1];	
	    }
	}
	if (list_type == And){
	    if (result != Match)
		return NotMatch;
	}else if (list_type == Or) {
	    if (result == Match)
		return Match;
	}
	prulenode = prulenode->link;
    }
    if (list_type == And)
	return Match;
    else 
	return NotMatch;
}
void processPreRuleLists(void *proc)
{
    RuleGroupPtr prulegroup = &rulegroup;
    RuleNodePtr rulehead;
    ActionInterfacePtr action;
    int i = 0;
    short result[LIST_NUM][POLICY_RESULT_NUM];
    memset(result,NOTPROCESS,sizeof result);
    BWSDEBUG("PrePolicyNum:%d",prulegroup->PrePolicyNum);
    while (i < prulegroup->PrePolicyNum){
	rulehead = &prulegroup->prePolicyList[i].RuleListHead;
	action   =  prulegroup->prePolicyList[i].action;
	// if there is no pattern at all we should just do the _Action_
	if ( rulehead->link == NULL ||  Match == processPattern(rulehead->link,rulehead->link->nodetype,proc,result)){
	    BWSDEBUG("PRE[%d]:Match and Skip [%d] Rule",i,prulegroup->prePolicyList[i].skip - 1 );
	    if (action != NULL && action->action != NULL){
		action->action(proc,action->actiondata);
	    }else{
		WARNING("The build Rule have porblem! we should not have any [NULL] action");
	    }
	    // the default value of the _skip is 100
	    i += prulegroup->prePolicyList[i].skip;
	    continue;
	}else{
	    BWSDEBUG("PRE[%d]:NotMatch",i);
	}
	i++;
    }
}

void processRuleList(void *patterndata,void *actiondata,RulePtr PolicyList,int PolicyNum)
{
    RuleNodePtr rulehead;
    ActionInterfacePtr action;
    int i = 0;
    short result[LIST_NUM][POLICY_RESULT_NUM];
    memset(result,NOTPROCESS,sizeof result);
    while(i < PolicyNum){
	rulehead = &(PolicyList[i].RuleListHead);
	action   =  PolicyList[i].action;
	if ( rulehead->link == NULL || Match == processPattern(rulehead->link,rulehead->link->nodetype,patterndata,result)){
	    BWSDEBUG("Rule[%d]:Match and Skip [%d] Rule",i,PolicyList[i].skip - 1);
	    action->action(actiondata,action->actiondata);
	    // the default value of the _skip_ is 1
	    i += PolicyList[i].skip;
	    continue;
	}else{
	    BWSDEBUG("Rule[%d]:NotMatch",i);
	}
	i++;
    }
}
void processRule(REGION region,void *patterndata,void*actiondata)
{
    RuleGroupPtr prulegroup = &rulegroup; 
    switch(region) {
	case REGION_PRE:
	    		BWSDEBUG("PRE REGION BEGION[%d]",prulegroup->PrePolicyNum);
	    		processRuleList(patterndata,actiondata,prulegroup->prePolicyList,prulegroup->PrePolicyNum);
			BWSDEBUG("PRE REGION END");
			break;
	case REGION_UPSTREAM:
			BWSDEBUG("UPSTREAM REGION BEGION[%d]",prulegroup->upstreamPlicyNum);
			processRuleList(patterndata,actiondata,prulegroup->upstreamPlicyList,prulegroup->upstreamPlicyNum);
			BWSDEBUG("UPSTREAM REGION END");
			break;
	case REGION_HANDLE:
			WARNING("Now we Don't Have HADLE");break;
	default:WARNING("We Can't Understand the REGION!");break;
    }
}

int load_policyframe_conf(const char *path_ptr, const char *dtdname, const char *docname)
{
    char doc[512];
    char dtd[512];

    if (dtdname == NULL || docname == NULL){
	    WARNING("XML&DTD NO PATH!");
	    return -1;
    }
    snprintf(doc,sizeof doc,"%s%s",path_ptr,docname);
    snprintf(dtd,sizeof dtd,"%s%s",path_ptr,dtdname);
    int ret = parseDoc(doc,(xmlChar*)dtd);
    return ret;
}
/*
int
main(int argc, char **argv) {
    char *docname;
    char *dtdname;
    if (argc != 3) {
	printf("Usage: %s docname dtdname\n", argv[0]);
	return(0);
    }
    docname = argv[1];
    dtdname = argv[2];
    parseDoc (docname,(xmlChar*)dtdname);
    processPreRuleLists(&rulegroup);
    return (1);
}*/
