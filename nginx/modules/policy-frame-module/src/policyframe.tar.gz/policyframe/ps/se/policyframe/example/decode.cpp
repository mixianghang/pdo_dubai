#include "decode.h"

static des_key_schedule key;

static unsigned int checksum_12(unsigned char *data)
{
	unsigned int value = 0;

	value = data[0] + data[1] + data[2] + data[3] + data[4] + data[5]
		+ data[6] + data[7] + data[8] + data[9] + data[10] + data[11];

	return(~value & 0xffff);
}

static int atb(char asc)
{
	if (asc >= 'A' && asc <= 'F') return(asc - 'A'+ 10) ;
	else if (asc >= 'a' && asc <= 'f') return(asc - 'a'+ 10) ;
	else return asc - '0' ;
}

/*
 *  *  initialize the DES decrypt
 *   */
void initkey_schedule(des_key_schedule *szKeySchedule, char *keyStr)
{
	des_cblock key;

	strncpy((char *)key, keyStr, sizeof(key));
	des_set_odd_parity(&key);
	des_key_sched(&key, *szKeySchedule);
}

static int ascTObcd(char *asc, int asclen, unsigned char *bcd, int bcdlen)
{
	int  i = 0;

	if ((bcdlen * 2) < asclen)
		return -1;
	memset(bcd, 0, bcdlen);

	for (i = 0; i < bcdlen; i++)
		bcd[i] = (atb(asc[i*2]))*0x10 + atb(asc[i*2+1]) ;

	return 0 ;
}

int desdecrypt(char *szDecrypt, int nBufferLen, char *pencryptStr, int encryptLen, 
		des_key_schedule *szKeySchedule)
{       
	int i = 0, nLoop = 0;
	char *pcurrentEnc = NULL, *pcurrentDec = NULL;
	des_cblock output, inputEnc;

	/*
	 *      * decrypt cookieID
	 *           */ 
	if ((encryptLen % (sizeof(des_cblock) * 2)) != 0)
		return -1; 

	if ((nBufferLen * 2) < encryptLen)
		return -1;

	nLoop = encryptLen / (sizeof(des_cblock) * 2);
	for (i = 0; i < nLoop; i++) {
		pcurrentEnc = pencryptStr + i * (sizeof(des_cblock) * 2);
		pcurrentDec = szDecrypt + i * sizeof(des_cblock);

		if (ascTObcd(pcurrentEnc, sizeof(des_cblock) * 2, (unsigned char*)inputEnc, 

					sizeof(des_cblock)) < 0) {
			return -1;
		}

		des_ecb_encrypt(&inputEnc, &output, *szKeySchedule, DES_DECRYPT);
		memcpy(pcurrentDec, output, sizeof(des_cblock));
	}
	return 0;   
} 

int validate_id(char *BAIDUID)
{
	char id[16];
	if(0 > desdecrypt(id, 16, BAIDUID, 32, &key)){
		return -1;
	}

	/* printf("%u\t%u\t%u\n", ((int *)id)[0], ((unsigned int *)id)[1], ((unsigned int *)id)[2]); */

	if(*(unsigned int *)(id + 12) != checksum_12((unsigned char *)id))
	{
		return -1;
	} 

	return 0;
}

bool is_valid_cookie(char * pCookie)
{
	if(NULL == pCookie){
		return false;
	}

	if(32 != strlen(pCookie)){
		ul_writelog(UL_LOG_WARNING, "BAIDUID [%s] should be 32 btyes long", pCookie);
		return false;
	}

	if(0 > validate_id(pCookie)){
		ul_writelog(UL_LOG_WARNING, "Invaild BAIDUID [%s], checksum fails", pCookie);
		return false;
	}

	return true;
}

int init_decode(char * pDesKey)
{
	if(NULL == pDesKey){
		return -1;
	}

	initkey_schedule(&key, pDesKey);

	return 0;
}

int main_TEST(int argc, char *argv[])
{
	char buf[4096];

	if(argc > 2 || (argc == 2 && strcmp(argv[1], "-v") == 0))
	{
		fprintf(stderr, "deid [BAIDUID]\n");
		return 1;
	}

	initkey_schedule(&key, "ZxdeacAD");
	if(argc == 2)
	{
		if(strlen(argv[1]) != 32)
		{
			fprintf(stderr, "BAIDUID should be 32 btyes long\n");
			return 2;
		}
		if(validate_id(argv[1]) < 0)
		{
			fprintf(stderr, "Invaild BAIDUID, checksum fails\n");
			return 3;
		}
		return 0;
	}

	while(fgets(buf, 4095, stdin) != NULL)
	{
		validate_id(buf);
	}
	return 0;
}

