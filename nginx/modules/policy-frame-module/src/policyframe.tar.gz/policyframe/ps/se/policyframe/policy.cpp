#include "policy.h"
#include <arpa/inet.h>
#include "policyframe.h"

extern PatternMatchFactoryPtr patternlist[];
int parse_request(quest_t *, stat_t *);

int processPolicy(void *proc, int op)
{
    stat_t conn_s;
    int j = 0, rt; 
    
    if (op == 1){
	BWSDEBUG("STAT_T STRUCT");
    }
    else if (op == 0){
        BWSDEBUG("RAW STRUCT");
	if (parse_request((quest_t*)proc, &conn_s)){
	    WARNING("Parse Request Error");
	    return -1;
	}
	proc = &conn_s;
    }
    else{
        WARNING("WRONG OPTION");
	return -1;
    }
    while (patternlist[j] != NULL){
	rt = patternlist[j]->pinit();    
	if (rt != 0){
            WARNING("PROCESS pinit() ERROR %d",rt);
	    return -1;
	}
        j++;
    }
    processRule(REGION_PRE, proc, proc);
    return ((stat_t*)proc)->rtcode;
}

/*
#ifdef USETHREAD
#include <pthread.h>
static pthread_key_t process_key = 0;
#endif
*/
 
 /*
 *  get a line from a buffer, mark \0 when necessary
 *  buf: source buffer
 *  pos: point to the current postion
 *  len: total length of the buffer
 *  return a line start pointer.
 */
static char *buf_getline(char *buf, int *pos, int len)
{
    int i, last_pos = *pos;
    int is_line_end = 0;

    for(i = *pos; i < len; ++i)
    {
	if( ('\r' == buf[i])
		&& ((i + 1 < len) && ('\n' == buf[i+1])))
	{
		buf[i] = 0;
		++i;		
		buf[i] = 0;
		is_line_end = 1;
	}

	if('\n' == buf[i]){
		buf[i] = 0;
		is_line_end = 1;
	}
	
	if(is_line_end){
		*pos = i + 1;
		return (buf + last_pos);
	}
	
    }
    
    return NULL;
}

/*
 *  parse the first line of the http request
 *  return 0, if success
 */
static int parse_first_line(stat_t *conn, char *line)
{
    char *start, *end;
    
    start = line;
    
    end = strpbrk(start, LWS);
    if(end == NULL)
    {
        return -1;
    }
    *end = '\0';
    
    /* get uri */
    start = end + 1;
    start += strspn(start, LWS);
    end = strpbrk(start, LWS);
    if(end != NULL)
    {
        *end = '\0';
    }
    conn->uri = start;

    /* get version */
    if(end != NULL)
    {
        start = end + 1;
        start += strspn(start, LWS);
    }
    
    /* Check for HTTP/1.1 absolute URL. */
    if(strncasecmp(conn->uri, "http://", 7) == 0)
    {
        /* some users use it, although it is forbidden */
        /*
        if(conn->version == HTTP0_9 || conn->version == HTTP1_0)
        {
            httpd_send_err(conn, 400, "");
            return -1;
        }
        */
        conn->uri = strchr(conn->uri + 7, '/');
        if(conn->uri == NULL)
        {
            return -1;
        }
    }
    
    if(*(conn->uri) != '/')
    {
        return -1;
    }
    return 0;
}

inline void stat_init(stat_t *conn)
{
    conn->client_addr.s_addr = 0;
    conn->uri = NULL;
    conn->refer = NULL;
    conn->user_agent = NULL;
    conn->host = NULL;
    conn->accept_encoding = NULL;
    conn->cookie = NULL;
    conn->rtcode = 0;
}
/*
#ifdef USETHREAD
static void destroy_process(void *statdata)
{
    if (statdata != NULL){
	free(statdata);
	statdata = NULL;
    }
}
#endif
int parse_request_init()
{
#ifdef USETHREAD
    if ( pthread_key_create(&process_key, destroy_process) !=0 ){
            WARNING("Create process_key Error");
            return -1;
    }
#endif
    return 0;
}*/


/*
 *  parse the request, and fill in the connection structure 
 *  (learn from thttpd)
 *  return 0, if success
 */
int parse_request(quest_t *proc, stat_t *conn)
{
    int     idx = 0;
    char    *start;
    char    *end;
#ifdef USECLIENTIP
    struct in_addr transmit_addr;
#endif

    /* HTTP header structure is like this
     *
     *  GET<LWS><URI><LWS>HTTP/<1.0|1.1><CRLF>
     * <Headers> <Value>
     * <Headers> <Value>
     * ...
     * 
     *  <URI>=[http://<HOST>]/<filename>[?<args>&<args>...]
     */

    /* read first line */
/*
#ifdef USETHREAD
    char *buffer;
    buffer = (char*)pthread_getspecific(process_key);
    if (process_key == 0)
	return 0;
    if (buffer == NULL){
	buffer = (char*)malloc(BUFFERLENGTH*sizeof(char));
        if(buffer == NULL){
	    WARNING("Not Enough Memory, Can't Malloc");
	    return -1;
        }
        if(pthread_setspecific(process_key, (void *)buffer)){
	    WARNING("Can't set specific process_key");
            free(bufer);
            return -1;	    
	}
    }
#else
    static char buffer[BUFFERLENGTH];
#endif
*/
    
    stat_init(conn);
    conn->client_addr = proc->client_addr;
    start = buf_getline(proc->in_buffer, &idx, proc->length);

    if(start == NULL)
    {
	BWSDEBUG("START ERROR");
        return -1;
    }
    if(parse_first_line(conn, start))
    {
	BWSDEBUG("PARESE FIRST LINE ERROR");
        return -1;
    }
    /* read the MIME headers. */
    while((start = buf_getline(proc->in_buffer, &idx, proc->length)) != NULL)
    {				
        switch(start[0])
        {
        case 'R': 
        case 'r':
            if(strncasecmp(start, "Referer:", 8) == 0)
            {
                start += 8;
                start += strspn(start, " \t");
                conn->refer = start;
            }
            break;
        case 'U': 
        case 'u':
            if(strncasecmp(start, "User-Agent:", 11) == 0)
            {
                start += 11;
                start += strspn(start, " \t");
                conn->user_agent = start;
            }
            break;
        case 'H':
        case 'h':
            if(strncasecmp(start, "Host:", 5) == 0)
            {
                start += 5;
                start += strspn(start, " \t");
                conn->host = start;
                    
                end = strchr(conn->host, ':');
                if(end != NULL)
                {
                    *end = '\0';
                }
                if(strchr(conn->host, '/' ) != NULL || conn->host[0] == '.' )
                {
			BWSDEBUG("HOST ERROR");
                    return -1;
                }
            }
            break;
        case 'A':
        case 'a':
            if(strncasecmp(start, "Accept-Encoding:", 16) == 0)
            {
                start += 16;
                start += strspn(start, " \t");
                conn->accept_encoding = start;
            }
            break;
        case 'C':
        case 'c':
            if(strncasecmp(start, "Cookie:", 7) == 0)
            {
                start += 7;
                start += strspn(start, " \t");
                conn->cookie = start;
	    }
#ifdef USECLIENTIP
            else if(strncasecmp(start, "CLIENTIP:", 9) == 0)
            {
                start += 9;
                start += strspn(start, " \t");
                if(inet_aton(start, &transmit_addr) != 0)
                {
                    conn->client_addr = transmit_addr;
                }
            }
#endif
            break;
        default:
            break;
        }
    }
#ifdef USECLIENTIP
    BWSDEBUG("URI[%s], Refer[%s], User-Agent[%s], Host[%s], Accept-Encoding[%s], Cookie[%s], ClientIP[%u]", 
		    conn->uri, conn->refer, conn->user_agent, conn->host, conn->accept_encoding, conn->cookie, conn->client_addr.s_addr);
#else
    BWSDEBUG("URI[%s], Refer[%s], User-Agent[%s], Host[%s], Accept-Encoding[%s], Cookie[%s]", 
		    conn->uri, conn->refer, conn->user_agent, conn->host, conn->accept_encoding, conn->cookie);
#endif
    return 0;
}

