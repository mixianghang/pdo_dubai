#ifndef __FRAME_HEADER__
#define __FRAME_HEADER__
#include "region.h"
int load_policyframe_conf(const char *dir, const char *dtdname, const char *xmlname);
void processRule(REGION region,void *patterndata,void *actiondata);
//void processPreRuleLists(void *proc);
#endif
