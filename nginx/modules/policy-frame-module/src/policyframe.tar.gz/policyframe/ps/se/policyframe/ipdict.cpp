#include "policy.h"
#include "policyframe.h"
#include "frame_util.h"
#include <pcre.h>

#include <ul_net.h>
#include <ul_def.h>

static const char * patterntype = "IpDict";
static int ipdict_create(PatternMatchInterfacePtr pmi,xmlNodePtr pxmlnode);
static void ipdict_release(PatternMatchInterfacePtr parg);
static int ipdict_init();
PatternMatchResult ipdict_patternmatch(void *conn,void *arg,short *result);


PatternMatchFactory ipdict_factory={"IpDict",\
					REGION_PRE|REGION_HANDLE|REGION_UPSTREAM,\
    		       		        ipdict_create,\
	     			        ipdict_release,\
				        ipdict_init
};

typedef struct{
    unsigned int start_addr;
    unsigned int end_addr;
}IpItem;

typedef struct{
    IpItem *dict;
    int dict_max;
}dict_table;

int DICTMAX = 1024;

/*********************************************************************************
 *   Name     :  ip_sort_cmp
 *   Comment  :��start_addr ���дӴ�С����
 *   Create On: 2007-03-27 add by liulp for sort 
 *   Input    :  
 *   Output   : 
 *
 *********************************************************************************/
static int 
ip_sort_cmp(const  void * a,const void *b)
{
	IpItem * aa = (IpItem *)a;
	IpItem * bb = (IpItem *)b;
	if (aa->start_addr < bb->start_addr){
		return 1;
	}
	if (aa->start_addr >bb->start_addr){
		return -1;
	}
	return 0;
}
/*********************************************************************************
 *	 Name	  :  ����������ֲ��� ,�����������������������С�Ĵ�����
 *	 Comment  ://search 	a.	 ������ 
 *	 Input	  :  
 *	 Output   : 
 *
 *********************************************************************************/
static inline int
ip_bisearch_desc(IpItem * a, int lower, int upper, unsigned int t)
{
    if (upper - lower == 1 || (upper == 0 && lower == 0)) {
	 //t	 is between upper and lower
        if (a[lower].start_addr <= t)
            return lower;
        return upper;
    }
    // bigger is at front
    int mid = (lower + upper) / 2;
    if (a[mid].start_addr < t) {
	  // found first equal;
        return ip_bisearch_desc(a, lower, mid, t);
    }
    if (a[mid].start_addr > t){
    	return ip_bisearch_desc(a, mid, upper, t);
    }
    return mid;
}
/*********************************************************************************
 *   Name     :  seek_dict_entry
 *   Comment  :
 *   Create on : 
 *   Input    :  
 *   Output   : 
 *   Last Modified   :2007-03-27 add by liulp for sort 
 *********************************************************************************/

static int 
seek_dict_entry(IpItem *dict, int size, unsigned int addr)
{
	if ( size < 1) {
		return -1;
	}
	int mid = ip_bisearch_desc(dict,0,size-1,addr);
	if(addr>=dict[mid].start_addr && addr<=dict[mid].end_addr){
		return 0;
	}
      return -1;
}

static int insert_into_dict(IpItem *dict, int cur_size, IpItem addr)
{

    dict[cur_size] = addr;

    return 1;
}

static int load_dict(IpItem *dict, int size, char *file_name)
{
    int  ip_num = 0;
    int  ret_code;
    char *start;
    char line[255];
    char addr_str1[100];
    char addr_str2[100];
    char addr_str3[100];
    FILE *fp;
    struct in_addr start_addr;
    struct in_addr end_addr;
    IpItem addr_item;

    if(file_name[0] == '\0')
        return 0;

    if((fp=fopen(file_name, "rb")) == NULL) 
    {
	WARNING("OPEN FILE %s ERROR",file_name);
        return -1;
    }

    while(1)
    {
        if(fgets(line, sizeof(line), fp) == NULL)
            break;

        start = line;
        while(1)
        {
            if(*start!=' ' && *start!='\t')
                break;

            start++;
        }

        if(start[0]=='#' || start[0]=='\r' || start[0]=='\n') 
            continue;

        ret_code = sscanf(start, "%s %s %s", addr_str1, addr_str2, addr_str3);
        if(ret_code == 1)
            strcpy(addr_str2, addr_str1);
        else
            if(ret_code == 2)
            {
                if(inet_aton(addr_str2, &end_addr) == 0)
                    strcpy(addr_str2, addr_str1);
            }
            else
                if(ret_code == 3)
                {
                    strcpy(addr_str2, addr_str3);
                }

        ret_code = inet_aton(addr_str1, &start_addr);
        if(ret_code == 0) 
        {
            WARNING("load_dict: the format of start-IP is error, start-IP=%s", addr_str1);
            continue;
        }

        ret_code = inet_aton(addr_str2, &end_addr);
        if(ret_code == 0) 
        {
            WARNING("load_dict: the format of end-IP is error, end-IP=%s", addr_str2);
            continue;
        }

        if(ip_num >= size)
        {
            WARNING("load_dict: entry size exceeded");
            break;
        }
        addr_item.start_addr = ntohl(start_addr.s_addr);
        addr_item.end_addr = ntohl(end_addr.s_addr);
	  if (addr_item.start_addr >addr_item.end_addr){
	  	WARNING("load_dict: start_addr larger end_addr,ignore");
	  	continue;
	  }
        ip_num += insert_into_dict(dict, ip_num, addr_item);
    }

    fclose(fp);

	/*Begin : 2007-03-27 add by liulp for sort  */
	if (ip_num >0){
		// (�Ӵ�С)
		qsort(dict,ip_num,sizeof(IpItem),ip_sort_cmp);
	}
	/*End */
	/*check overlap*/
	if (ip_num<=0){
		return ip_num;
	}
	int merge_item_cnt = 0;
	for (int ii = 0; ii < ip_num - 1; ++ii) {
		if (dict[ii].end_addr == 0 || dict[ii].start_addr == 0) {
			continue;
		}
		for (int jj = ii + 1; jj < ip_num; ++jj) {
		        if (dict[jj].end_addr == 0 || dict[jj].start_addr == 0) {
		            continue;
		        }
		        if (dict[jj].end_addr >= dict[ii].start_addr) {
		            //change start
		            dict[ii].start_addr = dict[jj].start_addr;
		            // change end
		            if (dict[jj].end_addr >= dict[ii].end_addr) {
		                dict[ii].end_addr = dict[jj].end_addr;
		            }
		            dict[jj].start_addr = 0;
		            dict[jj].end_addr = 0;
		            merge_item_cnt++;
		            // merge item;
		            for (int kk = ii + 1; kk < jj; ++kk) {
		                if (dict[kk].end_addr == 0 || dict[kk].start_addr == 0) {
		                    continue;
		                }
		                dict[kk].start_addr = 0;
		                dict[kk].end_addr = 0;
		                merge_item_cnt++;
		            }
		        }
		 }
	}   
	if (ip_num >0 && merge_item_cnt>0){
		// (�Ӵ�С)
		qsort(dict,ip_num,sizeof(IpItem),ip_sort_cmp);
		ul_writelog(UL_LOG_WARNING,"ip overlap found,%s,orig=%d,merge=%d",file_name,ip_num,merge_item_cnt);
		ip_num-=merge_item_cnt;
	}	
	for (int ii = 0 ; ii < ip_num ; ++ii){
		ul_writelog(UL_LOG_NOTICE,"%s,%d,ip1=%u,ip2=%u",file_name,ii,dict[ii].start_addr,dict[ii].end_addr);
	}
    return ip_num;
}

static void *
get_specific_data(xmlNodePtr pxmlnode){
    char dict_filename[64];	
    int ret_code;
    dict_table *dt;
    xmlNodePtr pnode = pxmlnode->xmlChildrenNode;
    
    dt = (dict_table*)malloc(sizeof(dict_table));
    if (dt == NULL)
	goto error1;
    dt->dict_max = DICTMAX;
    dict_filename[0]=0;
    while (pnode){
    	if (pnode->type == XML_ELEMENT_NODE){
	   if (tagNameMatch(pnode,"DictFile") == 0){
  	       if (getcontent(pnode,dict_filename,sizeof(dict_filename)) < 0){
       		   goto error1;
  	       }
       	   }else if (tagNameMatch(pnode,"DictMax") == 0){
	       if (getcontentint(pnode,&dt->dict_max) < 0){
		   goto error1;
	       }
	   }
	}
	pnode = pnode->next;
    }	
   
    BWSDEBUG("DICT NAME: %s", dict_filename);

    if( dict_filename[0] == 0 ){
	WARNING("DICT: No Dict File Name");     
	goto error1;
    }
    dt->dict = (IpItem*)malloc(dt->dict_max * sizeof(IpItem));
    if (dt->dict == NULL){
	WARNING("DICT: Cann't Malloc Enough Memory for Dict");
	goto error1;
    }
    ret_code = load_dict(dt->dict, dt->dict_max, dict_filename);
    if (ret_code < 0){
        WARNING("DICT: Read INNOCENT FILE ERROR (%d)",ret_code);
	free(dt->dict);
	goto error1;
    }
    dt->dict_max = ret_code;
    return dt;
error1:
    return NULL;
}

static int
ipdict_create(PatternMatchInterfacePtr pmi,xmlNodePtr pxmlnode)
{
    /*
     * first we should use the PatternMatchInterface node  and assign the following element in the node
     *           0. patterntype
     *           1. patternname ( this come from the "define" attribute)  
     *           2. pmatch  (this is the specific fuction) 
     *           3. pfactory (this func pinter is used to release the resource assigned in this function )
     *              and we can just give it value "httpfilter_factory"
     * second we should create specific node for the pattern
     * 		 0. patterndata (this data is released by the pmatch
     */
    xmlChar * name;
    if (pmi == NULL) return -1;
        snprintf(pmi->patterntype,PATTERNTYPELEN,"%s",patterntype);
    pmi->pfactory = &ipdict_factory;
    pmi->pmatch = &ipdict_patternmatch;
    pmi->patterndata = get_specific_data(pxmlnode);
    pmi->region = ipdict_factory.region;
    if (pmi->patterndata == NULL)
	goto erro;

    name = xmlGetProp(pxmlnode, (const xmlChar*)"define");
    if (name == NULL){
	goto erro;
    }
    snprintf(pmi->patternname,PATTERNNAMELEN,"%s",name);
    xmlFree(name);
    return 0;
erro:
    return -1;
}

static void 
ipdict_release(PatternMatchInterfacePtr parg)
{
    /*
     * this function have just one task:
     * 1. it should release the resource in PatternMatchInterfacePtr::patterndata
     */
    /**the first task**/
    dict_table *dt = (dict_table*)parg->patterndata;
    if(dt->dict != NULL)
	free(dt->dict);
    return;
}
static int 
ipdict_init()
{
    return 0;
}
PatternMatchResult 
ipdict_patternmatch(void *conn,void*arg,short *result)
{
    stat_t * proc = (stat_t *)conn;
    unsigned int addr;
    addr = ntohl(proc->client_addr.s_addr);
    dict_table *dt = (dict_table*)arg;
    if (seek_dict_entry(dt->dict, dt->dict_max, addr) >=0){
   	BWSDEBUG("ipdict Matched[%u]!", addr); 
        return Match;
    }
    else{
        BWSDEBUG("ipdict not Matched[%u]!", addr);
	return NotMatch;
    }
}
