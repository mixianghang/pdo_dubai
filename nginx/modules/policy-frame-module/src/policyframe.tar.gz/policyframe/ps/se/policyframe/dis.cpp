#include "ul_exlink.h"
#include "dis.h"
//#define WARNING(fmt,...) printf("%s-%d:"fmt"\n",__FILE__,__LINE__,##__VA_ARGS__)
//#define BWSDEBUG WARNING

static 
int update_record(void *dest, int size, void *src)
{
	memcpy(dest, src, size);
	return 0;
}

mc_cache *
get_specific_distribute_data(xmlNodePtr pxmlnode, DistributeAttactConfPtr disconf_ptr, mc_cache *bigcache_ptr)
{    
    char buf[64];
    if (disconf_ptr == NULL) return NULL;
    disconf_ptr->cachenum           = -1;
    disconf_ptr->period             = -1;
    disconf_ptr->thredthold         = -1;
    disconf_ptr->badusernum         =  0;
    disconf_ptr->baduserperiod      = -1;
    disconf_ptr->badusertimestamp   =  time(NULL);
    disconf_ptr->laststatebaduser   = SAFE;
    disconf_ptr->baduserthreadthold = 0; 
    disconf_ptr->policytest         = POLICYTEST; //the default we test the policy
    disconf_ptr->statid             = 0;
    disconf_ptr->cache_ptr	    = NULL;
#ifdef USETHREAD
    BWSDEBUG("USE THREAD");
    pthread_mutex_init(&disconf_ptr->cache_mutex,NULL);
#else
    BWSDEBUG("DO NOT USE THREAD");
#endif
    xmlNodePtr pnode = pxmlnode->xmlChildrenNode; 
    while (pnode){
	if (pnode->type == XML_ELEMENT_NODE){
	   if (tagNameMatch(pnode,"CacheNum") == 0){
	       if (getcontentint(pnode,&disconf_ptr->cachenum) < 0){
		   goto err;
	       }
	   }else if (tagNameMatch(pnode,"TimePeriod") == 0){
	       if (getcontentint(pnode,&disconf_ptr->period) < 0){
		   goto err;
	       }
	   }else if (tagNameMatch(pnode,"Threshold") == 0){
	       if (getcontentint(pnode,&disconf_ptr->thredthold) < 0){
		   goto err;
	       }
	   }else if (tagNameMatch(pnode,"PolicyTest") == 0){
	       if (getcontent(pnode,buf,sizeof(buf)) < 0 ){
		   goto err;
	       }else{
		  if (strlen(buf) != 1 || (buf[0] != 'Y' && buf[0] != 'y'&& \
			  buf[0] != 'N' && buf[0] != 'n')){
		      WARNING("DIS: You give us a error PolicyTest[%s]",buf);
		      goto err;
		  }else if (buf[0] == 'Y' || buf[0] == 'y') {
		      disconf_ptr->policytest = POLICYTEST;
		  }else{
		      disconf_ptr->policytest = POLIOCYONLINE;
		  }
	       }
	   }else if (tagNameMatch(pnode,"BadUserNumThreshold") == 0){
	       if (getcontentint(pnode,&disconf_ptr->baduserthreadthold) < 0){
		   goto err;
	       }
	   }else if (tagNameMatch(pnode,"BadUserTimePeriod") == 0){
	       if (getcontentint(pnode,&disconf_ptr->baduserperiod) < 0){
		   goto err;
	       }
	   }else if (tagNameMatch(pnode,"StatID") == 0){                                               
	       if (getcontentint(pnode,&disconf_ptr->statid) < 0){                                         
	           goto err;                                                                                      
	       }else{
	          if(disconf_ptr->statid>255 || disconf_ptr->statid<0){
		      WARNING("DIS: You give the STATID not between 0-255");
		      goto err;
		  }
	       }
	   }
	   
	}
	pnode = pnode->next;
    }
    if (pnode != NULL || -1 == disconf_ptr->period || -1 == disconf_ptr->thredthold|| \
	    -1 == disconf_ptr->baduserperiod ){
	goto err;
    }
    if (bigcache_ptr != NULL){
        BWSDEBUG("MC_CACHE HAVE MALLOC ALREADY");
    }
    else if (-1 == disconf_ptr->cachenum){
	WARNING("NO CACHENUM");
        goto err;
    }
    else{
        bigcache_ptr = mc_creat_cache(disconf_ptr->cachenum,sizeof (UserVisit));
        if (bigcache_ptr == NULL){
            WARNING("DIS: Create mc cache error");
	    goto err;
	}
	BWSDEBUG("MC_CACHE MALLOC NOW");
    }
    disconf_ptr->cache_ptr = bigcache_ptr;
    return disconf_ptr->cache_ptr;
err: 
    return NULL;	
}
PatternMatchResult 
distribute_stat(void *conn,void *arg,short *result,unsigned int *count,unsigned int sign[2])
{
    char needstat = 'Y';
	
    //stat_t * proc = (stat_t *)conn;
    UserVisit old_uv;
    UserVisit new_uv;
    DistributeAttactConfPtr disconf_ptr = (DistributeAttactConfPtr) arg;

    if ( count[disconf_ptr->statid] == 0){
        count[disconf_ptr->statid] = 1;
	BWSDEBUG("NEW STAT %d",disconf_ptr->statid);
    }else{
	BWSDEBUG("HAVE STAT THE CACHE ALREADY");
        needstat = 'N';
    }

    time_t time_now = time(NULL);
    int ret_code;
    if (needstat == 'Y'){
	new_uv.count = 1;
    }
    else{
	new_uv.count = 0;
    }
    new_uv.time_stamp = time_now;
    new_uv.record  = DIS_NotRecord;
    new_uv.lastcount = 0;
#ifdef USETHREAD
    pthread_mutex_lock(&disconf_ptr->cache_mutex);
#endif
    ret_code = mc_seekitem(disconf_ptr->cache_ptr, sign, &old_uv,sizeof(UserVisit));
    bool baduser = false;
    if (ret_code == RT_NOTICE_NONE_PROCESSED){
	mc_additem(disconf_ptr->cache_ptr, sign, &new_uv, sizeof(UserVisit));
    }else if (ret_code == RT_NOTICE_PROCESSED){
	if ((time_now - old_uv.time_stamp) < disconf_ptr->period){
	    new_uv.time_stamp = old_uv.time_stamp;
	    new_uv.count += old_uv.count;
	    new_uv.record = old_uv.record;
	    new_uv.lastcount = old_uv.lastcount;
	//	BWSDEBUG("--------------WE ARE RECORD--------------------");
	}else{
	    new_uv.lastcount = old_uv.count;
	}
	baduser = new_uv.count > disconf_ptr->thredthold || new_uv.lastcount > disconf_ptr->thredthold;
	if ((time_now - disconf_ptr->badusertimestamp) < disconf_ptr->baduserperiod){
	    if (baduser && new_uv.record == DIS_NotRecord){//we have a bad user which we don't __record___
		disconf_ptr->badusernum ++; //we count all the bad user number
		new_uv.record = DIS_Record;  //we record this bad user 
	    }
	}else{
	    if (disconf_ptr->badusernum >= disconf_ptr->baduserthreadthold){
		disconf_ptr->laststatebaduser = DANGER; //we shuold set the last danger state!
	    }else{
		disconf_ptr->laststatebaduser = SAFE; 
	    }
	    disconf_ptr->badusertimestamp = time_now;
	    disconf_ptr->badusernum = 0;
	}
	if( needstat == 'Y'){
            mc_modifyitem(disconf_ptr->cache_ptr, sign, update_record, &new_uv);
	}    
    }else{
	WARNING("DIS: mc_cache seek error!:%d",ret_code);
    }
#ifdef USETHREAD
    pthread_mutex_unlock(&disconf_ptr->cache_mutex);
#endif
    BWSDEBUG("visit count=[%ld][%d]",time_now,new_uv.count);
    BWSDEBUG("Bad User Num=[%ld][%d]",time_now,disconf_ptr->badusernum);
    /*
     * 	 if we have BAIDUVERIFY cookie 
     * 	 then the user is verified
     */

    if (baduser && (disconf_ptr->laststatebaduser == DANGER || \
		disconf_ptr->badusernum > disconf_ptr->baduserthreadthold)){
	/*
	 * here we should set a temporary cookie(support p3p) for verify the user!
	 */
	if (disconf_ptr->policytest == POLICYTEST){
	    *result = RESULT_NOTMATCH;
	    WARNING("DIS: HAVE BAD USER NUM = [%d]",disconf_ptr->badusernum);
	    return NotMatch;
	}
	*result = RESULT_MATCH;
	return Match;
    }else{
	*result = RESULT_NOTMATCH;
	return NotMatch;
    }
}
