#ifndef __PRISON_HEADER__
#define __PRISON_HEADER__

#include "public.h"

enum Prison_type{
	PRISON_COOKIE = 0x1,
	PRISON_IP = 0x2,
	PRISON_CONN = 0x4,
	PRISON_SESSION = 0x8
};

const int PRISON_FILTER_NUM = 8;

struct Filters{
	struct{
		Prison_type type;
		unsigned int check_period;
		unsigned int stay_period;
		unsigned int threshold;
	}filter[PRISON_FILTER_NUM];
	
	int size;
};


/*
 *load configureation of prison
 */ 
int load_prison_conf(struct Filters * filter_ptr, bool all);

/*
 *do some initialization work.
 *note: it must called after load_prison_conf():
 */
int init_prison();

/*
 *each visit shoule be processd by this function
 *ret_code:
 *		 > 0 : prison type
 *		== 0 : not prison
 *       < 0 : some error happens 
 */
int record_user(
		struct Filters * filter_ptr,
		unsigned int * user_id,         /*signature of the user*/
		/*it may derive from ip or cookie, unsigned int[2] */
		const unsigned int type,        /*prison type, it can be mixed*/
		const unsigned int now          /*current time to process*/
		);

/*
 *when find the user is a prion, call the function
 */
int add_to_prison(
		unsigned int * user_id,         /*signature of the user*/
		/*it may derive from ip or cookie, unsigned int[2] */		
		const unsigned int prison_type, /*prison type, it can be mixed*/
		const unsigned int stay_period, /*period of being in prison*/
		const unsigned int now          /*current time to process*/
		);

bool should_deny(
		unsigned int * user_id,         /*signature of the user*/
		/*it may derive from ip or cookie, unsigned int[2] */
		const unsigned int prison_type, /*prison type, it can be mixed*/
		const unsigned int now          /*current time to process*/		
		);

inline char * get_prison_type(
		unsigned int prison_type, 
		char * str_ptr
		);

/*
 * clean all user record and prison dict cache
 */
void reset_prison_record();

#endif
