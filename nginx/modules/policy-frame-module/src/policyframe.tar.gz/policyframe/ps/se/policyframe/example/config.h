#include "public.h"

enum CONFIG_RET{
	CONFIG_FOUND = 2,
	CONFIG_DEFAULT = 1,
	CONFIG_ERROR = -1
};

/*
 * at most open ten files
 */ 
int add_config_data(char * config_path, char * config_file);

/*
 * free all open configuration files
 */ 
void free_config_data();

/*
 *  read int type from all open figuration files
 */
enum CONFIG_RET get_conf_int(char *name, int *pv, const int defaultv = 0);

/*
 *  read sting type from all open figuration files
 */
enum CONFIG_RET get_conf_str(char *name, char *pv, int pv_size, const char *defaultv = NULL);
