/*
 *  region
 *
 */
#ifndef __REGION__
#define __REGION__

typedef int REGION;
#define	REGION_NOTDEFINE 0
#define REGION_PRE	 0x00000001
#define REGION_HANDLE	 0x00000002
#define REGION_UPSTREAM	 0x00000004
#define REGION_PRE_STR	 "PRE"
#define REGION_HANDLER_STR	"HANDLER"
#define	REGION_UPSTREAM_STR	"UPSTREAM"
#define REGION_NOTKNOW_STR	"REGION_NOTKNOW"


inline const char * RegionName(REGION region)
{
    switch (region){
	case 0x00000001:return REGION_PRE_STR;
	case 0x00000002:return REGION_HANDLER_STR;
	case 0x00000004:return REGION_UPSTREAM_STR;
	default:return REGION_NOTKNOW_STR;
    }
}

#endif
