#include "dis.h"
#include "policyframe.h"
#include "frame_util.h"
#include "mc_type.h"
#include "mc_const.h"
#include "mc_cache.h"
#include <ul_def.h>
#include <pthread.h>
#include <ul_net.h>
#include <ul_sign.h>

#ifdef USETHREAD
#include <pthread.h>
#endif
//#define WARNING(fmt,...) printf("%s-%d:"fmt"\n",__FILE__,__LINE__,##__VA_ARGS__)
//#define BWSDEBUG WARNING

#ifdef USETHREAD
static pthread_key_t process_key = 0;
#else
static unsigned int bigidcount_ptr[256];
#endif
static mc_cache * bigcache_ptr;
static const char * patterntype = "DistributeAgentAttack";
static int distribute_agentattack_create(PatternMatchInterfacePtr pmi,xmlNodePtr pxmlnode);
static void distribute_agentattack_release(PatternMatchInterfacePtr parg);
static int distribute_agentattack_init();
PatternMatchResult distribute_agentattack_patternmatch(void *conn,void*arg,short* result);

PatternMatchFactory distribute_agentattack_factory={"DistributeAgentAttack",\
				       REGION_PRE,\
    		       		       distribute_agentattack_create,\
	     			       distribute_agentattack_release,\
				       distribute_agentattack_init
};

#ifdef USETHREAD
static void destroy_process(void *statdata)
{
    if (statdata != NULL){
        free(statdata);
	statdata = NULL;
    }
}
#endif
static void *
get_specific_data(xmlNodePtr pxmlnode)
{
    DistributeAttactConfPtr disconf_ptr = (DistributeAttactConfPtr)malloc(sizeof(DistributeAttactConf));
    if (disconf_ptr == NULL)
    {
        WARNING("Malloc DistributeAttactConf error");
	goto err1;
    }
/*    if (bigcache_ptr == NULL)
    {
        bigcache_ptr = mc_creat_cache(disconf_ptr->cachenum,sizeof (UserVisit));
        if (bigcache_ptr == NULL){
	    WARNING("DistributeIPattack: Create mc cache error");
	    goto err1;
    	}
    }*/
#ifdef USETHREAD
    if ( pthread_key_create(&process_key, destroy_process) !=0 ){
        WARNING("Create process_key Error");
        goto err1;
    }
#endif
    BWSDEBUG("GET_SPECIFIC_DATA");
    bigcache_ptr = get_specific_distribute_data(pxmlnode, disconf_ptr, bigcache_ptr);
    if (bigcache_ptr == NULL)
    {
	WARNING("get_specific_distribute_data return error");
	goto err1;
    }
    return disconf_ptr;
err1:
    if (disconf_ptr == NULL){
        free(disconf_ptr);
	disconf_ptr = NULL;
    }
    return NULL;
}
static int 
distribute_agentattack_create(PatternMatchInterfacePtr pmi,xmlNodePtr pxmlnode)
{
    /*
     * first we should use the PatternMatchInterface node  and assign the following element in the node
     *           0. patterntype
     *           1. patternname ( this come from the "define" attribute)  
     *           2. pmatch  (this is the specific fuction) 
     *           3. pfactory (this func pinter is used to release the resource assigned in this function )
     *              and we can just give it value "distributeattack_factory"
     * second we should create specific node for the pattern
     * 		 0. patterndata (this data is released by the pmatch
     */
    xmlChar * name;
    snprintf(pmi->patterntype,PATTERNTYPELEN,"%s",patterntype);
    pmi->pfactory = &distribute_agentattack_factory;
    pmi->pmatch = &distribute_agentattack_patternmatch;
    pmi->patterndata = get_specific_data(pxmlnode);
    pmi->region = distribute_agentattack_factory.region;
    if (pmi->patterndata == NULL)
	goto erro;
    name = xmlGetProp(pxmlnode, (const xmlChar*)"define");
    if (name == NULL){
	goto erro;
    }
    snprintf(pmi->patternname,PATTERNNAMELEN,"%s",name);
    xmlFree(name);
    return 0;
erro:
    return -1;
}
static int
distribute_agentattack_init()
{
#ifdef USETHREAD
    unsigned int *bigstatidcount_ptr;
    bigstatidcount_ptr = (unsigned int*)pthread_getspecific(process_key);
    if (process_key == 0)
	return 0;
    if (bigstatidcount_ptr == NULL){
        bigstatidcount_ptr = (unsigned int*)malloc(256*sizeof(unsigned int));
        if(bigstatidcount_ptr == NULL){
	    WARNING("Not Enough Memory, Can't Malloc");
	    goto erro2;
        }
        if(pthread_setspecific(process_key, (void *)bigstatidcount_ptr)){
	    WARNING("Can't set specific process_key");
	    goto erro2;
        }
    }
    memset(bigstatidcount_ptr, 0, 256*sizeof(unsigned int));
    return 0;
erro2:
    if (bigstatidcount_ptr == NULL){
        free(bigstatidcount_ptr);
        bigstatidcount_ptr = NULL;   
    }
    return -1;
#else
    memset(bigidcount_ptr, 0, 256*sizeof(unsigned int));
    return 0;
#endif
}
static void 
distribute_agentattack_release(PatternMatchInterfacePtr parg)
{
    /*
     * this function have just one task:
     * 1. it should release the resource in PatternMatchInterfacePtr::patterndata
     */
    /**the task**/
    DistributeAttactConfPtr disconf_ptr = (DistributeAttactConfPtr)parg->patterndata;
    if (disconf_ptr != NULL){
	free(disconf_ptr);
	parg->patterndata = NULL;
    }
    if (bigcache_ptr != NULL){
        free(bigcache_ptr);
	bigcache_ptr = NULL;
    }
    /**the second task**/
//    RELEASE_PATTERN_MATCH_INTERFACE(parg);
    return;
}
PatternMatchResult 
distribute_agentattack_patternmatch(void *conn,void *arg,short *result)
{
    stat_t * proc = (stat_t *)conn;
    unsigned int sign[2], *count;
    DistributeAttactConfPtr disconf_ptr = (DistributeAttactConfPtr) arg;
    
    const char *agent  = (proc->user_agent==NULL)?"":proc->user_agent;
    creat_sign_f64((char*)agent, strlen(agent), &sign[0], &sign[1]);
    sign[1] = (sign[1]&0xFFFFFF00)|disconf_ptr->statid;
#ifdef USETHREAD
    count = (unsigned int*)pthread_getspecific(process_key);
    if (count == NULL){
        return NotMatch;
    }
#else
    count = bigidcount_ptr;
#endif
    return distribute_stat(conn, arg, result, count, sign);    
}
