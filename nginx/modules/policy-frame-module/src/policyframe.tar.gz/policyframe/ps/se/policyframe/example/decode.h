#ifndef __DES_DECODE_HEADER__
#define __DES_DECODE_HEADER__

#include "public.h"

/* init DES code & decode */
int init_decode(char * pDesKey);

/* test if the cookie is made by baidu */
bool is_valid_cookie(char * pCookie);

#endif
