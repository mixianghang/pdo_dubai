#ifndef __FRAME_POLICY__
#define __FRAME_POLICY__
#include <libxml/parser.h>
#include <string.h>
#include "region.h"
#define POLICY_RESULT_NUM 64
#define NOTPROCESS 0
#define RESULT_MATCH 1
#define RESULT_NOTMATCH 2



enum PatternMatchResult{Match,NotMatch};
typedef PatternMatchResult(*PatternMatch)(void *conn,void*arg,short* result);
typedef int (*Action)(void *conn,void *arg);
#define PATTERNTYPELEN 128
#define PATTERNNAMELEN 128
#define ACTIONNAMELEN  128
enum ListType{DEFINE_LIST = 0,\
    		NOTDEFINE_LIST,\
		  LIST_NUM};
typedef struct _PatternMatchInterface PatternMatchInterface;
typedef PatternMatchInterface* PatternMatchInterfacePtr;
struct _PatternMatchInterface{
    char patterntype[PATTERNTYPELEN];
    char patternname[PATTERNNAMELEN];
    enum ListType listype;
    int  listoffset;
    void *patterndata;
    REGION region;
    PatternMatch pmatch;
    struct _PatternMatchFactory * pfactory;
};

/*
 * 0  sucess create a patternmatchinterface
 * -1 some error!
 */
typedef int (*PatternCreate)  (PatternMatchInterfacePtr pmi,xmlNodePtr pxmlnode);
typedef void (*PatternRelease) (PatternMatchInterfacePtr parg); 
typedef int (*PatternInit) ();
typedef struct _PatternMatchFactory PatternMatchFactory;
typedef PatternMatchFactory *PatternMatchFactoryPtr;
struct _PatternMatchFactory{
    char patterntype[PATTERNTYPELEN];
    REGION region;
    PatternCreate pcreate;
    PatternRelease prelease;
    PatternInit pinit;
};
typedef struct _ActionInterface ActionInterface;
typedef ActionInterface* ActionInterfacePtr;
struct _ActionInterface{
    void *actiondata;
    REGION region;
    Action action;
    struct _ActionFactory *pfactory;
};
// fix me: we should pass ActionInterface to the _ActionCreate_ function. 
// you can see the PatternCreate.
// do this because the resource how to free!!!
typedef int (*ActionCreate) (ActionInterfacePtr aip,xmlNodePtr pxmlnode);
typedef void (*ActionRelease)(ActionInterfacePtr parg);
typedef struct _ActionFactory  ActionFactory;    
typedef ActionFactory * ActionFactoryPtr;
struct _ActionFactory {
    char actionname[ACTIONNAMELEN];
    REGION region;
    ActionCreate pcreate;
    ActionRelease prelease; 
};

enum RuleNodeType {Normal,And,Or};
typedef struct _RuleNode RuleNode;
typedef RuleNode* RuleNodePtr;
struct _RuleNode{
    RuleNodeType nodetype;
    PatternMatchInterfacePtr ppmatch_interface;
    struct _RuleNode * next; //sub level
    struct _RuleNode * link; //same level
};
#define RULETYPE_LEN 128
typedef struct _Rule Rule;
typedef Rule* RulePtr;
struct _Rule{
	RuleNode RuleListHead;
	ActionInterfacePtr action;
	int skip; // skip how many number 
	REGION	region;
	char RuleType[RULETYPE_LEN];
};


void inline initRuleNode(RuleNodePtr prulenode)
{
    prulenode->link = NULL;
    prulenode->next = NULL;
    prulenode->nodetype = And;
    prulenode->ppmatch_interface = NULL;
}
void inline initRule(RulePtr prule){
	initRuleNode(&prule->RuleListHead);
	prule->action = NULL;
	prule->skip = 0;
	memset(prule->RuleType,0,sizeof prule->RuleType);
	prule->region = REGION_NOTDEFINE;
}

void inline setRuleRegion(RulePtr prule,const char *name)
{
    if (name == NULL){
	prule->region = REGION_NOTDEFINE;
    }else if( strncmp(name,REGION_PRE_STR,strlen(REGION_PRE_STR)) == 0){
	prule->region = REGION_PRE;
    }else if (strncmp(name,REGION_HANDLER_STR,strlen(REGION_HANDLER_STR)) == 0){
	prule->region = REGION_HANDLE;
    }else if (strncmp(name,REGION_UPSTREAM_STR,strlen(REGION_UPSTREAM_STR)) == 0){
	prule->region = REGION_UPSTREAM;
    }else{
	prule->region = REGION_NOTDEFINE;
    }	
}
#define NEW_INIT_RULE_NODE(p) do{\
   p = (RuleNodePtr) malloc (sizeof(RuleNode));\
   if (p != NULL) initRuleNode(p);\
}while(0)
#define NEW_ACTION_INTERFACE(p) do{\
    p = (ActionInterfacePtr)malloc(sizeof (ActionInterface));\
    if (p!= NULL) memset(p,0,sizeof(ActionInterface));\
}while(0)
#define RELEASE_ACTION_INTERFACE(p) do{\
    if (p != NULL){\
	free(p);\
	p = NULL;\
    }\
}while(0)
#define NEW_PATTERN_MATCH_INTERFACE(p) do {\
    p = (PatternMatchInterfacePtr)malloc (sizeof(PatternMatchInterface));\
    if (p != NULL) memset(p,0,sizeof(PatternMatchInterface));\
}while(0)

#define RELEASE_PATTERN_MATCH_INTERFACE(p) do {\
    if (p != NULL) {\
	free(p);\
	p = NULL;\
    }\
}while(0)

#endif
