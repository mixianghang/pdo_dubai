#include "prison.h"
#include "config.h"

const int DEFAULT_USER_DICT_SIZE = 60000;
const int DEFAULT_PRISON_DICT_SIZE = 2000;

typedef struct{
	unsigned int count[PRISON_FILTER_NUM];
	unsigned int start_time[PRISON_FILTER_NUM];
}User;

typedef struct{
	struct{
		unsigned int free_time;
		Prison_type type;
	}free_type[PRISON_FILTER_NUM];

	unsigned int size;
}Prisoner;

static struct Dict{
	mc_cache * cache_ptr;
	int size;
}g_user_dict, g_prison_dict;


const char  prison_conn_str[] = "PRISON_CONN ";
const char  prison_ip_str[] = "PRISON_IP " ;
const char  prison_cookie_str[] = "PRISON_COOKIE ";
const char  prison_session_str[] = "PRISON_SESSION ";
inline char * get_prison_type(unsigned int prison_type, char * str_ptr)
{
	if(NULL == str_ptr){
		return NULL;
	}

	str_ptr[0] = '\0';

	if(PRISON_CONN & prison_type){
		strncat(str_ptr, prison_conn_str, sizeof(prison_conn_str) - 1);
	}

	if(PRISON_IP & prison_type){
		strncat(str_ptr, prison_ip_str, sizeof(prison_ip_str) - 1);
	}

	if(PRISON_COOKIE & prison_type){
		strncat(str_ptr, prison_cookie_str, sizeof(prison_cookie_str) - 1);
	}

	if(PRISON_SESSION & prison_type){
		strncat(str_ptr, prison_session_str, sizeof(prison_session_str) - 1);
	}

	return str_ptr;
}

static int load_filter_conf(struct Filters * filter_ptr, char * prefix_ptr, Prison_type type)
{
	if((NULL == prefix_ptr) || (NULL == filter_ptr)){
		return -1;
	}

	int conf_cprd_val = 0;
	char conf_cprd_name[256];
	int conf_sprd_val = 0;
	char conf_sprd_name[256];
	int conf_trd_val = 0;
	char conf_trd_name[256];	
	int conf_cnt = 0;

	for(conf_cnt = 0; ; ++conf_cnt){
		snprintf(conf_cprd_name, sizeof(conf_cprd_name), "%s_CHECK_PERIOD_%d", prefix_ptr, conf_cnt);
		snprintf(conf_sprd_name, sizeof(conf_sprd_name), "%s_STAY_PERIOD_%d", prefix_ptr, conf_cnt);
		snprintf(conf_trd_name, sizeof(conf_trd_name), "%s_THRESHOLD_%d", prefix_ptr, conf_cnt);

		if((CONFIG_FOUND != get_conf_int(conf_trd_name, &conf_trd_val))
				|| (CONFIG_FOUND != get_conf_int(conf_cprd_name, &conf_cprd_val))
				|| (CONFIG_FOUND != get_conf_int(conf_sprd_name, &conf_sprd_val))){
			break;
		}

		if(filter_ptr->size + 1 <= PRISON_FILTER_NUM){

			filter_ptr->filter[filter_ptr->size].check_period = (unsigned int)conf_cprd_val;
			filter_ptr->filter[filter_ptr->size].stay_period = (unsigned int)conf_sprd_val;
			filter_ptr->filter[filter_ptr->size].threshold = (unsigned int)conf_trd_val;
			filter_ptr->filter[filter_ptr->size].type = type;		
			filter_ptr->size += 1;
			
		}else{
			ul_writelog(UL_LOG_DEBUG, "too many filters in configuration %s, maximum filter num=%d", 
					prefix_ptr, PRISON_FILTER_NUM);
			return -1;
		}
	}

	return 0;	
}

int load_prison_conf(struct Filters * filter_ptr, bool all)
{
	if(NULL == filter_ptr){
		return -1;
	}
	
	bzero(filter_ptr, sizeof(struct Filters));

	if(0 > load_filter_conf(filter_ptr, "CONN", PRISON_CONN)){
		return -1;
	}

	if(0 > load_filter_conf(filter_ptr, "IP", PRISON_IP)){
		return -1;
	}

	if(0 > load_filter_conf(filter_ptr, "COOKIE", PRISON_COOKIE)){
		return -1;
	}

	if(0 > load_filter_conf(filter_ptr, "SESSION", PRISON_SESSION)){
		return -1;
	}

	if(all){
		bzero(&g_user_dict, sizeof(struct Dict));
		bzero(&g_prison_dict, sizeof(struct Dict));
		get_conf_int("USER_DICT_SIZE", &(g_user_dict.size), DEFAULT_USER_DICT_SIZE);
		get_conf_int("PRISON_DICT_SIZE", &(g_prison_dict.size), DEFAULT_PRISON_DICT_SIZE);
	}

	return 0;

}

int init_prison()
{
	if(NULL == (g_user_dict.cache_ptr = mc_creat_cache(g_user_dict.size, sizeof(User)))){
		ul_writelog(UL_LOG_DEBUG, "Failed to allcate memory for user dict");	
		return -1;
	}

	if(NULL == (g_prison_dict.cache_ptr = mc_creat_cache(g_prison_dict.size, sizeof(Prisoner)))){
		ul_writelog(UL_LOG_DEBUG, "Failed to allcate memory for prison dict");
		return -1;
	}			

	return 0;
}

static int update_item(void *dest, int size, void *src)
{
	memcpy(dest, src, size);
	return 0;
}

void reset_prison_record()
{
	if(NULL != g_user_dict.cache_ptr){
		ul_writelog(UL_LOG_DEBUG, "clean user cache");
		mc_clean_cache(g_user_dict.cache_ptr);
	}
}

int record_user(struct Filters * filter_ptr, unsigned int * user_id, const unsigned int type, const unsigned int now)
{
	if(NULL == user_id || NULL == filter_ptr){
		return -1;
	}

	User user;
	const int ret_code = mc_seekitem(g_user_dict.cache_ptr, user_id, &user, sizeof(User));
	if(RT_ERROR_GENERAL_ERROR == ret_code){
		ul_writelog(UL_LOG_FATAL, "%s %d record_user: mc_seekitem() error", __FILE__, __LINE__);
		return -1;
	}else if(RT_NOTICE_NONE_PROCESSED == ret_code){
		bzero(&user, sizeof(user));
	}
	
	int prison_type = 0;
	for(int turn = 0; turn < filter_ptr->size; ++turn){

		if(type & filter_ptr->filter[turn].type){

			user.count[turn] += 1;

			if(now - user.start_time[turn] >= filter_ptr->filter[turn].check_period){
				user.count[turn] = 1;
			}else if(user.count[turn] > filter_ptr->filter[turn].threshold){
				user.count[turn] = 1;
				prison_type |= filter_ptr->filter[turn].type;
				add_to_prison(user_id, filter_ptr->filter[turn].type, filter_ptr->filter[turn].stay_period, now);			
			}

			if(1 == user.count[turn]){
				user.start_time[turn] = now;
			}
		}

		char pt[256];
		char pt_2[256];
		ul_writelog(UL_LOG_DEBUG, "VISIT %d cnt=%u now=%u type=%s thrd=%d in_type=%s", 
				turn, user.count[turn], now, get_prison_type(filter_ptr->filter[turn].type, pt), 
				filter_ptr->filter[turn].threshold, get_prison_type(type, pt_2));

	}	

	if(RT_NOTICE_NONE_PROCESSED == ret_code){
		mc_additem(g_user_dict.cache_ptr, user_id, &user, sizeof(User));
	}else{
		mc_modifyitem(g_user_dict.cache_ptr, user_id, update_item, &user);
	}

	ul_writelog(UL_LOG_DEBUG, "record user return %d", prison_type);

	return prison_type;		
}

static inline void reset_prisoner(Prisoner * prisoner_ptr)
{
	if(NULL == prisoner_ptr){
		return;
	}
	bzero(prisoner_ptr, sizeof(Prisoner));

	prisoner_ptr->size = 4;
	prisoner_ptr->free_type[0].type = PRISON_IP;
	prisoner_ptr->free_type[1].type = PRISON_CONN;
	prisoner_ptr->free_type[2].type = PRISON_COOKIE;
	prisoner_ptr->free_type[3].type = PRISON_SESSION;

}

int add_to_prison(unsigned int * user_id, unsigned int prison_type, unsigned int stay_period, unsigned int now)
{
	Prisoner prisoner;
	const int ret_code = mc_seekitem(g_prison_dict.cache_ptr, user_id, &prisoner, sizeof(Prisoner));
	if(RT_ERROR_GENERAL_ERROR == ret_code){
		ul_writelog(UL_LOG_FATAL, "%s %d add_to_prison: mc_seekitem() error", __FILE__, __LINE__);
		return -1;
	}else if(RT_NOTICE_NONE_PROCESSED == ret_code){
		reset_prisoner(&prisoner);
	}

	for(size_t turn = 0; turn < prisoner.size; ++turn){
		if((prison_type & prisoner.free_type[turn].type)
				&& (prisoner.free_type[turn].free_time < (now + stay_period))){
			prisoner.free_type[turn].free_time = now + stay_period;
		}
	}

	if(RT_NOTICE_NONE_PROCESSED == ret_code){
		mc_additem(g_prison_dict.cache_ptr, user_id, &prisoner, sizeof(Prisoner));
	}else{
		mc_modifyitem(g_prison_dict.cache_ptr, user_id, update_item, &prisoner);
	}

	char pt[256];
	ul_writelog(UL_LOG_DEBUG, "add to prison, type=%s stay_period=%u now=%u", 
			get_prison_type(prison_type, pt), stay_period, now);

	return 0;	
}

bool should_deny(unsigned int * user_id, const unsigned int prison_type, const unsigned int now)
{
	Prisoner prisoner;
	const int ret_code = mc_seekitem(g_prison_dict.cache_ptr, user_id, &prisoner, sizeof(Prisoner));
	if(RT_ERROR_GENERAL_ERROR == ret_code){
		ul_writelog(UL_LOG_FATAL, "%s %d add_to_prison: mc_seekitem() error", __FILE__, __LINE__);
		return false;
	}else if(RT_NOTICE_NONE_PROCESSED == ret_code){
		return false;
	}

	bool is_invalid_item = true;
	bool is_in_prison = false;
	char pt_1[256];
	char pt_2[256];

	for(size_t turn = 0; turn < prisoner.size; ++turn){
		ul_writelog(UL_LOG_DEBUG, "should_deny: %d free_time=%d, now=%d, in_type=%s check_type=%s ", 
				turn, prisoner.free_type[turn].free_time, now, 
				get_prison_type(prison_type, pt_1), 
				get_prison_type(prisoner.free_type[turn].type, pt_2));

		if(now < prisoner.free_type[turn].free_time){
			is_invalid_item = false;			
		}

		if( (prison_type & prisoner.free_type[turn].type)
				&& (now < prisoner.free_type[turn].free_time) ){
			is_in_prison = true;
		}		
	}

	if(is_invalid_item){
		mc_removeitem(g_prison_dict.cache_ptr, user_id);
	}

	if(is_in_prison){
		ul_writelog(UL_LOG_DEBUG, "should_deny: OK");
	}else{
		ul_writelog(UL_LOG_DEBUG, "should_deny: NO");
	}

	return is_in_prison;
}
