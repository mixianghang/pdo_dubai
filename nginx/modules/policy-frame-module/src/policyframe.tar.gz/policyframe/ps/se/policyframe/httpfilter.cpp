#include "policyframe.h"
#include "policy.h"
#include <pcre.h>

#include <ul_net.h>
#include <ul_def.h>

static const char * patterntype = "HttpFilter";
static int httpfilter_create(PatternMatchInterfacePtr pmi,xmlNodePtr pxmlnode);
static void httpfilter_release(PatternMatchInterfacePtr parg);
static int httpfilter_init();
PatternMatchResult httpfilter_patternmatch(void *conn,void*arg,short *result);


PatternMatchFactory httpfilter_factory={"HttpFilter",\
					REGION_PRE|REGION_HANDLE|REGION_UPSTREAM,\
					httpfilter_create,\
	     			       	httpfilter_release,\
				       	httpfilter_init
};
#define FREE_SOME_RES(ptr) do{\
    if (ptr != NULL){\
	free(ptr);\
    }\
}while(0)

enum HttpAttribute{HTTP_MATCH=0,HTTP_NOT_MATCH,HTTP_NOTSET};

typedef struct _HttpFilterDefine{
    pcre *uri;
    pcre *agent;
    pcre *cookie;
    pcre *encode;
    pcre *host;
    pcre *refer;
    char *uri_c;
    char *agent_c;
    char *cookie_c;
    char *encode_c;
    char *host_c;
    char *refer_c;
    HttpAttribute uri_match;
    HttpAttribute agent_match;
    HttpAttribute cookie_match;
    HttpAttribute encode_match;
    HttpAttribute host_match;
    HttpAttribute refer_match;
    HttpAttribute uri_c_match;
    HttpAttribute agent_c_match;
    HttpAttribute cookie_c_match;
    HttpAttribute encode_c_match;
    HttpAttribute host_c_match;
    HttpAttribute refer_c_match;
} HttpFilter;

typedef HttpFilter* HttpFilterPtr;
static inline void
freeallpcre(HttpFilterPtr hf_ptr)
{
    	if (hf_ptr == NULL)
	    return;
	FREE_SOME_RES(hf_ptr->agent);
	FREE_SOME_RES(hf_ptr->cookie);
	FREE_SOME_RES(hf_ptr->encode);
	FREE_SOME_RES(hf_ptr->host);
	FREE_SOME_RES(hf_ptr->refer);
	FREE_SOME_RES(hf_ptr->uri);

}
static inline void
freeallstring(HttpFilterPtr hf_ptr)
{
    	if (hf_ptr == NULL)
	    return;
	FREE_SOME_RES(hf_ptr->agent_c);
	FREE_SOME_RES(hf_ptr->cookie_c);
	FREE_SOME_RES(hf_ptr->encode_c);
	FREE_SOME_RES(hf_ptr->host_c);
	FREE_SOME_RES(hf_ptr->refer_c);
	FREE_SOME_RES(hf_ptr->uri_c);

}
static inline void
init_httpfilter(HttpFilterPtr fp)
{
    fp->uri = NULL;
    fp->agent = NULL;
    fp->cookie = NULL;
    fp->encode = NULL;
    fp->host  = NULL;
    fp->refer = NULL;
    fp->uri_c = NULL;
    fp->agent_c = NULL;
    fp->cookie_c = NULL;
    fp->encode_c = NULL;
    fp->host_c  = NULL;
    fp->refer_c = NULL;
}
inline static pcre *
buildpcre(xmlNodePtr pnode, HttpAttribute *match)
{
    const char *error;
    int erroffset;
    int pcreoption = 0;
    char pattern[1024];
    pcre *re = NULL;
    if (getattributevalue(pnode,"match",pattern,sizeof pattern) == 0){
	*match = HTTP_MATCH;
    }else if (getattributevalue(pnode,"notmatch",pattern,sizeof pattern) == 0){
    	*match = HTTP_NOT_MATCH;
    }else if (getattributevalue(pnode,"matchnc",pattern,sizeof pattern) == 0){
        *match = HTTP_MATCH;
        pcreoption = PCRE_CASELESS;
    }else if (getattributevalue(pnode,"notmatchnc",pattern,sizeof pattern) == 0){
        *match = HTTP_NOT_MATCH;
        pcreoption = PCRE_CASELESS;
    }else{
	WARNING("HTTPFILTER : get httpfilter attribute erro");
	return NULL;
    }
    BWSDEBUG("VALUE[%s]",pattern);
    re = pcre_compile(
	    pattern, /* the pattern */
	    pcreoption, /* default options */
	    &error, /* for error message */
	    &erroffset, /* for error offset */
	    NULL); /* use default character tables */

    if (NULL == re){
	WARNING("HTTPFILTER : The pcre error[%s]:%s",pattern,(error!=NULL)?error:"");
	return NULL;
    }
    return re;

}
inline static char *
buildstring(xmlNodePtr pnode, HttpAttribute *match)
{
    char *pattern;
    pattern = (char*)malloc(sizeof(char)*1024);
    if (NULL == pattern){
	WARNING("NOT Enough Memory");
    	return NULL;
    }
    
    if (getattributevalue(pnode,"match",pattern,1024) == 0){
	*match = HTTP_MATCH;
    }else if (getattributevalue(pnode,"notmatch",pattern,1024) == 0){
    	*match = HTTP_NOT_MATCH;
    }else{
	WARNING("HTTPFILTER : get httpfilter attribute erro");
	return NULL;
    }
    BWSDEBUG("VALUE[%s]",pattern);
    return pattern;
}
static void *
get_specific_data(xmlNodePtr pxmlnode){
    HttpFilterPtr httpfilter = (HttpFilterPtr)malloc(sizeof (HttpFilter));
    if (httpfilter == NULL)
	return NULL;
    init_httpfilter(httpfilter);
    xmlNodePtr pnode = pxmlnode->xmlChildrenNode;
    while(pnode != NULL){
	if (pnode->type == XML_ELEMENT_NODE){
		if (tagNameMatch(pnode,"HTTP_AGENT") == 0){
		    FREE_SOME_RES(httpfilter->agent);
		    httpfilter->agent = NULL;
		    if ((httpfilter->agent = buildpcre(pnode, &httpfilter->agent_match)) == NULL){
			WARNING("HTTPFILTER: build AGENT pcre erro");
			break;
		    }
		}else if (tagNameMatch(pnode,"HTTP_REFER") == 0){
		    FREE_SOME_RES(httpfilter->refer);
		    httpfilter->refer = NULL;
		    if ((httpfilter->refer = buildpcre(pnode, &httpfilter->refer_match)) == NULL){
			WARNING("HTTPFILTER: build refer pcre erro");
			break;
		    }
		}else if (tagNameMatch(pnode,"HTTP_COOKIE") == 0){
		    FREE_SOME_RES(httpfilter->cookie);
		    httpfilter->cookie = NULL;
		    if ((httpfilter->cookie = buildpcre(pnode, &httpfilter->cookie_match)) == NULL){
			WARNING("HTTPFILTER: build cookie pcre erro");
			break;
		    }
		}else if (tagNameMatch(pnode,"HTTP_HOST") == 0){
		    FREE_SOME_RES(httpfilter->host);
		    httpfilter->host = NULL;
  		    if ((httpfilter->host = buildpcre(pnode, &httpfilter->host_match)) == NULL){
			WARNING("HTTPFILTER: build host pcre erro");
			break;
		    }
		}else if (tagNameMatch(pnode,"HTTP_ENCODE") == 0){
		    FREE_SOME_RES(httpfilter->encode);
	    	    httpfilter->encode = NULL;
	    	    if ((httpfilter->encode = buildpcre(pnode, &httpfilter->encode_match)) == NULL){
			WARNING("HTTPFILTER: build encod pcre erro");
			break;
		    }
		}else if (tagNameMatch(pnode,"HTTP_URI") == 0){
		    FREE_SOME_RES(httpfilter->uri);
		    httpfilter->uri = NULL;
	    	    if ((httpfilter->uri = buildpcre(pnode, &httpfilter->uri_match)) == NULL){
			WARNING("HTTPFILTER: build uri pcre erro");
			break;
		    }
		}else if (tagNameMatch(pnode,"HTTP_AGENT_C") == 0){
		    FREE_SOME_RES(httpfilter->agent_c);
		    httpfilter->agent_c = NULL;
		    if ((httpfilter->agent_c = buildstring(pnode, &httpfilter->agent_c_match)) == NULL){
			WARNING("HTTPFILTER: build agent string erro");
			break;
		    }
		}else if (tagNameMatch(pnode,"HTTP_REFER_C") == 0){
		    FREE_SOME_RES(httpfilter->refer_c);
		    httpfilter->refer_c = NULL;
		    if ((httpfilter->refer_c = buildstring(pnode, &httpfilter->refer_c_match)) == NULL){
			WARNING("HTTPFILTER: build refer string erro");
			break;
		    }
		}else if (tagNameMatch(pnode,"HTTP_COOKIE_C") == 0){
		    FREE_SOME_RES(httpfilter->cookie_c);
		    httpfilter->cookie_c = NULL;
		    if ((httpfilter->cookie_c = buildstring(pnode, &httpfilter->cookie_c_match)) == NULL){
		        WARNING("HTTPFILTER: build cookie string erro");
			break;
		    }
		}else if (tagNameMatch(pnode,"HTTP_HOST_C") == 0){
		    FREE_SOME_RES(httpfilter->host_c);
		    httpfilter->host_c = NULL;
	    	    if ((httpfilter->host_c = buildstring(pnode, &httpfilter->host_c_match)) == NULL){
			WARNING("HTTPFILTER: build host string erro");
			break;
		    }
		}else if (tagNameMatch(pnode,"HTTP_ENCODE_C") == 0){
		    FREE_SOME_RES(httpfilter->encode_c);
		    httpfilter->encode_c = NULL;
		    if ((httpfilter->encode_c = buildstring(pnode, &httpfilter->encode_c_match)) == NULL){
			WARNING("HTTPFILTER: build encod string erro");
			break;
		    }
		}else if (tagNameMatch(pnode,"HTTP_URI_C") == 0){
		    FREE_SOME_RES(httpfilter->uri_c);
		    httpfilter->uri_c = NULL;
		    if ((httpfilter->uri_c = buildstring(pnode, &httpfilter->uri_c_match)) == NULL){
			WARNING("HTTPFILTER: build uri string erro");
			break;
		    }
		}
		
	}
	pnode = pnode->next;
    }
    if (pnode == NULL)
	return httpfilter;
    else{
	freeallpcre(httpfilter);
	free (httpfilter);
	return NULL;
    }
}

static int
httpfilter_create(PatternMatchInterfacePtr pmi,xmlNodePtr pxmlnode)
{
    /*
     * first we should use the PatternMatchInterface node  and assign the following element in the node
     *           0. patterntype
     *           1. patternname ( this come from the "define" attribute)  
     *           2. pmatch  (this is the specific fuction) 
     *           3. pfactory (this func pinter is used to release the resource assigned in this function )
     *              and we can just give it value "httpfilter_factory"
     * second we should create specific node for the pattern
     * 		 0. patterndata (this data is released by the pmatch
     */
//  PatternMatchInterfacePtr pmi = NULL;
 //   NEW_PATTERN_MATCH_INTERFACE(pmi);
    if (pmi == NULL) return -1;
    snprintf(pmi->patterntype,PATTERNTYPELEN,"%s",patterntype);
    pmi->pfactory = &httpfilter_factory;
    pmi->pmatch = &httpfilter_patternmatch;
    pmi->patterndata = get_specific_data(pxmlnode);
    pmi->region = httpfilter_factory.region;
    if (pmi->patterndata == NULL)
	goto erro;
    return 0;
erro:
    return -1;
}


static void 
httpfilter_release(PatternMatchInterfacePtr parg)
{
    /*
     * this function have just one task:
     * 1. it should release the resource in PatternMatchInterfacePtr::patterndata
     */
    /**the first task**/
    HttpFilterPtr hf_ptr = (HttpFilterPtr)parg->patterndata;
    if (hf_ptr != NULL){
	freeallpcre(hf_ptr);
	freeallstring(hf_ptr);
	free(hf_ptr);
	parg->patterndata = NULL;
    }
    return;
}
static int
httpfilter_init()
{
    return 0;
}
static inline int
patternmatch(const char *subject,int subject_length,const pcre* re)
{
#define OVECCOUNT 30 /* should be a multiple of 3 */
    int ovector[OVECCOUNT];
    int rc;
    rc = pcre_exec(
	    re, /* the compiled pattern */
	    NULL, /* no extra data - we didn�t study the pattern */
	    subject, /* the subject string */
	    subject_length, /* the length of the subject */
	    0, /* start at offset 0 in the subject */
	    0, /* default options */
	    ovector, /* output vector for substring information */
	    OVECCOUNT); /* number of elements in the output vector */
    if (rc < 0){
	if (rc != PCRE_ERROR_NOMATCH){
	    WARNING("HTTPFILTER: pcre erro [%s][%d]",subject,rc);
	    return -1;
	}else{
	    //BWSDEBUG("WE ARE NOT MATCH[%s]",subject);
	    return -1;
	}
    }else if (rc == 0){	
	WARNING("HTTPFILTER: ovector room has not enough room");
	return -1; 
    }
    return 0;
}
#define getsomefield(ptr) \
    (ptr == NULL)?"":ptr;
PatternMatchResult 
httpfilter_patternmatch(void *conn,void*arg,short *result)
{
    stat_t * proc = (stat_t *)conn;
    //const char *host = "";
    //int   host_length  = strlen(host);
      
    HttpFilterPtr hf = (HttpFilterPtr)arg;
    if (hf->agent != NULL){
	const char *agent  = getsomefield(proc->user_agent);
	int   agent_length = strlen(agent);
	if (0 != patternmatch(agent,agent_length,hf->agent)){
	    BWSDEBUG("WE ARE NOT MATCH AGENT[%s]",agent);
	    if (hf->agent_match == HTTP_MATCH){
	    	return NotMatch;
	    }
	}else{
	    if (hf->agent_match == HTTP_NOT_MATCH){
	    	return NotMatch;
	    }
	}
    }
    if (hf->cookie != NULL){
	const char *cookie = getsomefield(proc->cookie);
	int   cookie_length = strlen(cookie);
 	if (0 != patternmatch(cookie,cookie_length,hf->cookie)){
	    BWSDEBUG("WE ARE NOT MATCH COOKIE[%s]",cookie);
	    if (hf->cookie_match == HTTP_MATCH){
	    	return NotMatch;
	    }
	}else{
	    if (hf->cookie_match == HTTP_NOT_MATCH){
	    	return NotMatch;
	    }
	}
    }
    if (hf->encode != NULL){
	const char *encode = getsomefield(proc->accept_encoding);
	int   encode_length= strlen(encode);
	if ( 0 != patternmatch(encode,encode_length,hf->encode) ){
	    BWSDEBUG("WE ARE NOT MATCH ENCODE[%s]",encode);
	    if (hf->encode_match == HTTP_MATCH){
	    	return NotMatch;
	    }
	}else{
	    if (hf->encode_match == HTTP_NOT_MATCH){
	    	return NotMatch;
	    }
	}
    }
    if (hf->refer != NULL){
	const char *refer  = getsomefield(proc->refer);
	int   refer_length = strlen(refer);
	if ( 0 != patternmatch(refer,refer_length,hf->refer)){
	    BWSDEBUG("WE ARE NOT MATCH REFER[%s]",refer);
	    if (hf->refer_match == HTTP_MATCH){
	    	return NotMatch;
	    }
	}else{
	    if (hf->refer_match == HTTP_NOT_MATCH){
	    	return NotMatch;
	    }
	}
    }
    if (hf->uri != NULL){
	const char *uri = getsomefield(proc->uri); //"/s?asdfasdf";//NULL;
	int   uri_length  = strlen(uri); 
	if (0 != patternmatch(uri,uri_length,hf->uri)){
	    BWSDEBUG("WE ARE NOT MATCH URI[%s]",uri);
	    if (hf->uri_match == HTTP_MATCH){
	    	return NotMatch;
	    }
	}else{
	    if (hf->uri_match == HTTP_NOT_MATCH){
	    	return NotMatch;
	    }
	}
    }
    if (hf->host != NULL){
	const char *host = getsomefield(proc->host);
	int   host_length  = strlen(host); 
	if (0 != patternmatch(host,host_length,hf->host)){
	    BWSDEBUG("WE ARE NOT MATCH HOST[%s]",host);
	    if (hf->host_match == HTTP_MATCH){
	    	return NotMatch;
	    }
	}else{
	    if (hf->host_match == HTTP_NOT_MATCH){
	    	return NotMatch;
	    }
	}
    }
   if (hf->agent_c != NULL){
	const char *agent  = getsomefield(proc->user_agent);
	if (0 != strcmp(agent,hf->agent_c)){
	    BWSDEBUG("WE ARE NOT MATCH AGENT[%s]",agent);
	    if (hf->agent_c_match == HTTP_MATCH){
	    	return NotMatch;
	    }
	}else{
	    if (hf->agent_c_match == HTTP_NOT_MATCH){
	    	return NotMatch;
	    }
	}
    }
    if (hf->cookie_c != NULL){
	const char *cookie = getsomefield(proc->cookie);
 	if (0 != strcmp(cookie,hf->cookie_c)){
	    BWSDEBUG("WE ARE NOT MATCH COOKIE[%s]",cookie);
	    if (hf->cookie_c_match == HTTP_MATCH){
	    	return NotMatch;
	    }
	}else{
	    if (hf->cookie_c_match == HTTP_NOT_MATCH){
	    	return NotMatch;
	    }
	}
    }
    if (hf->encode_c != NULL){
	const char *encode = getsomefield(proc->accept_encoding);
	if ( 0 != strcmp(encode,hf->encode_c) ){
	    BWSDEBUG("WE ARE NOT MATCH ENCODE[%s]",encode);
	    if (hf->encode_c_match == HTTP_MATCH){
	    	return NotMatch;
	    }
	}else{
	    if (hf->encode_c_match == HTTP_NOT_MATCH){
	    	return NotMatch;
	    }
	}
    }
    if (hf->refer_c != NULL){
	const char *refer  = getsomefield(proc->refer);
	if ( 0 != strcmp(refer,hf->refer_c)){
	    BWSDEBUG("WE ARE NOT MATCH REFER[%s]",refer);
	    if (hf->refer_c_match == HTTP_MATCH){
	    	return NotMatch;
	    }
	}else{
	    if (hf->refer_c_match == HTTP_NOT_MATCH){
	    	return NotMatch;
	    }
	}
    }
    if (hf->uri_c != NULL){
	const char *uri = getsomefield(proc->uri); //"/s?asdfasdf";//NULL;
	if (0 != strcmp(uri,hf->uri_c)){
	    BWSDEBUG("WE ARE NOT MATCH URI[%s]",uri);
	    if (hf->uri_c_match == HTTP_MATCH){
	    	return NotMatch;
	    }
	}else{
	    if (hf->uri_c_match == HTTP_NOT_MATCH){
	    	return NotMatch;
	    }
	}
    }
    if (hf->host_c != NULL){
	const char *host = getsomefield(proc->host);
	if (0 != strcmp(host,hf->host_c)){
	    BWSDEBUG("WE ARE NOT MATCH HOST[%s]",host);
	    if (hf->host_c_match == HTTP_MATCH){
	    	return NotMatch;
	    }
	}else{
	    if (hf->host_c_match == HTTP_NOT_MATCH){
	    	return NotMatch;
	    }
	}
    }

    return Match;
    //const char *uri = 
}
