#include "policyframe.h"
#include "policy.h"
static int rtcodefactory_create(ActionInterfacePtr ai,xmlNodePtr pxmlnode);
static void rtcodefactory_release(ActionInterfacePtr aif);
static int rtcode_action(void *conn,void*arg);
ActionFactory rtcode_factory={"ReturnCode",\
					REGION_PRE,\
					&rtcodefactory_create,\
				     	&rtcodefactory_release
};
//#define WARNING(fmt,...) printf("%s-%d:"fmt"\n",__FILE__,__LINE__,##__VA_ARGS__)
//#define BWSDEBUG WARNING

static void *
get_specific_data(xmlNodePtr pxmlnode){

    int *rtcode = (int*)malloc(sizeof(int));
    if (rtcode == NULL){
	WARNING("Not Enough Memory");
	return NULL;
    }
    if (0 != getattributeint(pxmlnode,"Code",rtcode)){
	free(rtcode);
	return NULL;
    }
    BWSDEBUG("Code:%d",*rtcode);
    return rtcode;
}
static int 
rtcodefactory_create(ActionInterfacePtr ai,xmlNodePtr pxmlnode)
{
    /*
     * first we should use the ActionInterface node  and assign the following element in the node
     *           0. actionname
     *           1. action  (this is the specific fuction) 
     *           3. pfactory (this func pinter is used to release the resource assigned in this function )
     *              and we can just give it value "rewrite_factory"
     * second we should create specific node for the action
     * 		 0. actiondata (this data is released by the pmatch
     */

  if (ai == NULL) return -1;
  ai->pfactory = &rtcode_factory;
  ai->action   = &rtcode_action;
  ai->actiondata = get_specific_data(pxmlnode);
  ai->region = rtcode_factory.region;
  if (ai->actiondata == NULL) goto err;
  return 0;
err:
  return -1;
}
void 
rtcodefactory_release(ActionInterfacePtr aif)
{
    if (aif->actiondata != NULL){
	free((int*)aif->actiondata);
	aif->actiondata = NULL;
    }
    return;
}
/*
 *  if we want the some 302 400 http status 
 *  we must modify the process_t::conn_t::status
 */
int 
rtcode_action(void *conn,void *arg)
{
    stat_t * proc = (stat_t *)conn;
    proc->rtcode = *(int*)arg;
    BWSDEBUG("RT CODE: %d", *(int*)arg);
    return 0;
}
