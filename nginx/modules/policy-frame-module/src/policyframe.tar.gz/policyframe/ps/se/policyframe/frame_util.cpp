#include <libxml/xmlmemory.h>
#include <libxml/parser.h>
#include <iconv.h>
#include <libxml/encoding.h>
#include <string.h>
#include <ul_log.h>
//#include "util.h"

int
getattributevalue(xmlNodePtr pcur,char *attribute,char *value, int vlen)
{
    xmlChar *name;
    name = xmlGetProp(pcur,(const xmlChar*)attribute);
    int len;
    if (name == NULL ) return -1;
    if ( (len=xmlStrlen(name)) < vlen ){
	memcpy(value,name,len);
	value[len] = 0;
	xmlFree(name);
	return 0;
    }else{
	memcpy(value,name,vlen - 1);
	value[vlen - 1] = 0;
	ul_writelog(UL_LOG_WARNING,"When get the attribute[%s] the buffer is out.",attribute);
	xmlFree(name);
	return 0;
    }
    xmlFree(name);
    return -1;
}

int 
getattributeint(xmlNodePtr pcur,char *attribute,int *value)
{
    char num[128];
    if (getattributevalue(pcur,attribute,num,sizeof num) < 0) return -1;
    *value = atoi(num);
    return 0;
}

int 
getcontent(xmlNodePtr pcur,char *value,int vlen)
{
    xmlChar* name;
    int len;
    name = xmlNodeGetContent(pcur);
    if (NULL == name) return -1;
    if ( (len=xmlStrlen(name)) < vlen){
	memcpy(value,name,len);
	value[len] = 0;
	xmlFree(name);
	return 0;
    }
    xmlFree(name);
    return -1;
}

int 
getcontentint(xmlNodePtr pcur,int *value)
{
    char num[32];
    if (getcontent(pcur,num,sizeof num) < 0) return -1;
    * value = atoi (num);
    return 0;
}
/*
 * 0 match
 * -1 not match
 */
int 
tagNameMatch(xmlNodePtr cur,char * tagname)
{
    if ((xmlStrlen(cur->name) == (int)strlen (tagname))&&\
		(xmlStrcmp(cur->name,(xmlChar*)tagname) == 0))
	return 0;
    return -1;

}

