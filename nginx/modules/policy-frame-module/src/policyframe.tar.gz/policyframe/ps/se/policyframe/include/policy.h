#ifndef __POLICY__
#define __POLICY__
#include "frame.h"
#include "frame_util.h"
#include <netdb.h>

#ifndef NOTHREAD
#define USETHREAD
#endif

#define BUFFERLENGTH 4096
#define LWS " \t\n\r"

typedef struct
{
	struct in_addr client_addr;     /* client's address */
	char    *uri;                   /* uri fields in http headers */
	char    *refer;                 /* http headers */
	char    *user_agent;
	char    *host;
	char    *accept_encoding;
	char    *cookie;
	int	rtcode;
}stat_t;

typedef struct
{
	struct 	in_addr client_addr;
	char	*in_buffer;
	unsigned int	length;
}quest_t;

int processPolicy(void *proc, int op);
int parse_request_init();

#endif
