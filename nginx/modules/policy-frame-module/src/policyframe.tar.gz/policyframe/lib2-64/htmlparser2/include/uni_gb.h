#ifndef __UL_UNI_GB_H__
#define __UL_UNI_GB_H__

/*
 * translate table for unicode to gbk
 */ 
extern unsigned short ul_uni_gb_array[65536];

#endif
