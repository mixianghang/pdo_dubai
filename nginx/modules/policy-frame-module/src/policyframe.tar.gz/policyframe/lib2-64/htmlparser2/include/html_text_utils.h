#ifndef __HTML_TEXT_UTILS_H__
#define __HTML_TEXT_UTILS_H__
/*
 * description :
 * 		combine two functions: dereferencing html char and merging blank.
 * 		copy text from src to buffer after dereferencing html char and 
 * 		merging blank
 * input :
 * 		buffer : the buffer to store text
 * 		available : the begin postion of buffer this time
 * 		end : the last position of buffer
 * 		src : the source text
 * output :
 * 		buffer : the text will append to it
 * return
 * 		the new postion of buffer
 */ 

int copy_html_text(char *buffer, int available, int end, char *src);

 /*	copy text from src to buffer after dereferencing html char 
  */
int	html_derefrence_text (char *buffer, int available, int end, char *src);
// same as html_derefrence_text except ' ' 32
int	html_derefrence_text_url(char *buffer, int available, int end, char *src);
/*	copy text from src to buffer after merging blank
 */
int	html_tree_copy_html_text (char *buffer, int available, int end, char *src);

/*	copy text only, do NOT dereferencing html char or merging blank
 */
int html_copy_text_only (char *buffer, int available, int end, char *src);
#endif
