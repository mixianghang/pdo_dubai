#ifndef __BH_BLOCK_HEAP_H__
#define __BH_BLOCK_HEAP_H__

typedef struct _block_t {
	char *p;
	struct _block_t *next;
} block_t;

typedef struct _block_heap_t {
	int node_size;
	int unit_num;
	char *available;
	block_t *block;
	int block_cnt;
} block_heap_t;

/*
 * description :
 * 		create block_heap
 * input :
 * 		node_size : the size of node returned by block_heap_allocate
 * 		unit_num : the node number in one block
 * return :
 * 		success : the pointer of block_heap
 * 		failed : NULL
 */
block_heap_t *block_heap_create(int node_size, int unit_num);

/*
 * description :
 * 		allocate one node from block_heap
 * input :
 * 		block_heap : the block heap to allocate
 * return :
 * 		success : the pointer to node
 * 		failed : NULL
 */ 		
void *block_heap_allocate(block_heap_t *block_heap);

/*
 * description :
 * 		test if the block_heap is in initial state
 * input :
 * 		block_heap : the block heap to test
 * return :
 * 		yes : 1
 * 		no : 0
 */ 		
int is_clean_heap(block_heap_t *block_heap);

/*
 * description :
 * 		renew block_heap to initial state
 * input :
 * 		block_heap : the block heap to renew
 */		
void block_heap_renew(block_heap_t *block_heap);

/*
 * description :
 * 		delete block heap
 * input :
 * 		block_heap : the bloc heap to delete
 */ 		
void block_heap_delete(block_heap_t *block_heap);
#endif
