#ifndef __HTML_CHAR_H__
#define __HTML_CHAR_H__

/*
 * description :
 * 		if src is a valid reference, get unicode value of it
 * input :
 * 		src : the start postion of reference string
 * 		unicode : the pointer to store unicode value of reference string
 * ouput :
 * 		unicode : the unicode value of reference string
 * return :		
 * 		yes : first position of invalid char;
 * 		no : NULL
 */ 
char *html_dereference(char *src, unsigned short *unicode);

//same as html_dereference except ";"
char *html_dereference_url(char *src, unsigned short *unicode);
#endif
