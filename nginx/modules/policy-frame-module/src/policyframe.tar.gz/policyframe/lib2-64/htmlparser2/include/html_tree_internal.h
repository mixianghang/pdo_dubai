#ifndef __HTML_TREE_INTERNAL_H__
#define __HTML_TREE_INTERNAL_H__

#include "ul_dict.h"
#include"bh_block_heap.h"
#include "html_dtd.h"
#define VISIT_ERROR -1
#define VISIT_NORMAL 1
#define VISIT_FINISH 2
#define VISIT_SKIP_CHILD 	 3
//attribute
typedef struct _html_attribute_t {
	html_attr_type_t type;
	char * value;
	char * name;
	struct _html_attribute_t *next;
} html_attribute_t;

//tag
typedef struct _html_tag_t {
	char *tag_name;
	struct _html_attribute_t *attribute;
	char *text;
	html_tag_type_t tag_type;
	int tag_code;
} html_tag_t;


//node
typedef struct _html_node_t {
	html_tag_t html_tag;
	struct _html_node_t *parent;
    struct _html_node_t *next;
	struct _html_node_t *prev;
	struct _html_node_t *child;//first child
	struct _html_node_t *last_child;
} html_node_t;

/*virtual_memory is private */
typedef struct _virtual_memory_t
{
	char *vm_memory ;
	char *vm_memory_end ;
	char * vm_tree ;
	char *vm_string ;
	char *vm_node ;
	char *vm_attr ;
	char * vm_node_available ;
	char * vm_attr_available ;
}virtual_memory_t ;


/*
	when html_tree_create success 
 	you can use public Field
	never use other field !!!
*/
typedef struct _html_tree_t {
	block_heap_t *nodes_heap;	
	block_heap_t *attributes_heap;		
	char *string_heap;		
	int string_heap_size;			
	char *available_buffer;			
	
	char *next_input_char;	
	char *next_input_char_script;   
	html_node_t *next_input_node;
	html_node_t *my_head_node;		
	
	char * tag_type_map;			//public  map for tag type
	int tag_type_map_size;			
	char * child_parent_map;		//public  map for tag child parent	
	int child_parent_map_size;			
	char * attr_type_map;			//public  map for attr
	int attr_type_map_size;				
	int next_tag_code;				
	int stack_depth;					
	html_node_t root;			//public  the root node of tree
	virtual_memory_t *vm ;
} html_tree_t;
	
//for friend functions

/*
 * description :
 * 		get value of a attribute of html tag according to name
 * 	input :
 * 		html_tag :  the tag
 * 		name : the attribute name
 * 		type : the html attribute tag
 * 	return :
 * 		found : the value
 * 		not found : NULL
 * 	warning : the param "name" must be lower
 */ 

char *get_attribute_value(html_tag_t *html_tag, char *name);

char *get_attribute_value(html_tree_t * html_tree,html_tag_t *html_tag, char *name);

char *get_attribute_value(html_tag_t *html_tag,html_attr_type_t type);

/*
 * description :
 * 		iterator to visit html_tree
 * input :
 * 		html_tree : the tree to visit
 * 		start_visit : the visit function, it will be called for each node in
 * 						tree before visiting its childs
 * 		finish_visit : the visit function, it will be called for each node in
 * 						tree after visiting its childs
 * 		result : the paramter for start_visit and finish_visit
 * return :
 * 		success : 1
 * 		failed : 0
 */ 
int html_tree_visit(html_tree_t *html_tree, int (* start_visit)(html_tag_t *html_tag, void *result, int flag), 
						int (* finish_visit)(html_tag_t *html_tag, void *result), void *result, int flag);

int html_node_visit(html_node_t *html_node, int (* start_visit)(html_tag_t *html_tag, void *result,int flag),
						int (* finish_visit)(html_tag_t *html_tag, void *result), void *result, int flag);
#endif
