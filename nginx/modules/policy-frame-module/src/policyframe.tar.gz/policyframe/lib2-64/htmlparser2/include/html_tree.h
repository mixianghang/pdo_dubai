#ifndef __HTML_TREE2_H__
#define __HTML_TREE2_H__

#include "html_tree_internal.h"

html_tag_type_t get_tagtype(char *tag_map, char *tag_name);

/*
 * description :
 * 		creat html_tree struct
 * input :
 * 		max_page_len : the maximum length of page this tree can store
 * return :
 * 		success : the pointer to new struct
 * 		failed : NULL
 */
unsigned int get_size4create(int max_page_len) ; 
html_tree_t *html_tree_create(int max_page_len,void *  memory=NULL ,unsigned int memory_size=0);

/*
 * description :
 * 		parse page into html_tree 
 * input : 
 * 		html_tree : the struct to store result
 * 		page : the page to parse
 * 		page_len : the length of page, assert(strlen(page)==page_len)
 * return :
 * 		success : 1
 * 		failed : 0
 * notice :
 * 		html_tree must has been created and in initial state
 */ 
int html_tree_parse(html_tree_t *html_tree, char *page, int page_len);

/*
 * description :
 * 		set html_tree to initial state, free memory allocated 
 * 		by html_tree_parse
 * input :
 * 		html_tree : the struct to clean
 */ 
void html_tree_clean(html_tree_t *html_tree);

/*
 * descrition :
 * 		delete html tree allocated by html_tree_create
 * 		the html_tree must be in initial state
 * input :
 * 		html_tree : the struct to delete
 */ 
//void html_tree_del(html_tree_t *html_tree);
int script_parse(char * script,char * htmlbuf,int bufsize);

/*
 *description:
 *		create three maps 
 *		call in main thread before html_tree_create
 *		
 * */
unsigned int get_size4maps(void) ;	
int create_three_map(char * memory = NULL , unsigned int size = 0 ) ;
/*
 *description:
 *		destory three maps 
 *		call in main thread before exit
 */
void destory_three_map(void) ;


/*
 *description:
 *		load tree(offset) from memory_in to memory_out(real tree)
 *return:
 *	NULL--failed  html_tree---OK
 *input:
 *	memory_in , size_in --- html_tree(offset) received from net or read from disk
 *	memory_out , size_out ---- buffer for real html_tree
 *
 *note:
 *	you can use the html_tree to extract something you want just like a tree after html_tree_create and html_tree_parse
 *	but you can't use the tree to parse another html page 
 *	the can't access the filed in html_tree
 */
unsigned int get_size4load(const char * tree_in_memory) ;
html_tree_t * html_tree_load(char * memory_in , unsigned int size_in , char * memory_out , unsigned int size_out );



/* description:
 *		change the html_tree to memory_out which can be saved or trans
 *return:
 *	0 failed or change size 
 *note:
 *	memory_out must >= get_memory_size_tree 
 */
unsigned int get_size4save(const html_tree_t * html_tree) ;
int html_tree_save( html_tree_t *html_tree ,char * memory_out , unsigned int size_out);

/*
 *description:
 *	get the memory size used by html_tree 
 */
void html_tree_del(html_tree_t *html_tree);
#endif
