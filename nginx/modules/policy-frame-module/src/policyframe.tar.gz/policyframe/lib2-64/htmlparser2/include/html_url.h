#ifndef __HTML_URL_H__
#define __HTML_URL_H__
#include"ul_log.h"
#include"ul_url.h"
/*description:
 * 	same ul_single_path except #
 *input:
 *	path
 *output:
 *	path after escape %xx
 *return:
 * 0-failed 1-ok
 */

int ul_single_path_inner(char *path);

/*description:
 * 	same ul_check_url except \r \n  ' '
 *input:
 *	url
 *output:
 *	url after remove \r \n  and escape ' ' to %20
 *return:
 * 0-failed 1-ok
 */
int ul_check_url_inner(char * url) ;

/*description:
 * 	same ul_parser_url 
 * 	except change url like www.baicu.com?123 to www.baicu.com/?123  
 *input:
 *	url
 *output:
 *	site 
 *	port
 *	path
 *return:
 * 0-failed 1-ok
 */
int ul_parse_url_inner(const char *input,char *site,char *port,char *path);
#endif
